import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "npm:resend@2.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

interface AnalysisEmailRequest {
  clientEmail: string;
  companyName: string;
  totalSavings: number;
  totalInvoices: number;
  totalRHDCost: number;
  overpaymentPercent: number;
  analysisDate: string;
  podNumbers: string[];
  customerAddress?: string;
}

const generateEmailHTML = (data: AnalysisEmailRequest) => {
  const {
    companyName,
    totalSavings,
    totalInvoices,
    totalRHDCost,
    overpaymentPercent,
    analysisDate,
    podNumbers,
    customerAddress
  } = data;

  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8">
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #1e40af, #3b82f6); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
        .content { background: #f9fafb; padding: 30px; border-radius: 0 0 10px 10px; }
        .highlight { background: #10b981; color: white; padding: 15px; border-radius: 8px; text-align: center; margin: 20px 0; }
        .stats { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin: 20px 0; }
        .stat-card { background: white; padding: 15px; border-radius: 8px; border-left: 4px solid #3b82f6; }
        .warning { background: #fef3c7; border: 1px solid #f59e0b; padding: 15px; border-radius: 8px; margin: 20px 0; }
        .footer { text-align: center; margin-top: 30px; padding: 20px; background: #374151; color: white; border-radius: 8px; }
        .pod-list { background: white; padding: 10px; border-radius: 5px; font-family: monospace; font-size: 12px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>🔋 Teljesítmény Lekötés Optimalizálás</h1>
          <h2>${companyName}</h2>
          <p>Energiafogyasztás elemzési jelentés</p>
        </div>
        
        <div class="content">
          <p><strong>Tisztelt ${companyName}!</strong></p>
          
          <p>Elkészült a teljesítmény lekötés optimalizálási elemzése. Az alábbiakban találja a főbb eredményeket:</p>
          
          <div class="highlight">
            <h3>💰 Becsült éves megtakarítás: ${totalSavings.toLocaleString()} Ft</h3>
          </div>
          
          <div class="stats">
            <div class="stat-card">
              <h4>📊 Elemzett számlák</h4>
              <p><strong>${totalInvoices} db</strong></p>
            </div>
            <div class="stat-card">
              <h4>💳 Összes RHD díj</h4>
              <p><strong>${totalRHDCost.toLocaleString()} Ft</strong></p>
            </div>
            <div class="stat-card">
              <h4>⚠️ Túlfizetés mértéke</h4>
              <p><strong>${overpaymentPercent}%</strong></p>
            </div>
            <div class="stat-card">
              <h4>📅 Elemzés dátuma</h4>
              <p><strong>${analysisDate}</strong></p>
            </div>
          </div>
          
          ${customerAddress ? `
          <div class="stat-card">
            <h4>📍 Telephely</h4>
            <p>${customerAddress}</p>
          </div>
          ` : ''}
          
          ${podNumbers.length > 0 ? `
          <div>
            <h4>🔢 POD azonosítók:</h4>
            <div class="pod-list">
              ${podNumbers.map(pod => `<div>${pod}</div>`).join('')}
            </div>
          </div>
          ` : ''}
          
          <div class="warning">
            <h4>⚠️ Fontos információ</h4>
            <p><strong>Ez a kalkulációs eredmény nem minősül ajánlatnak!</strong></p>
            <p>A hálózat optimalizálás teljes szakmai véglegesítéséhez vegye fel a kapcsolatot szakértőnkkel:</p>
            <p>📞 <strong>+36302806962</strong> | ✉️ <strong>info@gs-group.hu</strong></p>
          </div>
          
          <p>A részletes elemzési jelentést a webes felületen tekintheti meg.</p>
          
          <p>Amennyiben kérdése van, keressen minket bizalommal!</p>
          
          <p>Üdvözlettel,<br>
          <strong>GS Group Energetikai Szakértő Csapat</strong></p>
        </div>
        
        <div class="footer">
          <p>🌐 <strong>www.gs-group.hu</strong></p>
          <p>📧 info@gs-group.hu | 📞 +36302806962</p>
          <p><em>Professzionális energetikai tanácsadás és optimalizálás</em></p>
        </div>
      </div>
    </body>
    </html>
  `;
};

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const emailData: AnalysisEmailRequest = await req.json();
    
    const {
      clientEmail,
      companyName,
      totalSavings,
      totalInvoices,
      totalRHDCost,
      overpaymentPercent,
      analysisDate,
      podNumbers,
      customerAddress
    } = emailData;

    console.log("📧 Email küldés indítása:", {
      clientEmail,
      companyName,
      totalSavings,
      totalInvoices
    });

    const emailHTML = generateEmailHTML(emailData);
    const subject = `${companyName} teljesítmény optimalizálás`;

    // Email küldése az ügyfélnek
    const clientEmailResponse = await resend.emails.send({
      from: "GS Group <no-reply@gs-group.hu>",
      to: [clientEmail],
      subject: subject,
      html: emailHTML,
    });

    console.log("✅ Ügyfél email elküldve:", clientEmailResponse);

    // Email küldése az info@gs-group.hu címre is
    const internalEmailResponse = await resend.emails.send({
      from: "GS Group <no-reply@gs-group.hu>",
      to: ["info@gs-group.hu"],
      subject: `[BELSŐ] ${subject}`,
      html: `
        <h2>Új elemzés készült</h2>
        <p><strong>Ügyfél:</strong> ${companyName}</p>
        <p><strong>Email:</strong> ${clientEmail}</p>
        <p><strong>Potenciális megtakarítás:</strong> ${totalSavings.toLocaleString()} Ft</p>
        <p><strong>Elemzés dátuma:</strong> ${analysisDate}</p>
        <hr>
        ${emailHTML}
      `,
    });

    console.log("✅ Belső email elküldve:", internalEmailResponse);

    return new Response(
      JSON.stringify({ 
        success: true, 
        clientEmailId: clientEmailResponse.data?.id,
        internalEmailId: internalEmailResponse.data?.id
      }), 
      {
        status: 200,
        headers: {
          "Content-Type": "application/json",
          ...corsHeaders,
        },
      }
    );

  } catch (error: any) {
    console.error("❌ Email küldési hiba:", error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message 
      }),
      {
        status: 500,
        headers: { 
          "Content-Type": "application/json", 
          ...corsHeaders 
        },
      }
    );
  }
};

serve(handler);