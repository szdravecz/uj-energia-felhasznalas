import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Upload, Zap, TrendingDown, FileText, BarChart3, CheckCircle, ArrowRight, Mail, X, AlertTriangle, Eye } from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import gsgLogo from "@/assets/gsg-logo.png";
import energyBackground from "/lovable-uploads/17ddbc87-3354-45fd-bef5-01b924b3b6a6.png";
import energyEfficiencyBackground from "@/assets/energy-efficiency-background.jpg";
import { AnalysisEngine, type AnalysisProgress } from "@/services/analysisEngine";

const Home = () => {
  const [email, setEmail] = useState("");
  const [consent, setConsent] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [isDragOver, setIsDragOver] = useState(false);
  const [analysisStarted, setAnalysisStarted] = useState(false);
  const [analysisProgress, setAnalysisProgress] = useState<AnalysisProgress | null>(null);
  const [analysisComplete, setAnalysisComplete] = useState(false);
  const [showEmailForm, setShowEmailForm] = useState(false);
  const [analysisResults, setAnalysisResults] = useState<any>(null);
  const [estimatedTimeLeft, setEstimatedTimeLeft] = useState<number>(0);
  const [analysisStartTime, setAnalysisStartTime] = useState<number>(0);
  const navigate = useNavigate();

  // 🔄 SESSION CLEANUP - Automatikus törlés a Home komponens betöltésekor
  useEffect(() => {
    console.log('🔄 Home komponens betöltve - session cleanup...');
    
    // Ha van korábbi analysis eredmény, törölj
    if (analysisResults) {
      console.log('🔄 Korábbi analysis eredmények törlése...');
      setAnalysisResults(null);
      setAnalysisComplete(false);
      setAnalysisStarted(false);
      setAnalysisProgress(null);
      setUploadedFiles([]);
      toast.info('Korábbi session adatok törölve');
    }
  }, []); // Csak komponens mount-kor fut le

  const handleStartModal = () => {
    setIsModalOpen(true);
  };

  // File upload kezelés - automatikus elemzés indítással
  const handleFileUpload = (files: FileList | null) => {
    if (!files) return;
    
    const pdfFiles = Array.from(files).filter(file => file.type === 'application/pdf');
    
    if (pdfFiles.length === 0) {
      toast.error("Csak PDF fájlokat lehet feltölteni!");
      return;
    }

    if (pdfFiles.length > 12) {
      toast.error("Maximum 12 fájlt lehet feltölteni!");
      return;
    }

    const newFiles = [...uploadedFiles, ...pdfFiles].slice(0, 12);
    setUploadedFiles(newFiles);
    toast.success(`${pdfFiles.length} fájl feltöltve`);
    
    // Automatikus elemzés indítás ha vannak fájlok
    if (newFiles.length > 0) {
      setTimeout(() => {
        handleStartAnalysisWithFiles(newFiles);
      }, 500); // Kis késleltetés a UX-ért
    }
  };

  // Drag & Drop handlers
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    handleFileUpload(e.dataTransfer.files);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  // Fájl eltávolítása
  const removeFile = (index: number) => {
    setUploadedFiles(prev => prev.filter((_, i) => i !== index));
  };

  // Email form submit kezelése - eredmények megjelenítése
  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Ha email megadva, akkor hozzájárulás kötelező
    if (email && !consent) {
      toast.error("Kérjük fogadja el az adatkezelési feltételeket az email küldéshez!");
      return;
    }

    if (email) {
      localStorage.setItem('userEmail', email);
    }
    
    // Navigáció Results oldalra
    navigate('/results', {
      state: {
        results: analysisResults
      }
    });
  };

  // Elemzés indítása közvetlenül
  const handleStartAnalysis = async () => {
    if (uploadedFiles.length === 0) {
      toast.error("Először töltsön fel számlákat!");
      return;
    }

    await handleStartAnalysisWithFiles(uploadedFiles);
  };

  // Elemzés indítása megadott fájlokkal - email form megjelenítéssel az elemzés után
  const handleStartAnalysisWithFiles = async (files: File[]) => {
    if (files.length === 0) {
      toast.error("Először töltsön fel számlákat!");
      return;
    }

    setAnalysisStarted(true);
    setAnalysisStartTime(Date.now());
    setEstimatedTimeLeft(90); // 90 másodperc kezdeti becslés
    
    try {
      const geminiApiKey = localStorage.getItem('geminiApiKey') || '';
      const visionApiKey = localStorage.getItem('googleVisionApiKey') || 'AIzaSyBQOIWfD-Mjo0i0Wj6DdEoUrR_8bei7EKk';
      
      const analysisEngine = new AnalysisEngine(geminiApiKey, visionApiKey);
      analysisEngine.setProgressCallback(setAnalysisProgress);
      
      const results = await analysisEngine.runFullAnalysis(files);
      
      // Eredmények tárolása
      setAnalysisResults(results);
      setAnalysisComplete(true);
      
      // Email form megjelenítése az elemzés után
      setShowEmailForm(true);
      
    } catch (error) {
      toast.error(`Hiba történt az elemzés során: ${error}`);
      setAnalysisStarted(false);
      setAnalysisProgress(null);
      setAnalysisComplete(false);
      setEstimatedTimeLeft(0);
    }
  };

  // Modal bezárása és reset
  const closeModal = () => {
    setIsModalOpen(false);
    setUploadedFiles([]);
    setAnalysisStarted(false);
    setAnalysisProgress(null);
    setAnalysisComplete(false);
    setShowEmailForm(false);
    setEmail("");
    setConsent(false);
    setAnalysisResults(null);
    setEstimatedTimeLeft(0);
    setAnalysisStartTime(0);
  };

  // Időbecslés frissítése - 90 másodpercről visszafelé számol
  useEffect(() => {
    if (!analysisStarted || analysisComplete) return;

    const interval = setInterval(() => {
      const elapsed = (Date.now() - analysisStartTime) / 1000; // másodpercben
      const remaining = Math.max(0, Math.round(90 - elapsed));
      setEstimatedTimeLeft(remaining);
    }, 1000);

    return () => clearInterval(interval);
  }, [analysisStarted, analysisComplete, analysisStartTime]);

  const features = [
    {
      icon: Upload,
      title: "12 havi számla feltöltés",
      description: "Ugyanazon POD-hoz tartozó számlák - akár több számla 1 PDF-ben is"
    },
    {
      icon: Zap,
      title: "AI-alapú elemzés",
      description: "Gemini AI automatikusan elemzi a teljesítmény adatokat"
    },
    {
      icon: TrendingDown,
      title: "Optimalizálási javaslatok",
      description: "Konkrét lekötés csökkentési lehetőségek azonosítása"
    },
    {
      icon: BarChart3,
      title: "Megtakarítás kalkuláció",
      description: "Pontos forint összegben megadott éves megtakarítás"
    }
  ];

  const steps = [
    {
      number: "01",
      title: "Számlák feltöltése",
      description: "Töltse fel ugyanazon POD-hoz tartozó 12 havi számláit - akár több számla egy PDF-ben is"
    },
    {
      number: "02", 
      title: "AI elemzés",
      description: "Rendszerünk automatikusan kinyeri és elemzi a teljesítmény adatokat"
    },
    {
      number: "03",
      title: "Optimalizálási javaslatok",
      description: "Kapjon konkrét javaslatokat a lekötött teljesítmény csökkentésére"
    },
    {
      number: "04",
      title: "Megtakarítás számítás",
      description: "Pontos kalkuláció az éves RHD megtakarításról forintban"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-subtle">
      {/* GSG Logo in top left corner */}
      <div className="absolute top-4 left-4 z-50">
        <div className="bg-white rounded-lg p-3 shadow-lg">
          <img 
            src={gsgLogo} 
            alt="GSG Logo" 
            className="h-12 w-auto object-contain"
          />
        </div>
      </div>

      {/* Hero Section */}
      <div className="relative bg-gradient-primary overflow-hidden min-h-screen flex items-center">
        {/* Image Background */}
        <div className="absolute inset-0">
          <img 
            src={energyEfficiencyBackground}
            alt="Energy Efficiency Background"
            className="w-full h-full object-cover opacity-60"
          />
          <div className="absolute inset-0 bg-gradient-primary/60"></div>
          <div className="absolute inset-0 bg-gradient-to-br from-transparent via-white/5 to-white/10"></div>
        </div>
        
        <div className="relative container mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="max-w-5xl mx-auto">

            {/* Main Hero Content */}
            <div className="text-center space-y-8">
              
              {/* Hero Title */}
              <div className="animate-fade-in-up animation-delay-200">
                <div className="flex flex-col lg:flex-row items-center justify-center gap-4 lg:gap-6 mb-6">
                  <div className="animate-glow-pulse">
                    <Zap className="h-12 w-12 sm:h-16 sm:w-16 lg:h-20 lg:w-20 text-white" />
                  </div>
                  <h1 className="text-4xl sm:text-5xl lg:text-7xl xl:text-8xl font-bold text-white leading-tight">
                    Hálózati díj
                    <span className="block text-energy-blue-light bg-gradient-to-r from-energy-blue-light to-white bg-clip-text text-transparent">
                      optimalizálás
                    </span>
                  </h1>
                </div>
              </div>
              
              {/* Subtitle */}
              <div className="animate-fade-in-up animation-delay-400">
                <p className="text-lg sm:text-xl lg:text-2xl xl:text-3xl text-white/95 mb-8 leading-relaxed max-w-4xl mx-auto">
                  Csökkentse villamos energia rendszerhasználati díjait akár{" "}
                  <span className="font-bold text-energy-blue-light bg-white/10 px-3 py-1 rounded-full">
                    20-40%-kal
                  </span>
                  {" "}intelligens teljesítmény elemzéssel
                </p>
              </div>
            
              {/* Features Highlight Box */}
              <div className="animate-scale-in animation-delay-600">
                <div className="bg-white/10 backdrop-blur-md rounded-2xl lg:rounded-3xl p-6 lg:p-8 mx-auto max-w-4xl border border-white/20 shadow-glow">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 lg:gap-6 text-white/95">
                    <div className="flex items-center justify-center gap-3 p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors duration-300">
                      <CheckCircle className="h-5 w-5 lg:h-6 lg:w-6 text-energy-blue-light flex-shrink-0" />
                      <span className="text-sm lg:text-base font-medium">12 havi számla elemzés</span>
                    </div>
                    <div className="flex items-center justify-center gap-3 p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors duration-300">
                      <CheckCircle className="h-5 w-5 lg:h-6 lg:w-6 text-energy-blue-light flex-shrink-0" />
                      <span className="text-sm lg:text-base font-medium">AI-alapú optimalizálás</span>
                    </div>
                    <div className="flex items-center justify-center gap-3 p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors duration-300">
                      <CheckCircle className="h-5 w-5 lg:h-6 lg:w-6 text-energy-blue-light flex-shrink-0" />
                      <span className="text-sm lg:text-base font-medium">Konkrét forint megtakarítás</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* CTA Section */}
            <div className="animate-fade-in-up animation-delay-800 mt-12">
              <div className="space-y-6">
                <div className="text-center">
                  <Button 
                    onClick={handleStartModal}
                    type="button"
                    variant="energy" 
                    size="lg" 
                    className="bg-white text-energy-blue hover:bg-neutral-50 h-12 lg:h-14 px-6 lg:px-8 text-base lg:text-lg font-semibold shadow-glow hover:shadow-premium transition-all duration-300 hover:scale-105"
                  >
                    Kezdjük el! <ArrowRight className="ml-2 h-4 w-4 lg:h-5 lg:w-5" />
                  </Button>
                </div>
                
                {/* Quick stats */}
                <div className="text-center text-white/80 text-sm lg:text-base">
                  <span className="inline-flex items-center gap-2">
                    <span className="w-2 h-2 bg-energy-blue-light rounded-full animate-pulse"></span>
                    Már <span className="font-bold text-energy-blue-light">200+</span> vállalat takarított meg milliókat
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="py-24 bg-background">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-slate-gray mb-6">
              Miért válassza a Hálózati díj optimalizálást?
            </h2>
            <p className="text-xl text-slate-gray-light max-w-3xl mx-auto">
              Professzionális AI-alapú elemzés, amely pontos és gyakorlatias javaslatokat ad a villamos energia költségek csökkentésére
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="border-0 shadow-card hover:shadow-premium transition-all duration-300 hover:scale-105 bg-white">
                <CardHeader className="text-center pb-4">
                  <div className="mx-auto bg-gradient-primary rounded-2xl p-4 w-fit mb-4 shadow-premium">
                    <feature.icon className="h-8 w-8 text-white" />
                  </div>
                  <CardTitle className="text-slate-gray text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-slate-gray-light text-center leading-relaxed">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>

      {/* How it works */}
      <div className="py-24 bg-neutral-50">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-slate-gray mb-6">
              Hogyan működik?
            </h2>
            <p className="text-xl text-slate-gray-light max-w-2xl mx-auto">
              Egyszerű 4 lépéses folyamat a maximum megtakarításért
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <div key={index} className="relative">
                <div className="bg-white rounded-2xl p-8 shadow-card hover:shadow-premium transition-all duration-300 h-full">
                  <div className="text-6xl font-bold text-energy-blue-light mb-6">{step.number}</div>
                  <h3 className="text-xl font-bold text-slate-gray mb-4">{step.title}</h3>
                  <p className="text-slate-gray-light leading-relaxed">{step.description}</p>
                </div>
                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-1/2 -right-4 transform -translate-y-1/2">
                    <ArrowRight className="h-8 w-8 text-energy-blue-light" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="py-24 bg-gradient-primary relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PGNpcmNsZSBjeD0iMzAiIGN5PSIzMCIgcj0iMSIvPjwvZz48L2c+PC9zdmc+')] opacity-20"></div>
        
        <div className="relative container mx-auto px-6 text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Készen áll a megtakarításra?
          </h2>
          <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
            Csatlakozzon a már több millió forintot megtakarított vállalatokhoz a hálózati díj optimalizálással
          </p>
          
          <Button 
            onClick={() => setIsModalOpen(true)}
            variant="energy" 
            size="xl" 
            className="bg-white text-energy-blue hover:bg-neutral-50 shadow-glow"
          >
            <FileText className="mr-3 h-6 w-6" />
            Ingyenes elemzés kérése
            <ArrowRight className="ml-3 h-6 w-6" />
          </Button>
        </div>
      </div>

      {/* Footer */}
      <footer className="py-12 bg-slate-gray">
        <div className="container mx-auto px-6 text-center">
          <div className="flex items-center justify-center mb-4">
            <Zap className="h-8 w-8 text-energy-blue mr-3" />
            <span className="text-2xl font-bold text-white">Hálózati díj optimalizálás</span>
          </div>
          <p className="text-white/70 mb-4">
            Professzionális villamos energia lekötés optimalizálás AI technológiával
          </p>
          <p className="text-white/50 text-sm">
            © 2024 Hálózati díj optimalizálás. Minden jog fenntartva.
          </p>
        </div>
      </footer>

      {/* Elemzés Modal */}
      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="w-[95vw] max-w-6xl h-[95vh] max-h-[95vh] overflow-hidden flex flex-col p-0">
          <DialogHeader className="p-6 pb-4 shrink-0">
            <DialogTitle className="flex items-center gap-2 text-lg sm:text-xl lg:text-2xl">
              <Zap className="h-5 w-5 sm:h-6 sm:w-6 text-primary" />
              Hálózati díj optimalizálás elemzés
            </DialogTitle>
            <DialogDescription className="text-sm sm:text-base lg:text-lg font-semibold text-primary">
              Töltsön fel <strong className="font-bold underline">Rendszerhasználati elszámoló számlákat</strong> és készítjük a javaslatainkat!
            </DialogDescription>
          </DialogHeader>

          <div className="flex-1 overflow-y-auto px-6 pb-6">
            <div className="space-y-4 sm:space-y-6">
            {!analysisStarted && !showEmailForm && (
              <>
                {/* File Upload Area */}
                <div 
                  className={`border-2 border-dashed rounded-xl p-4 sm:p-6 lg:p-8 text-center transition-colors ${
                    isDragOver 
                      ? 'border-primary bg-primary/5' 
                      : 'border-gray-300 hover:border-primary/50'
                  }`}
                  onDrop={handleDrop}
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                >
                  <Upload className="h-8 w-8 sm:h-10 sm:w-10 lg:h-12 lg:w-12 mx-auto text-gray-400 mb-3 sm:mb-4" />
                  <h3 className="text-base sm:text-lg font-semibold text-gray-700 mb-2">
                    Húzza ide a PDF fájlokat vagy kattintson a tallózáshoz
                  </h3>
                  <p className="text-sm text-gray-500 mb-3 sm:mb-4">Maximum 12 fájl, egyenként max 10MB</p>
                  
                  <input
                    type="file"
                    multiple
                    accept=".pdf"
                    onChange={(e) => handleFileUpload(e.target.files)}
                    className="hidden"
                    id="file-upload-modal"
                  />
                  <Button 
                    onClick={() => document.getElementById('file-upload-modal')?.click()}
                    variant="outline"
                    className="mb-3 sm:mb-4"
                    size="sm"
                  >
                    Fájlok kiválasztása
                  </Button>
                  
                  <div className="text-xs sm:text-sm text-amber-700 bg-amber-50 border border-amber-200 rounded-lg p-2 sm:p-3">
                    <AlertTriangle className="h-4 w-4 sm:h-5 sm:w-5 inline mr-2 text-amber-600" />
                    <strong className="font-bold underline">Fontos: Ugyanazon POD számhoz tartozó számlák</strong>
                  </div>
                </div>

                {/* Uploaded Files */}
                {uploadedFiles.length > 0 && (
                  <div className="bg-gray-50 rounded-lg p-3 sm:p-4">
                    <h4 className="font-semibold mb-2 sm:mb-3 flex items-center gap-2 text-sm sm:text-base">
                      <FileText className="h-4 w-4" />
                      Feltöltött fájlok ({uploadedFiles.length})
                    </h4>
                    <div className="space-y-2 max-h-32 sm:max-h-40 overflow-y-auto">
                      {uploadedFiles.map((file, index) => (
                        <div key={index} className="flex items-center justify-between bg-white p-2 sm:p-3 rounded-lg border">
                          <div className="flex items-center gap-2 min-w-0 flex-1">
                            <FileText className="h-4 w-4 text-gray-500 flex-shrink-0" />
                            <span className="text-xs sm:text-sm font-medium truncate">{file.name}</span>
                            <Badge variant="secondary" className="text-xs flex-shrink-0">
                              {(file.size / 1024 / 1024).toFixed(1)} MB
                            </Badge>
                          </div>
                          <Button
                            onClick={() => removeFile(index)}
                            variant="ghost"
                            size="sm"
                            className="h-6 w-6 p-0 text-gray-400 hover:text-red-500 flex-shrink-0 ml-2"
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </>
            )}

            {/* Analysis Progress */}
            {analysisStarted && !analysisComplete && (
              <div className="space-y-4 sm:space-y-6">
                <div className="text-center">
                  <div className="flex items-center justify-center gap-2 mb-4">
                    <Zap className="h-6 w-6 sm:h-8 sm:w-8 text-primary animate-pulse" />
                    <h3 className="text-lg sm:text-xl font-semibold">Elemzés folyamatban...</h3>
                  </div>
                  <p className="text-primary font-medium text-base sm:text-lg">2-3 órás szakértői munka – 2-3 perc alatt az Ön kezében!</p>
                </div>
                
                {/* Progress Steps */}
                <div className="space-y-4">
                  {/* Step indicators */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mb-6">
                    {[
                      { step: 'upload', label: '1. File feltöltés', icon: Upload },
                      { step: 'ocr', label: '2. Számlaadatok kiolvasása', icon: FileText },
                      { step: 'analysis', label: '3. Szakmai elemzés', icon: Zap },
                      { step: 'report', label: '4. Riport összeállítása', icon: BarChart3 }
                    ].map(({ step, label, icon: Icon }, index) => {
                      const isActive = analysisProgress?.step === step;
                      const isCompleted = analysisProgress ? 
                        ['upload', 'ocr', 'analysis', 'report', 'complete'].indexOf(analysisProgress.step) > 
                        ['upload', 'ocr', 'analysis', 'report'].indexOf(step) : false;
                      
                      return (
                        <div key={step} className="text-center">
                          <div className={`w-10 h-10 sm:w-12 sm:h-12 mx-auto rounded-full flex items-center justify-center mb-2 transition-colors ${
                            isCompleted ? 'bg-green-500 text-white' :
                            isActive ? 'bg-primary text-white' : 
                            'bg-gray-200 text-gray-400'
                          }`}>
                            {isCompleted ? <CheckCircle className="h-5 w-5 sm:h-6 sm:w-6" /> : <Icon className="h-5 w-5 sm:h-6 sm:w-6" />}
                          </div>
                          <div className={`text-xs font-medium ${
                            isActive ? 'text-primary' : 
                            isCompleted ? 'text-green-600' : 
                            'text-gray-500'
                          }`}>
                            {label}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                  
                  {/* Progress bar */}
                  <div className="bg-gray-50 rounded-lg p-4 sm:p-6">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-gray-700">
                        Feldolgozás állapota
                      </span>
                      <span className="text-sm font-medium text-gray-700">
                        {analysisProgress?.progress || 0}%
                      </span>
                    </div>
                    <Progress value={analysisProgress?.progress || 0} className="w-full h-2 sm:h-3" />
                  </div>
                </div>
                
                {/* Mit fog kapni információ */}
                <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-4 sm:p-6 border border-blue-200">
                  <h4 className="text-base sm:text-lg font-semibold text-blue-900 mb-3 sm:mb-4 text-center">A KÖVETKEZŐKET KAPJA:</h4>
                  <div className="text-center mb-4">
                    <p className="text-sm sm:text-base text-blue-800 font-medium">
                      2-3 órás szakértői munka – 2-3 perc alatt az Ön kezében!
                    </p>
                  </div>
                  <ul className="space-y-2">
                    <li className="flex items-start gap-3">
                      <CheckCircle className="h-4 w-4 sm:h-5 sm:w-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-sm sm:text-base text-gray-700">Felesleges túlfizetések kiszűrése</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle className="h-4 w-4 sm:h-5 sm:w-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-sm sm:text-base text-gray-700">Szezonális mintázatok grafikonos elemzése</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle className="h-4 w-4 sm:h-5 sm:w-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-sm sm:text-base text-gray-700">Tételes havi értékelés táblázatos formában</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <CheckCircle className="h-4 w-4 sm:h-5 sm:w-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-sm sm:text-base text-gray-700">Szakmai összefoglaló és javaslatok</span>
                    </li>
                  </ul>
                </div>
                
                <div className="text-center text-sm text-gray-500">
                  {estimatedTimeLeft > 0 && 
                    `Becsült hátralévő idő: ${estimatedTimeLeft} másodperc`
                  }
                </div>
              </div>
            )}

            {/* Email Form - elemzés után */}
            {showEmailForm && analysisComplete && (
              <div className="space-y-4 sm:space-y-6">
                <div className="text-center mb-4 sm:mb-6">
                  <div className="flex items-center justify-center gap-2 mb-4">
                    <CheckCircle className="h-6 w-6 sm:h-8 sm:w-8 text-green-500" />
                    <h3 className="text-lg sm:text-xl font-semibold text-green-600">Elemzés elkészült!</h3>
                  </div>
                  
                  <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-4 sm:p-6 mb-4 sm:mb-6 border border-blue-200">
                    <h4 className="text-base sm:text-lg font-semibold text-blue-900 mb-3 sm:mb-4">A KÖVETKEZŐKET KAPJA:</h4>
                    <div className="text-center mb-4">
                      <p className="text-sm sm:text-base text-blue-800 font-medium">
                        2-3 órás szakértői munka – 2-3 perc alatt az Ön kezében!
                      </p>
                    </div>
                    <ul className="space-y-2 text-left">
                      <li className="flex items-start gap-3">
                        <CheckCircle className="h-4 w-4 sm:h-5 sm:w-5 text-green-500 mt-0.5 flex-shrink-0" />
                        <span className="text-sm sm:text-base text-gray-700">Felesleges túlfizetések kiszűrése</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle className="h-4 w-4 sm:h-5 sm:w-5 text-green-500 mt-0.5 flex-shrink-0" />
                        <span className="text-sm sm:text-base text-gray-700">Szezonális mintázatok grafikonos elemzése</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle className="h-4 w-4 sm:h-5 sm:w-5 text-green-500 mt-0.5 flex-shrink-0" />
                        <span className="text-sm sm:text-base text-gray-700">Tételes havi értékelés táblázatos formában</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <CheckCircle className="h-4 w-4 sm:h-5 sm:w-5 text-green-500 mt-0.5 flex-shrink-0" />
                        <span className="text-sm sm:text-base text-gray-700">Szakmai összefoglaló és javaslatok</span>
                      </li>
                    </ul>
                  </div>
                  
                  <p className="text-sm sm:text-base text-gray-600">Adja meg email címét az eredmények email küldéséhez (opcionális)</p>
                </div>

                <form onSubmit={handleEmailSubmit} className="space-y-4">
                  <div>
                    <Input
                      type="email"
                      placeholder="Email cím (opcionális)"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full"
                    />
                  </div>

                  {email && (
                    <div className="flex items-start gap-3">
                      <input
                        type="checkbox"
                        id="consent"
                        checked={consent}
                        onChange={(e) => setConsent(e.target.checked)}
                        className="mt-1"
                        required
                      />
                      <label htmlFor="consent" className="text-xs sm:text-sm text-gray-600 leading-relaxed">
                        Hozzájárulok, hogy email címemet az elemzés eredményének elküldéséhez használják fel. 
                        Az adatokat bizalmasan kezeljük és harmadik félnek nem adjuk át.
                      </label>
                    </div>
                  )}

                  <Button 
                    type="submit"
                    className="w-full"
                    size="lg"
                    disabled={email ? !consent : false}
                  >
                    <Eye className="mr-2 h-4 w-4" />
                    Eredmények megtekintése
                  </Button>
                </form>
              </div>
            )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Home;