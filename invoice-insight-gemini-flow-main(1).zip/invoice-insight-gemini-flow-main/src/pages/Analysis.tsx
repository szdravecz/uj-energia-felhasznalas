import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { AnalysisProgressBar } from "@/components/AnalysisProgressBar";
import AnalysisContentSelector from "@/components/AnalysisContentSelector";
import { ChatDownloadInterface } from "@/components/ChatDownloadInterface";

import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { 
  Upload, 
  FileText, 
  Zap, 
  BarChart3, 
  CheckCircle, 
  Clock, 
  AlertTriangle,
  Eye,
  RefreshCw,
  Home,
  Download,
  Settings,
  Database,
  Brain,
  TrendingUp,
  Users,
  ArrowRight,
  Play,
  RotateCcw,
  X,
  Key,
  XCircle,
  Loader2,
  Mail,
  Bug,
  Calculator,
  Settings2
} from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { InvoiceAnalysisService, type ExtractedData } from "@/services/invoiceAnalysisService";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";

// Automatikus hiba javítási szolgáltatás
class AutoRecoveryService {
  static async handlePDFError(file: File, error: any): Promise<string> {
    console.log('PDF hiba automatikus javítás:', error);
    
    // Próbálkozás különböző worker URL-ekkel
    const workerUrls = [
      // Vite environment
      new URL('pdfjs-dist/build/pdf.worker.min.js', import.meta.url).toString(),
      // CDN fallback
      'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js',
      // Alternative CDN
      'https://unpkg.com/pdfjs-dist@3.11.174/build/pdf.worker.min.js'
    ];
    
    for (const workerUrl of workerUrls) {
      try {
        const pdfjsLib = await import('pdfjs-dist');
        pdfjsLib.GlobalWorkerOptions.workerSrc = workerUrl;
        
        const arrayBuffer = await file.arrayBuffer();
        const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
        const page = await pdf.getPage(1);
        const viewport = page.getViewport({ scale: 2.0 });
        
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d')!;
        canvas.height = viewport.height;
        canvas.width = viewport.width;
        
        await page.render({ canvasContext: context, viewport }).promise;
        return canvas.toDataURL('image/png').split(',')[1];
      } catch (retryError) {
        console.log(`Worker URL ${workerUrl} failed:`, retryError);
        continue;
      }
    }
    
    throw new Error('Minden PDF worker URL hibás');
  }
  
  static async handleVisionAPIError(error: any, apiKey: string): Promise<void> {
    console.log('Vision API hiba automatikus elemzés:', error);
    
    if (error.toString().includes('API_KEY_INVALID')) {
      throw new Error('API kulcs érvénytelen - ellenőrizze a Google Cloud Vision API kulcsot');
    }
    
    if (error.toString().includes('QUOTA_EXCEEDED')) {
      throw new Error('API kvóta túllépve - várjon vagy növelje a limiteket');
    }
    
    if (error.toString().includes('BILLING_NOT_ENABLED')) {
      throw new Error('Számlázás nincs engedélyezve a Google Cloud projektben');
    }
    
    // Network hibák esetén retry
    if (error.toString().includes('fetch') || error.toString().includes('network')) {
      await new Promise(resolve => setTimeout(resolve, 2000)); // 2s várakozás
      return; // Retry a hívó kódban
    }
  }
}

interface AnalysisStep {
  id: string;
  title: string;
  description: string;
  status: 'pending' | 'running' | 'completed' | 'error';
  progress: number;
  duration?: number;
  error?: string;
  details?: string;
  estimatedTime?: number;
}

interface DiagnosticInfo {
  timestamp: string;
  step: string;
  message: string;
  type: 'info' | 'warning' | 'error' | 'success';
}

const Analysis = () => {
  const navigate = useNavigate();
  const [userEmail] = useState(localStorage.getItem('userEmail') || '');
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [isDragOver, setIsDragOver] = useState(false);
  const [analysisStarted, setAnalysisStarted] = useState(false);
  const [showDiagnostics, setShowDiagnostics] = useState(false);
  const [showApiConfig, setShowApiConfig] = useState(false);
  const [showContentSettings, setShowContentSettings] = useState(false);
  const [showAdminPanel, setShowAdminPanel] = useState(true);
  
  
  // API kulcsok kezelése
  const [googleVisionApiKey, setGoogleVisionApiKey] = useState(
    localStorage.getItem('googleVisionApiKey') || 'AIzaSyBQOIWfD-Mjo0i0Wj6DdEoUrR_8bei7EKk'
  );
  const [geminiApiKey, setGeminiApiKey] = useState(
    localStorage.getItem('geminiApiKey') || ''
  );
  
  // Debug information
  console.log('🔧 Analysis State Debug:', {
    analysisStarted,
    uploadedFilesCount: uploadedFiles.length,
    hasVisionKey: !!googleVisionApiKey,
    hasGeminiKey: !!geminiApiKey
  });
  
  // Feldolgozási eredmények
  const [extractedData, setExtractedData] = useState<ExtractedData[]>([]);
  const [extractedTexts, setExtractedTexts] = useState<{fileName: string, text: string}[]>([]);
  const [professionalAnalysis, setProfessionalAnalysis] = useState<string>('');
  const [showDataSheet, setShowDataSheet] = useState(false);
  const [showAnalysisSheet, setShowAnalysisSheet] = useState(false);
  const [showOptimizationSheet, setShowOptimizationSheet] = useState(false);
  const [optimizationData, setOptimizationData] = useState<any>(null);
  const [analysisStartTime, setAnalysisStartTime] = useState<number | undefined>();

  // 🔄 SESSION CLEANUP - Előző session adatok törlése
  useEffect(() => {
    console.log('🔄 Analysis komponens betöltve - session cleanup...');
    
    // Csak ha van korábbi adat, akkor töröljük
    if (extractedData.length > 0) {
      console.log(`🔄 Korábbi session ${extractedData.length} számla törlése...`);
      setExtractedData([]);
      setExtractedTexts([]);
      setProfessionalAnalysis('');
      setOptimizationData(null);
      toast.info('Korábbi session adatok törölve - új elemzés indítható');
    }
  }, []); // Csak komponens mount-kor fut le
  
  const [analysisSteps, setAnalysisSteps] = useState<AnalysisStep[]>([
    { 
      id: 'upload', 
      title: 'File feltöltés', 
      description: 'Számla fájlok előkészítése elemzéshez',
      status: 'pending', 
      progress: 0,
      estimatedTime: 1
    },
    { 
      id: 'ocr', 
      title: 'Számlaadatok kiolvasása', 
      description: 'Google Vision API segítségével szöveg kinyerése',
      status: 'pending', 
      progress: 0,
      estimatedTime: 30 // Will be multiplied by file count
    },
    { 
      id: 'ai-analysis', 
      title: 'AI elemzés és feldolgozás', 
      description: 'Gemini AI szakmai elemzése a számlákról',
      status: 'pending', 
      progress: 0,
      estimatedTime: 15
    },
    { 
      id: 'calculation', 
      title: 'Optimalizálási számítások', 
      description: 'Lekötési stratégia és megtakarítás kalkuláció',
      status: 'pending', 
      progress: 0,
      estimatedTime: 2
    },
    { 
      id: 'results', 
      title: 'Eredmények előkészítése', 
      description: 'Végső jelentés összeállítása és navigáció',
      status: 'pending', 
      progress: 0,
      estimatedTime: 1
    }
  ]);

  const [diagnostics, setDiagnostics] = useState<DiagnosticInfo[]>([]);

  // Diagnosztikai log hozzáadása
  const addDiagnostic = (step: string, message: string, type: DiagnosticInfo['type'] = 'info') => {
    const newDiagnostic: DiagnosticInfo = {
      timestamp: new Date().toLocaleTimeString('hu-HU'),
      step,
      message,
      type
    };
    setDiagnostics(prev => [...prev, newDiagnostic]);
  };

  // Lépés státusz frissítése
  const updateStepStatus = (stepId: string, status: AnalysisStep['status'], progress: number = 0, error?: string) => {
    setAnalysisSteps(prev => prev.map(step => 
      step.id === stepId 
        ? { ...step, status, progress, error, duration: status === 'completed' ? Math.random() * 3 + 1 : undefined }
        : step
    ));
  };

  // File upload kezelés
  const handleFileUpload = (files: FileList | null) => {
    if (!files) return;
    
    const pdfFiles = Array.from(files).filter(file => file.type === 'application/pdf');
    
    if (pdfFiles.length === 0) {
      toast.error("Csak PDF fájlokat lehet feltölteni!");
      addDiagnostic('upload', 'Hibás fájl formátum - csak PDF engedélyezett', 'error');
      return;
    }

    if (pdfFiles.length > 12) {
      toast.error("Maximum 12 fájlt lehet feltölteni!");
      addDiagnostic('upload', `Túl sok fájl: ${pdfFiles.length}/12`, 'error');
      return;
    }

    // 🧹 ÚJ SESSION INDÍTÁSA - Minden előző adat törlése új fájl feltöltéskor
    setExtractedData([]);
    setExtractedTexts([]);
    setProfessionalAnalysis('');
    setOptimizationData(null);
    setAnalysisStarted(false);
    
    // Lépések alaphelyzetbe állítása
    setAnalysisSteps([
      { 
        id: 'upload', 
        title: 'File feltöltés', 
        description: 'Számla fájlok előkészítése elemzéshez',
        status: 'pending', 
        progress: 0,
        estimatedTime: 1
      },
      { 
        id: 'ocr', 
        title: 'Számlaadatok kiolvasása', 
        description: 'Google Vision API segítségével szöveg kinyerése',
        status: 'pending', 
        progress: 0,
        estimatedTime: 30
      },
      { 
        id: 'ai-analysis', 
        title: 'AI elemzés és feldolgozás', 
        description: 'Gemini AI szakmai elemzése a számlákról',
        status: 'pending', 
        progress: 0,
        estimatedTime: 15
      },
      { 
        id: 'calculation', 
        title: 'Optimalizálási számítások', 
        description: 'Lekötési stratégia és megtakarítás kalkuláció',
        status: 'pending', 
        progress: 0,
        estimatedTime: 2
      },
      { 
        id: 'results', 
        title: 'Eredmények előkészítése', 
        description: 'Végső jelentés összeállítása és navigáció',
        status: 'pending', 
        progress: 0,
        estimatedTime: 1
      }
    ]);

    setUploadedFiles(pdfFiles); // Teljes reset - csak az új fájlokat tartsuk meg
    updateStepStatus('upload', 'completed', 100);
    addDiagnostic('upload', `🧹 Új session indítva - ${pdfFiles.length} PDF fájl feltöltve`, 'success');
    toast.success(`Új session: ${pdfFiles.length} fájl feltöltve`);
  };

  // Drag & Drop
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    handleFileUpload(e.dataTransfer.files);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  // API kulcsok mentése
  const saveApiKeys = () => {
    localStorage.setItem('googleVisionApiKey', googleVisionApiKey);
    localStorage.setItem('geminiApiKey', geminiApiKey);
    addDiagnostic('config', 'API kulcsok mentve localStorage-ba', 'success');
    toast.success("API kulcsok mentve!");
    setShowApiConfig(false);
  };

  // Tartalom beállítások kezelése
  const handleContentSettingsChange = (categories: any) => {
    addDiagnostic('config', 'Szakmai elemzés tartalom beállítások frissítve', 'success');
    setShowContentSettings(false);
    setShowAdminPanel(false);
  };

  // Admin panel billentyű kombináció kezelése
  useEffect(() => {
    const handleKeyPress = (event: KeyboardEvent) => {
      console.log('🔑 Billentyű esemény:', { ctrlKey: event.ctrlKey, shiftKey: event.shiftKey, key: event.key });
      if (event.ctrlKey && event.shiftKey && event.key === 'A') {
        event.preventDefault();
        console.log('🔧 Admin panel toggle - előtte:', showAdminPanel, 'utána:', !showAdminPanel);
        setShowAdminPanel(!showAdminPanel);
        addDiagnostic('admin', 'Admin panel toggled', 'info');
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [showAdminPanel]);

  // 🧹 Új session indítása funkcióval (explicit hívható)
  const startNewSession = () => {
    console.log('🧹 ÚJ SESSION INDÍTÁS - minden adat törlése');
    
    // State cleanup
    setExtractedData([]);
    setExtractedTexts([]);
    setProfessionalAnalysis('');
    setOptimizationData(null);
    setAnalysisStarted(false);
    setAnalysisStartTime(undefined);
    
    // Browser storage cleanup
    const keysToRemove = ['tempAnalysisData', 'lastAnalysisResults'];
    keysToRemove.forEach(key => {
      localStorage.removeItem(key);
      sessionStorage.removeItem(key);
    });
    
    // Diagnostics reset
    setDiagnostics([]);
    
    // Steps reset
    setAnalysisSteps([
      { 
        id: 'upload', 
        title: 'File feltöltés', 
        description: 'Számla fájlok előkészítése elemzéshez',
        status: 'pending', 
        progress: 0,
        estimatedTime: 1
      },
      { 
        id: 'ocr', 
        title: 'Számlaadatok kiolvasása', 
        description: 'Google Vision API segítségével szöveg kinyerése',
        status: 'pending', 
        progress: 0,
        estimatedTime: 30
      },
      { 
        id: 'ai-analysis', 
        title: 'AI elemzés és feldolgozás', 
        description: 'Gemini AI szakmai elemzése a számlákról',
        status: 'pending', 
        progress: 0,
        estimatedTime: 15
      },
      { 
        id: 'calculation', 
        title: 'Optimalizálási számítások', 
        description: 'Lekötési stratégia és megtakarítás kalkuláció',
        status: 'pending', 
        progress: 0,
        estimatedTime: 2
      },
      { 
        id: 'results', 
        title: 'Eredmények előkészítése', 
        description: 'Végső jelentés összeállítása és navigáció',
        status: 'pending', 
        progress: 0,
        estimatedTime: 1
      }
    ]);
    
    addDiagnostic('system', '🧹 ÚJ SESSION: Minden adat törölve, tiszta lappal indulunk', 'success');
    toast.success("Új session indítva - minden adat törölve");
  };

  // Valódi elemzés indítása
  const startAnalysis = async () => {
    if (uploadedFiles.length === 0) {
      toast.error("Először töltsön fel számlákat!");
      return;
    }

    // 🧹 EGYETLEN TELJES STATE RESET - azonnal az elején
    console.log('🧹 ELEMZÉS INDÍTÁS - state reset ELŐTT:', { 
      extractedDataLength: extractedData.length,
      extractedTextsLength: extractedTexts.length,
      hasAnalysis: !!professionalAnalysis 
    });
    
    startNewSession(); // Teljes cleanup
    
    console.log('🧹 ELEMZÉS INDÍTÁS - state reset UTÁN: tiszta lap');
    addDiagnostic('analysis', `🚀 Elemzés indítása ${uploadedFiles.length} fájllal`, 'info');

    if (!googleVisionApiKey) {
      toast.error("Google Vision API kulcs szükséges!");
      setShowApiConfig(true);
      return;
    }

    setAnalysisStarted(true);
    setAnalysisStartTime(performance.now());
    
    // ⏱️ TELJESÍTMÉNY MÉRÉS KEZDETE
    const analysisStartTime = performance.now();
    const stepTimes: Record<string, {start: number, end?: number, duration?: number}> = {};
    
    try {
      console.log('🚀 ELEMZÉS INDÍTÁS - START');
      // Service inicializálás - ellenőrizzük a Gemini API kulcsot is
      if (!geminiApiKey) {
        addDiagnostic('ai-analysis', '⚠️ Gemini API kulcs hiányzik - szakmai elemzés kihagyva', 'warning');
        toast.warning("Gemini API kulcs szükséges a szakmai elemzéshez!");
      }
      
      console.log('🔑 API kulcsok:', { gemini: !!geminiApiKey, vision: !!googleVisionApiKey });
      const visionService = new InvoiceAnalysisService({ apiKey: geminiApiKey || googleVisionApiKey });
      const analysisService = visionService;
      console.log('✅ Service inicializálva');
      
      // OCR lépés
      stepTimes.ocr = { start: performance.now() };
      updateStepStatus('ocr', 'running', 0);
      addDiagnostic('ocr', '🔍 Google Cloud Vision API inicializálása...', 'info');
      
      const extractedResults: ExtractedData[] = [];
      const textResults: {fileName: string, text: string}[] = [];
      
      for (let i = 0; i < uploadedFiles.length; i++) {
        const file = uploadedFiles[i];
        console.log(`🔍 Feldolgozás: ${file.name} (${i + 1}/${uploadedFiles.length})`);
        const progress = Math.round((i / uploadedFiles.length) * 100);
        
        updateStepStatus('ocr', 'running', progress);
        addDiagnostic('ocr', `Feldolgozás: ${file.name}`, 'info');
        
        try {
          // Próbálkozás OCR-rel, automatikus hiba javítással
          let extractedText = '';
          let retryCount = 0;
          const maxRetries = 3;
          
          while (retryCount < maxRetries) {
            try {
              extractedText = await visionService.extractTextFromPDF(file);
              textResults.push({fileName: file.name, text: extractedText});
              break; // Sikeres, kilépés a retry loop-ból
            } catch (ocrError) {
              retryCount++;
              addDiagnostic('ocr', `Próba ${retryCount}/${maxRetries} - hiba: ${ocrError}`, 'warning');
              
              if (retryCount < maxRetries) {
                // Automatikus hiba javítási kísérlet
                try {
                  await AutoRecoveryService.handleVisionAPIError(ocrError, googleVisionApiKey);
                  addDiagnostic('ocr', 'Automatikus javítás alkalmazva, újrapróbálkozás...', 'info');
                  
                  // Ha PDF worker hiba, próbáljuk meg az AutoRecovery PDF feldolgozóval
                  if (ocrError.toString().includes('pdf') || ocrError.toString().includes('worker')) {
                    addDiagnostic('ocr', 'PDF worker hiba észlelve, automatikus javítás...', 'warning');
                    const base64Image = await AutoRecoveryService.handlePDFError(file, ocrError);
                    
                    // Közvetlen Vision API hívás a javított képpel
                    const response = await fetch(`https://vision.googleapis.com/v1/images:annotate?key=${googleVisionApiKey}`, {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({
                        requests: [{
                          image: { content: base64Image },
                          features: [{ type: 'TEXT_DETECTION', maxResults: 1 }]
                        }]
                      })
                    });
                    
                    const result = await response.json();
                    extractedText = result.responses[0].fullTextAnnotation?.text || '';
                    addDiagnostic('ocr', 'Automatikus PDF javítás sikeres!', 'success');
                    break;
                  }
                } catch (recoveryError) {
                  addDiagnostic('ocr', `Automatikus javítás nem sikerült: ${recoveryError}`, 'error');
                }
              } else {
                throw ocrError; // Maximum próbálkozás elérve
              }
            }
          }
          
          addDiagnostic('ocr', `Szöveg kinyerve: ${extractedText.substring(0, 100)}...`, 'info');
          
          // 📊 SZÖVEG MÉRÉS ÉS MINŐSÉG ELLENŐRZÉS
          addDiagnostic('ocr', `📏 Szöveg hossza: ${extractedText.length} karakter`, 'info');
          if (extractedText.length < 100) {
            addDiagnostic('ocr', '⚠️ Rövid szöveg - rossz minőségű OCR gyanú', 'warning');
          }
          
          // Többszámla elemzés Gemini AI-val
          console.log(`🤖 Gemini AI többszámla elemzés: ${file.name}`);
          console.log(`🔍 SZÁMLÁK SZÁMA ELEMZÉS ELŐTT: ${extractedResults.length}`);
          
          const invoiceDataArray = await analysisService.parseMultipleInvoicesFromText(extractedText);
          console.log(`📊 Kinyert számlák (${file.name}): ${invoiceDataArray.length} db`);
          console.log(`🔍 AI által talált számlák részletei:`, invoiceDataArray);
          
          // 🆔 EGYEDI AZONOSÍTÓ és DEDUPLIKÁCIÓ
          for (const invoiceData of invoiceDataArray) {
            const invoiceWithId = {
              ...invoiceData,
              companyName: invoiceData.companyName || file.name.replace('.pdf', ''),
              fileName: file.name, // PDF fájl nevének nyilvántartása
              _uniqueId: `${Date.now()}_${file.name}_${Math.random().toString(36).substr(2, 9)}`,
              _processedAt: new Date().toISOString(),
              _fileIndex: i
            };
            
            // 🔄 JAVÍTOTT DUPLIKÁCIÓ ELLENŐRZÉS - Számlaszám alapú
            let isDuplicate = false;
            
            // 1. Elsődleges deduplikáció: számlaszám alapján (ha van)
            if (invoiceData.invoiceNumber && invoiceData.invoiceNumber.trim() !== '') {
              isDuplicate = extractedResults.some(existing => 
                existing.invoiceNumber === invoiceData.invoiceNumber
              );
            } else {
              // 2. Ha nincs számlaszám, akkor POD + számlázási időszak alapján
              const duplicateKey = `${invoiceData.podNumber || 'NO_POD'}_${invoiceData.billingPeriod || 'NO_PERIOD'}`;
              isDuplicate = extractedResults.some(existing => 
                `${existing.podNumber || 'NO_POD'}_${existing.billingPeriod || 'NO_PERIOD'}` === duplicateKey
              );
            }
            
            if (isDuplicate) {
              addDiagnostic('ocr', `🔄 DUPLIKÁCIÓ: ${invoiceData.customerName} (Számla: ${invoiceData.invoiceNumber || invoiceData.billingPeriod}) már létezik`, 'warning');
            } else {
              extractedResults.push(invoiceWithId);
              addDiagnostic('ocr', `📋 Számla hozzáadva: ${invoiceData.customerName} (POD: ${invoiceData.podNumber})`, 'info');
            }
          }
          
          console.log(`✅ Hozzáadva ${invoiceDataArray.length} számla (${file.name}) - duplikátumok kiszűrve`);
          console.log(`🔍 SZÁMLÁK SZÁMA ELEMZÉS UTÁN: ${extractedResults.length}`);
          addDiagnostic('ocr', `${invoiceDataArray.length} számla kinyerve (duplikátumok kiszűrve): ${file.name}`, 'success');
          
        } catch (error) {
          addDiagnostic('ocr', `Hiba ${file.name} feldolgozásánál: ${error}`, 'error');
          updateStepStatus('ocr', 'error', progress, `Hiba: ${error}`);
          return;
        }
      }
      
      stepTimes.ocr.end = performance.now();
      stepTimes.ocr.duration = stepTimes.ocr.end - stepTimes.ocr.start;
      updateStepStatus('ocr', 'completed', 100);
      addDiagnostic('ocr', `⏱️ OCR befejezve: ${(stepTimes.ocr.duration / 1000).toFixed(2)}s`, 'info');
      
      // POD konzisztencia ellenőrzése
      const podNumbers = extractedResults.map(data => data.podNumber).filter(Boolean);
      const uniquePods = [...new Set(podNumbers)];
      
      if (uniquePods.length > 1) {
        addDiagnostic('ocr', `⚠️ FIGYELEM: ${uniquePods.length} különböző POD szám észlelve: ${uniquePods.join(', ')}`, 'warning');
        toast.warning(`Különböző POD számok: ${uniquePods.join(', ')}`);
      } else if (uniquePods.length === 1) {
        addDiagnostic('ocr', `✅ Konzisztens POD szám: ${uniquePods[0]}`, 'success');
      }
      
      // Havi számlák ellenőrzése
      if (extractedResults.length > 12) {
        addDiagnostic('ocr', `⚠️ FIGYELEM: Több mint 12 számla (${extractedResults.length}) - optimalizáció pontatlan lehet`, 'warning');
        toast.warning(`${extractedResults.length} számla > 12 hónap!`);
      }
      
      setExtractedData(extractedResults);
      setExtractedTexts(textResults);
      console.log(`🎯 Összesen feldolgozott számlák: ${extractedResults.length}`);
      console.log('📋 Teljes extractedResults:', extractedResults);
      addDiagnostic('ocr', `${extractedResults.length} számla sikeresen feldolgozva (${uploadedFiles.length} fájlból)`, 'success');
      
      console.log('📊 ADATOK BEÁLLÍTVA - Folytatás AI elemzéssel');
      // Gemini AI szakmai elemzés generálása
      stepTimes.analysis = { start: performance.now() };
      updateStepStatus('ai-analysis', 'running', 0);
      addDiagnostic('ai-analysis', '🤖 Gemini AI szakmai elemzés generálása...', 'info');
      console.log('🤖 AI ELEMZÉS INDÍTÁSA...');
      
      try {
        if (!geminiApiKey) {
          addDiagnostic('ai-analysis', '⚠️ Gemini API kulcs hiányzik - szakmai elemzés kihagyva', 'warning');
          setProfessionalAnalysis('Szakmai elemzés nem érhető el - Gemini API kulcs szükséges');
          updateStepStatus('ai-analysis', 'completed', 100);
        } else {
          addDiagnostic('ai-analysis', `🔑 Gemini kulcs ellenőrzése: ${geminiApiKey.substring(0, 20)}...`, 'info');
          const analysis = await analysisService.generateProfessionalAnalysis(extractedResults);
          
          let finalAnalysis = '';
          if (!analysis || analysis.trim() === '') {
            addDiagnostic('ai-analysis', '⚠️ Gemini válasz üres - API probléma vagy hibás kulcs', 'warning');
            finalAnalysis = 'Szakmai elemzés jelenleg nem érhető el - próbálja meg később';
          } else {
            finalAnalysis = analysis;
            console.log('🔄 Analysis.tsx elemzés kész:', analysis.length, 'karakter');
            console.log('🔄 Analysis.tsx analysis változó tartalma:', analysis.substring(0, 200) + '...');
            addDiagnostic('ai-analysis', `✅ Elemzés kész: ${analysis.length} karakter`, 'success');
          }
          
          setProfessionalAnalysis(finalAnalysis);
        }
        
        stepTimes.analysis.end = performance.now();
        stepTimes.analysis.duration = stepTimes.analysis.end - stepTimes.analysis.start;
        updateStepStatus('ai-analysis', 'completed', 100);
      } catch (analysisError) {
        stepTimes.analysis.end = performance.now();
        stepTimes.analysis.duration = stepTimes.analysis.end - stepTimes.analysis.start;
        addDiagnostic('ai-analysis', `❌ Gemini hiba: ${analysisError}`, 'error');
        
        // Hibás API kulcs ellenőrzése
        if (analysisError.toString().includes('API_KEY_INVALID') || 
            analysisError.toString().includes('invalid key') ||
            analysisError.toString().includes('403')) {
          setProfessionalAnalysis('Hibás Gemini API kulcs - ellenőrizze a beállításokat');
          toast.error("Hibás Gemini API kulcs!");
        } else {
          setProfessionalAnalysis(`Szakmai elemzés hiba: ${analysisError}`);
        }
        
        updateStepStatus('ai-analysis', 'completed', 100); // Folytatjuk
      }
      
      // Optimalizációs számítás
      stepTimes.calculation = { start: performance.now() };
      updateStepStatus('calculation', 'running', 0);
      addDiagnostic('calculation', '📊 Lekötés optimalizáció számítása...', 'info');
      
      try {
        const optimizationCalc = generateOptimizationCalculation(extractedResults);
        setOptimizationData(optimizationCalc);
        stepTimes.calculation.end = performance.now();
        stepTimes.calculation.duration = stepTimes.calculation.end - stepTimes.calculation.start;
        addDiagnostic('calculation', `✅ Optimalizáció kész: ${(stepTimes.calculation.duration / 1000).toFixed(2)}s`, 'success');
        updateStepStatus('calculation', 'completed', 100);
      } catch (calcError) {
        stepTimes.calculation.end = performance.now();
        stepTimes.calculation.duration = stepTimes.calculation.end - stepTimes.calculation.start;
        addDiagnostic('calculation', `⚠️ Számítási hiba (${(stepTimes.calculation.duration / 1000).toFixed(2)}s): ${calcError}`, 'warning');
        updateStepStatus('calculation', 'completed', 100); // Folytatjuk
      }
      
      // Befejezés - átirányítás Results oldalra  
      setTimeout(async () => {
        const totalAnalysisTime = performance.now() - analysisStartTime;
        updateStepStatus('results', 'completed', 100);
        
        // ⏱️ TELJESÍTMÉNY JELENTÉS
        const performanceReport = `
📊 TELJESÍTMÉNY JELENTÉS:
• Teljes elemzési idő: ${(totalAnalysisTime / 1000).toFixed(2)}s
• OCR idő: ${stepTimes.ocr?.duration ? (stepTimes.ocr.duration / 1000).toFixed(2) : 'N/A'}s
• AI elemzés idő: ${stepTimes.analysis?.duration ? (stepTimes.analysis.duration / 1000).toFixed(2) : 'N/A'}s  
• Számítás idő: ${stepTimes.calculation?.duration ? (stepTimes.calculation.duration / 1000).toFixed(2) : 'N/A'}s
• Fájlok száma: ${uploadedFiles.length}
• Feldolgozott számlák: ${extractedResults.length}
• Átlag/fájl: ${uploadedFiles.length > 0 ? (totalAnalysisTime / uploadedFiles.length / 1000).toFixed(2) : 'N/A'}s
        `.trim();
        
        console.log(performanceReport);
        addDiagnostic('system', '⏱️ Teljes elemzés befejezve!', 'success');
        addDiagnostic('performance', performanceReport, 'info');
        
        // FRESH elemzés lekérése direktben a navigációhoz  
        let freshAnalysis = '';
        try {
          if (geminiApiKey && extractedResults.length > 0) {
            console.log('🔄 Fresh szakmai elemzés generálása navigációhoz...');
            freshAnalysis = await analysisService.generateProfessionalAnalysis(extractedResults);
            console.log('🎯 Fresh elemzés hossza:', freshAnalysis?.length || 0);
          } else {
            freshAnalysis = professionalAnalysis || 'Szakmai elemzés nem érhető el';
          }
        } catch (error) {
          console.warn('⚠️ Fresh elemzés hiba:', error);
          freshAnalysis = professionalAnalysis || 'Szakmai elemzés nem érhető el';
        }
        
        // Eredmények átadása és navigáció
        console.log('🔍 DEBUG: professionalAnalysis state ellenőrzése');
        console.log('🔍 professionalAnalysis.length:', professionalAnalysis.length);
        console.log('🔍 freshAnalysis.length:', freshAnalysis.length);
        console.log('🔍 freshAnalysis tartalma:', freshAnalysis.substring(0, 300) + '...');
        
        const results = {
          extractedData: extractedResults,
          extractedTexts: textResults,
          professionalAnalysis: freshAnalysis // Fresh elemzést használjuk
        };
        
        console.log('🚀 Navigálás előtt - results objektum:', results);
        console.log('🚀 professionalAnalysis hossza:', professionalAnalysis.length);
        
        toast.success("Elemzés befejezve! Átirányítás az eredményekhez...");
        setTimeout(() => {
          navigate('/results', { state: { results } });
        }, 2000);
      }, 1000);
      
    } catch (error) {
      console.error('❌ KRITIKUS HIBA:', error);
      addDiagnostic('system', `Kritikus hiba: ${error}`, 'error');
      toast.error("Elemzési hiba történt!");
      setAnalysisStarted(false); // Reset analysis state on error
    }
  };

  // Újra teszt funkció - elemzés újraindítása fájlok újratöltése nélkül
  const restartTest = () => {
    // Állapotok resetelése
    setAnalysisStarted(false);
    setExtractedData([]);
    setDiagnostics([]);
    
    // Lépések resetelése (kivéve az upload lépést)
    setAnalysisSteps(prev => prev.map(step => 
      step.id === 'upload' 
        ? step // upload lépést nem reseteljük 
        : { ...step, status: 'pending' as const, progress: 0, error: undefined, duration: undefined }
    ));
    
    addDiagnostic('system', 'Új teszt indítva - fájlok megtartva', 'info');
    toast.success("Új teszt előkészítve!");
  };


  // Fájl eltávolítása
  const removeFile = (index: number) => {
    setUploadedFiles(prev => prev.filter((_, i) => i !== index));
    addDiagnostic('upload', `Fájl eltávolítva: ${uploadedFiles[index]?.name}`, 'info');
  };

  // Optimalizációs számítás generálása - valós adatok nélkül nem elérhető
  const generateOptimizationCalculation = (invoiceData: ExtractedData[]) => {
    // Ellenőrizzük, hogy van-e elegendő valós adat
    const validData = invoiceData.filter(data => 
      data.contractedPower > 0 && 
      data.monthlyMaxPower > 0 &&
      data.systemUsageFee > 0
    );
    
    if (validData.length === 0) {
      throw new Error('Nincs elegendő valós adat az optimalizációhoz. Kérlek tölts fel érvényes számlákat.');
    }

    // Valós adatok feldolgozása
    const avgContractedPower = validData.reduce((sum, data) => sum + data.contractedPower, 0) / validData.length;
    const avgMaxPower = validData.reduce((sum, data) => sum + data.monthlyMaxPower, 0) / validData.length;
    const avgSystemUsageFee = validData.reduce((sum, data) => sum + data.systemUsageFee, 0) / validData.length;

    // Optimalizációs javaslat valós adatok alapján
    const recommendedPower = Math.ceil(avgMaxPower * 1.1); // 10% biztonsági tartalék
    const currentYearlyCost = avgSystemUsageFee * 12;
    const optimizedYearlyCost = (avgSystemUsageFee / avgContractedPower) * recommendedPower * 12;
    const yearlySavings = currentYearlyCost - optimizedYearlyCost;
    const savingsPercentage = (yearlySavings / currentYearlyCost) * 100;

    // Havi bontás valós adatok alapján
    const monthlyData = validData.map((data, i) => {
      const month = data.measurementMonth || `${i + 1}. hónap`;
      const currentContracted = Math.round(data.contractedPower);
      const measuredMax = Math.round(data.monthlyMaxPower);
      const recommendedOptimal = Math.ceil(measuredMax * 1.1);
      const currentCost = Math.round(data.systemUsageFee);
      const optimizedCost = Math.round((currentCost / currentContracted) * recommendedOptimal);
      const monthlySaving = currentCost - optimizedCost;

      return {
        month,
        currentContracted,
        measuredMax,
        recommendedOptimal,
        currentCost,
        optimizedCost,
        monthlySaving,
        excessPower: Math.max(0, measuredMax - currentContracted),
        excessCost: data.exceedanceFee || 0
      };
    });

    return {
      companyName: validData[0]?.companyName || 'Ismeretlen cég',
      customerName: validData[0]?.customerName || 'Ismeretlen ügyfél',
      address: validData[0]?.address || 'Cím nem található',
      tariffType: validData[0]?.tariffType || 'Ismeretlen tarifa',
      yearlyPerformanceFee: Math.round(currentYearlyCost),
      monthlyPerformanceFee: Math.round(currentYearlyCost / 12),
      podNumber: validData[0]?.podNumber || 'POD szám nem található',
      analysisNote: 'Az elemzés valós számlák alapján készült.',
      currentSituation: {
        avgContractedPower: Math.round(avgContractedPower),
        avgMeasuredMax: Math.round(avgMaxPower),
        note: 'Jelenlegi lekötés és tényleges igénybevétel a feltöltött számlák alapján'
      },
      optimization: {
        note: 'Optimalizációs javaslat a tényleges adatok alapján'
      },
      monthlyData,
      summary: {
        totalCurrentCost: Math.round(currentYearlyCost),
        totalOptimizedCost: Math.round(optimizedYearlyCost),
        totalSavings: Math.round(yearlySavings),
        savingsPercentage: Math.round(savingsPercentage),
        recommendation: yearlySavings > 0 
          ? `Javasolt ${Math.round(yearlySavings)} Ft éves megtakarítás (${Math.round(savingsPercentage)}%)` 
          : 'A jelenlegi beállítás optimális'
      }
    };
  };

  const getStepIcon = (step: AnalysisStep) => {
    switch (step.status) {
      case 'completed': return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'running': return <RefreshCw className="h-5 w-5 text-blue-500 animate-spin" />;
      case 'error': return <AlertTriangle className="h-5 w-5 text-red-500" />;
      default: return <Clock className="h-5 w-5 text-gray-400" />;
    }
  };

  const getStepBadgeVariant = (status: AnalysisStep['status']) => {
    switch (status) {
      case 'completed': return 'default';
      case 'running': return 'secondary';
      case 'error': return 'destructive';
      default: return 'outline';
    }
  };

  const getDiagnosticColor = (type: DiagnosticInfo['type']) => {
    switch (type) {
      case 'error': return 'text-red-600';
      case 'warning': return 'text-orange-600';
      case 'success': return 'text-green-600';
      default: return 'text-slate-600';
    }
  };

  const allStepsCompleted = analysisSteps.every(step => step.status === 'completed');

  return (
    <div className="min-h-screen bg-gradient-subtle">
      {/* Header */}
      <header className="bg-white shadow-card border-b">
        <div className="container mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" onClick={() => navigate('/')} className="text-slate-gray">
              <Home className="h-5 w-5 mr-2" />
              Kezdőlap
            </Button>
            <Separator orientation="vertical" className="h-6" />
            <div className="flex items-center space-x-2">
              <Zap className="h-6 w-6 text-energy-blue" />
              <span className="text-xl font-bold text-slate-gray">RHD Elemzés</span>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setShowApiConfig(!showApiConfig)}
              className={!googleVisionApiKey ? 'border-red-500 text-red-600' : ''}
            >
              <Key className="h-4 w-4 mr-2" />
              API Kulcsok
            </Button>
            
            {/* 🧹 Új Session gomb */}
            <Button 
              variant="outline" 
              size="sm"
              onClick={startNewSession}
              className="border-amber-500 text-amber-600 hover:bg-amber-50"
              title="Összes adat törlése és új session indítása"
            >
              <RotateCcw className="h-4 w-4 mr-2" />
              Új Session
            </Button>
            
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setShowDiagnostics(!showDiagnostics)}
              className={showDiagnostics ? 'bg-energy-blue text-white' : ''}
            >
              <Bug className="h-4 w-4 mr-2" />
              Diagnosztika
            </Button>
            {userEmail && (
              <Badge variant="secondary" className="text-sm">
                <Mail className="h-3 w-3 mr-1" />
                {userEmail}
              </Badge>
            )}
          </div>
        </div>
      </header>

      {/* API Kulcsok konfigurációs panel */}
      {showApiConfig && (
        <div className="bg-white border-b shadow-card">
          <div className="container mx-auto px-6 py-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-slate-gray">
                  <Settings className="h-6 w-6 mr-3 text-energy-blue" />
                  API Kulcsok Konfigurálása
                </CardTitle>
                <CardDescription>
                  Adja meg a Google Cloud Vision és Gemini AI API kulcsokat a valódi elemzéshez
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="vision-key">Google Cloud Vision API Kulcs *</Label>
                    <Input
                      id="vision-key"
                      type="password"
                      placeholder="AIzaSyC..."
                      value={googleVisionApiKey}
                      onChange={(e) => setGoogleVisionApiKey(e.target.value)}
                      className="mt-1"
                    />
                    <p className="text-xs text-slate-gray-light mt-1">
                      <a href="https://console.cloud.google.com/apis/credentials" target="_blank" rel="noopener noreferrer" className="text-energy-blue hover:underline">
                        API kulcs beszerzése →
                      </a>
                    </p>
                  </div>
                  <div>
                    <Label htmlFor="gemini-key">Gemini AI API Kulcs</Label>
                    <Input
                      id="gemini-key"
                      type="password"
                      placeholder="AIzaSyD..."
                      value={geminiApiKey}
                      onChange={(e) => setGeminiApiKey(e.target.value)}
                      className="mt-1"
                    />
                    <p className="text-xs text-slate-gray-light mt-1">
                      <a href="https://makersuite.google.com/app/apikey" target="_blank" rel="noopener noreferrer" className="text-energy-blue hover:underline">
                        API kulcs beszerzése →
                      </a>
                    </p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <Button onClick={saveApiKeys} variant="premium" disabled={!googleVisionApiKey}>
                    <Key className="h-4 w-4 mr-2" />
                    Kulcsok mentése
                  </Button>
                  <Button onClick={() => setShowApiConfig(false)} variant="outline">
                    Mégse
                  </Button>
                </div>
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                  <p className="text-sm text-yellow-800">
                    <strong>Biztonsági megjegyzés:</strong> Az API kulcsok a böngésző localStorage-jában kerülnek tárolásra. 
                    Production környezetben használjon biztonságosabb backend megoldást.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      <div className="container mx-auto px-6 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Bal oldal - Feltöltés és Folyamat */}
          <div className="lg:col-span-2 space-y-6">
            {/* POD konzisztencia figyelmeztetés */}
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
              <div className="flex items-start space-x-3">
                <AlertTriangle className="h-5 w-5 text-amber-600 mt-0.5" />
                <div>
                  <h4 className="font-semibold text-amber-800 mb-1">
                    Fontos: Ugyanazon POD számhoz tartozó számlák
                  </h4>
                  <p className="text-sm text-amber-700">
                    Kérjük, csak ugyanazon POD (fogyasztáshely) azonosítóhoz tartozó 12 havi számlát töltsön fel az optimális elemzéshez. 
                    Egy PDF-ben akár több számla is lehet.
                  </p>
                </div>
              </div>
            </div>

            {/* File Upload */}
            <Card className="shadow-card">
              <CardHeader>
                <CardTitle className="flex items-center text-slate-gray">
                  <Upload className="h-6 w-6 mr-3 text-energy-blue" />
                  Számlák feltöltése
                </CardTitle>
                <CardDescription>
                  Töltse fel az elmúlt 12 hónap villamos energia számláit PDF formátumban
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div
                  className={`border-2 border-dashed rounded-xl p-8 text-center transition-all duration-200 ${
                    isDragOver 
                      ? 'border-energy-blue bg-energy-blue/5' 
                      : 'border-neutral-200 hover:border-energy-blue hover:bg-neutral-50'
                  }`}
                  onDrop={handleDrop}
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                >
                  <Upload className="h-12 w-12 mx-auto mb-4 text-energy-blue" />
                  <p className="text-lg font-semibold text-slate-gray mb-2">
                    Húzza ide a PDF fájlokat vagy kattintson a tallózáshoz
                  </p>
                   <p className="text-slate-gray-light mb-4">
                     Maximum 12 fájl, egyenként max 10MB
                   </p>
                  <input
                    type="file"
                    multiple
                    accept=".pdf"
                    onChange={(e) => handleFileUpload(e.target.files)}
                    className="hidden"
                    id="file-upload"
                  />
                  <Button 
                    variant="outline" 
                    className="cursor-pointer"
                    onClick={() => document.getElementById('file-upload')?.click()}
                  >
                    Fájlok kiválasztása
                  </Button>
                </div>

                {/* Feltöltött fájlok listája */}
                {uploadedFiles.length > 0 && (
                  <div className="mt-6">
                    <h4 className="font-semibold text-slate-gray mb-3">
                      Feltöltött fájlok ({uploadedFiles.length}/12)
                    </h4>
                    <div className="space-y-2">
                      {uploadedFiles.map((file, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-neutral-50 rounded-lg">
                          <div className="flex items-center space-x-3">
                            <FileText className="h-5 w-5 text-red-500" />
                            <span className="text-sm text-slate-gray">{file.name}</span>
                            <Badge variant="outline" className="text-xs">
                              {(file.size / 1024 / 1024).toFixed(1)} MB
                            </Badge>
                          </div>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            onClick={() => removeFile(index)}
                            className="text-red-500 hover:text-red-700"
                          >
                            Eltávolítás
                          </Button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {uploadedFiles.length > 0 && !analysisStarted && (
                  <div className="mt-6 space-y-3">
                    <Button 
                      onClick={startAnalysis}
                      variant="premium"
                      size="lg"
                      className="w-full"
                    >
                      <Zap className="h-5 w-5 mr-3" />
                      Elemzés indítása
                    </Button>
                    
                    {/* Debug reset gomb */}
                    <Button 
                      onClick={() => {
                        console.log('🔧 FORCE RESET: analysisStarted előtte:', analysisStarted);
                        setAnalysisStarted(false);
                        console.log('🔧 FORCE RESET: analysisStarted utána:', false);
                        toast.success("State reset!");
                      }}
                      variant="outline"
                      size="sm"
                      className="w-full"
                    >
                      🔧 Force Reset (DEBUG)
                    </Button>
                  </div>
                )}

                {uploadedFiles.length > 0 && (analysisStarted || allStepsCompleted) && (
                  <div className="mt-6">
                    <Button 
                      onClick={restartTest}
                      variant="outline"
                      size="lg"
                      className="w-full"
                    >
                      <RefreshCw className="h-5 w-5 mr-3" />
                      ÚJ TESZT
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Letöltési gombok */}
            <ChatDownloadInterface />

            {/* Elemzési folyamat - Új igényes komponens */}
            {analysisStarted && (
              <AnalysisProgressBar 
                steps={analysisSteps}
                startTime={analysisStartTime}
                totalFiles={uploadedFiles.length}
              />
            )}

            {/* Eredmények - csak valódi elemzés után */}
            {allStepsCompleted && (
              <Card className="shadow-premium border-2 border-energy-blue/20">
                <CardHeader>
                  <CardTitle className="flex items-center text-slate-gray">
                    <CheckCircle className="h-6 w-6 mr-3 text-green-500" />
                    Elemzés befejezve!
                  </CardTitle>
                  <CardDescription>
                    Az RHD optimalizálási javaslatok elkészültek
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-slate-gray-light mb-4">
                    {extractedData.length} számla sikeresen feldolgozva. Tekintse meg a részletes adatokat!
                  </p>
                   
                   <div className="grid md:grid-cols-2 gap-4">
                     <Sheet>
                       <SheetTrigger asChild>
                         <Button variant="outline" className="w-full">
                           <Database className="h-5 w-5 mr-2" />
                           Kinyert adatok megtekintése
                         </Button>
                       </SheetTrigger>
                      <SheetContent className="min-w-[60vw] overflow-y-auto">
                        <SheetHeader>
                          <SheetTitle>Kinyert számla adatok</SheetTitle>
                          <SheetDescription>
                            Google Vision API OCR eredményei és feldolgozott adatok
                          </SheetDescription>
                        </SheetHeader>
                        
                        <Tabs defaultValue="structured" className="mt-6">
                          <TabsList className="grid w-full grid-cols-2">
                            <TabsTrigger value="structured">Strukturált adatok</TabsTrigger>
                            <TabsTrigger value="raw">Nyers OCR szöveg</TabsTrigger>
                          </TabsList>
                          
                          <TabsContent value="structured" className="space-y-6">
                            {extractedData.map((data, index) => (
                              <Card key={index} className="p-4">
                                <div className="flex items-center justify-between mb-4">
                                  <h4 className="font-semibold text-slate-gray">
                                    Számla #{index + 1}: {uploadedFiles[index]?.name}
                                  </h4>
                                  <Badge variant={data.confidence > 0.7 ? "default" : data.confidence > 0.4 ? "secondary" : "destructive"}>
                                    {Math.round(data.confidence * 100)}% megbízhatóság
                                  </Badge>
                                </div>
                                
                                <div className="grid md:grid-cols-2 gap-4 text-sm">
                                  <div className="space-y-3">
                                    <div>
                                      <label className="font-medium text-slate-gray">Szolgáltató:</label>
                                      <p className="text-slate-600 bg-gray-50 p-2 rounded mt-1">
                                        {data.companyName || 'Nem azonosított'}
                                      </p>
                                    </div>
                                    
                                    <div>
                                      <label className="font-medium text-slate-gray">Ügyfél neve:</label>
                                      <p className="text-slate-600 bg-gray-50 p-2 rounded mt-1">
                                        {data.customerName || 'Nem azonosított'}
                                      </p>
                                    </div>
                                    
                                    <div>
                                      <label className="font-medium text-slate-gray">Ügyfél címe:</label>
                                      <p className="text-slate-600 bg-gray-50 p-2 rounded mt-1">
                                        {data.customerAddress || 'Nem azonosított'}
                                      </p>
                                    </div>
                                    
                                    <div>
                                      <label className="font-medium text-slate-gray">Felhasználási hely:</label>
                                      <p className="text-slate-600 bg-gray-50 p-2 rounded mt-1">
                                        {data.address || 'Nem azonosított'}
                                      </p>
                                    </div>
                                    
                                    <div>
                                      <label className="font-medium text-slate-gray">Tarifa típus:</label>
                                      <p className="text-slate-600 bg-gray-50 p-2 rounded mt-1">
                                        {data.tariffType || 'Nem azonosított'}
                                      </p>
                                    </div>
                                    
                                    <div>
                                      <label className="font-medium text-slate-gray">Elszámolási időszak:</label>
                                      <p className="text-slate-600 bg-gray-50 p-2 rounded mt-1">
                                        {data.billingPeriod || 'Nem azonosított'}
                                      </p>
                                    </div>
                                    
                                    <div>
                                      <label className="font-medium text-slate-gray">Adószám:</label>
                                      <p className="text-slate-600 bg-gray-50 p-2 rounded mt-1 font-mono">
                                        {data.taxNumber || 'Nem azonosított'}
                                      </p>
                                    </div>
                                    
                                    <div>
                                      <label className="font-medium text-slate-gray">Számla száma:</label>
                                      <p className="text-slate-600 bg-gray-50 p-2 rounded mt-1 font-mono">
                                        {data.invoiceNumber || 'Nem azonosított'}
                                      </p>
                                    </div>
                                  </div>
                                  
                                  <div className="space-y-3">
                                    <div>
                                      <label className="font-medium text-slate-gray">Számla összesen (bruttó):</label>
                                      <p className="text-slate-600 bg-green-50 p-2 rounded mt-1 font-bold text-lg">
                                        {data.totalAmount > 0 ? `${data.totalAmount.toLocaleString()} Ft` : 'Nem azonosított'}
                                      </p>
                                    </div>
                                    
                                    <div>
                                      <label className="font-medium text-slate-gray">Rendszerhasználati díj (nettó):</label>
                                      <p className="text-slate-600 bg-blue-50 p-2 rounded mt-1 font-semibold">
                                        {data.systemUsageFee > 0 ? `${data.systemUsageFee.toLocaleString()} Ft` : 'Nem azonosított'}
                                      </p>
                                    </div>
                                    
                                    <div>
                                      <label className="font-medium text-slate-gray">Lekötött teljesítmény:</label>
                                      <p className="text-slate-600 bg-blue-50 p-2 rounded mt-1 font-semibold">
                                        {data.contractedPower > 0 ? `${data.contractedPower} kW` : 'Nem azonosított'}
                                      </p>
                                    </div>
                                    
                                    <div>
                                      <label className="font-medium text-slate-gray">Mért maximum teljesítmény:</label>
                                      <p className="text-slate-600 bg-blue-50 p-2 rounded mt-1 font-semibold">
                                        {data.monthlyMaxPower > 0 ? `${data.monthlyMaxPower} kW` : 'Nem azonosított'}
                                      </p>
                                    </div>
                                    
                                    <div>
                                      <label className="font-medium text-slate-gray">Azonosított adatok:</label>
                                      <div className="flex flex-wrap gap-1 mt-1">
                                        {data.companyName !== 'Nem azonosított' && <Badge variant="outline" className="text-xs">Szolgáltató</Badge>}
                                        {data.customerName && <Badge variant="outline" className="text-xs">Ügyfél</Badge>}
                                        {data.totalAmount > 0 && <Badge variant="outline" className="text-xs">Teljes összeg</Badge>}
                                        {data.systemUsageFee > 0 && <Badge variant="outline" className="text-xs">RHD</Badge>}
                                        {data.contractedPower > 0 && <Badge variant="outline" className="text-xs">Lekötött telj.</Badge>}
                                        {data.monthlyMaxPower > 0 && <Badge variant="outline" className="text-xs">Max telj.</Badge>}
                                        {data.tariffType && <Badge variant="outline" className="text-xs">Tarifa</Badge>}
                                        {data.address && <Badge variant="outline" className="text-xs">Cím</Badge>}
                                        {data.taxNumber && <Badge variant="outline" className="text-xs">Adószám</Badge>}
                                        {data.invoiceNumber && <Badge variant="outline" className="text-xs">Számlaszám</Badge>}
                                      </div>
                                    </div>
                                    
                                    <div className="mt-4 p-3 bg-gradient-to-r from-green-50 to-blue-50 rounded-lg border">
                                      <h5 className="font-semibold text-slate-gray mb-2">📊 Számla összefoglaló:</h5>
                                      <div className="text-sm space-y-1">
                                        <p><strong>Nettó RHD:</strong> {data.systemUsageFee.toLocaleString()} Ft</p>
                                        <p><strong>Bruttó összesen:</strong> {data.totalAmount.toLocaleString()} Ft</p>
                                        <p><strong>ÁFA:</strong> {(data.totalAmount - data.systemUsageFee).toLocaleString()} Ft</p>
                                        <p><strong>ÁFA %:</strong> {data.systemUsageFee > 0 ? Math.round(((data.totalAmount - data.systemUsageFee) / data.systemUsageFee) * 100) : 0}%</p>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                                
                                {/* Optimalizálási potenciál */}
                                {data.contractedPower > 0 && data.monthlyMaxPower > 0 && (
                                  <div className="mt-4 p-3 bg-gradient-to-r from-blue-50 to-green-50 rounded-lg border">
                                    <h5 className="font-semibold text-slate-gray mb-2">Optimalizálási lehetőség:</h5>
                                    {data.contractedPower > data.monthlyMaxPower * 1.1 ? (
                                      <p className="text-green-700 text-sm">
                                        ✅ <strong>Csökkentési lehetőség:</strong> A lekötött teljesítmény ({data.contractedPower} kW) 
                                        jelentősen meghaladja a mért maximumot ({data.monthlyMaxPower} kW). 
                                        Javasolt új érték: {Math.ceil(data.monthlyMaxPower * 1.1)} kW
                                      </p>
                                    ) : (
                                      <p className="text-blue-700 text-sm">
                                        ℹ️ <strong>Optimális beállítás:</strong> A lekötött teljesítmény megfelelően van beállítva.
                                      </p>
                                    )}
                                  </div>
                                )}
                              </Card>
                            ))}
                          </TabsContent>
                          
                          <TabsContent value="raw" className="space-y-4">
                            {extractedTexts.map((textData, index) => (
                              <Card key={index} className="p-4">
                                <h4 className="font-semibold text-slate-gray mb-3">
                                  {textData.fileName}
                                </h4>
                                <div className="bg-slate-100 p-4 rounded-lg font-mono text-sm max-h-96 overflow-y-auto">
                                  <pre className="whitespace-pre-wrap text-xs">
                                    {textData.text || 'Nincs kinyert szöveg'}
                                  </pre>
                                </div>
                              </Card>
                            ))}
                          </TabsContent>
                        </Tabs>
                      </SheetContent>
                    </Sheet>
                    
                    <Sheet open={showAnalysisSheet} onOpenChange={setShowAnalysisSheet}>
                      <SheetTrigger asChild>
                        <Button variant="premium" className="w-full" disabled={!professionalAnalysis}>
                          <BarChart3 className="h-5 w-5 mr-2" />
                          Szakmai elemzés megtekintése
                        </Button>
                      </SheetTrigger>
                      <SheetContent className="min-w-[70vw] overflow-y-auto">
                        <SheetHeader>
                          <SheetTitle>Gemini AI Szakmai Elemzés</SheetTitle>
                          <SheetDescription>
                            Részletes szakmai elemzés és optimalizálási javaslatok a kinyert számla adatok alapján
                          </SheetDescription>
                        </SheetHeader>
                        
                        <ScrollArea className="mt-6 h-[85vh]">
                          <div className="prose max-w-none">
                            {professionalAnalysis ? (
                              <div className="whitespace-pre-wrap text-sm leading-relaxed p-4 bg-gray-50 rounded-lg">
                                {professionalAnalysis}
                              </div>
                            ) : (
                              <div className="text-center py-12">
                                <BarChart3 className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                                <p className="text-gray-600">Szakmai elemzés még nem áll rendelkezésre</p>
                                <p className="text-sm text-gray-500 mt-2">Az elemzés generálása az adatok feldolgozása után automatikusan megtörténik</p>
                              </div>
                            )}
                          </div>
                        </ScrollArea>
                      </SheetContent>
                     </Sheet>
                     
                     <Sheet open={showOptimizationSheet} onOpenChange={setShowOptimizationSheet}>
                       <SheetTrigger asChild>
                         <Button variant="outline" className="w-full" disabled={!optimizationData}>
                           <Calculator className="h-5 w-5 mr-2" />
                           Lekötés optimalizáció kalkuláció
                         </Button>
                       </SheetTrigger>
                       <SheetContent className="min-w-[90vw] overflow-y-auto">
                         <SheetHeader>
                           <SheetTitle>Lekötés optimalizáció előzetes kalkuláció</SheetTitle>
                           <SheetDescription>
                             Részletes optimalizációs számítás a feltöltött számlák alapján
                           </SheetDescription>
                         </SheetHeader>
                         
                         {optimizationData && (
                           <div className="mt-6 space-y-6">
                             {/* Header információk */}
                             <div className="grid grid-cols-2 gap-4 p-4 bg-gray-50 rounded-lg">
                               <div>
                                 <div className="flex gap-4 mb-2">
                                   <div>
                                     <label className="font-semibold">Ügyfél:</label>
                                     <p>{optimizationData.companyName}</p>
                                   </div>
                                   <div>
                                     <label className="font-semibold">Telephely:</label>
                                     <p>{optimizationData.address}</p>
                                   </div>
                                 </div>
                                 <div className="flex gap-4">
                                   <div>
                                     <label className="font-semibold">Fordulónap:</label>
                                     <p>nem ismert</p>
                                   </div>
                                   <div>
                                     <label className="font-semibold">Rendszerhasználati tarifa:</label>
                                     <p>{optimizationData.tariffType}</p>
                                   </div>
                                 </div>
                               </div>
                               <div>
                                 <div className="mb-2">
                                   <label className="font-semibold">Éves teljesítmény díj:</label>
                                   <p>{optimizationData.yearlyPerformanceFee.toLocaleString()} Ft/kW/év</p>
                                 </div>
                                 <div className="mb-2">
                                   <label className="font-semibold">Havi teljesítmény díj:</label>
                                   <p>{optimizationData.monthlyPerformanceFee.toLocaleString()} Ft/kW/hó</p>
                                 </div>
                                 <div>
                                   <label className="font-semibold">POD:</label>
                                   <p className="text-sm">{optimizationData.podNumber}</p>
                                 </div>
                               </div>
                             </div>

                             {/* Verzió információk */}
                             <div className="grid grid-cols-2 gap-4 text-sm">
                               <div className="p-3 bg-blue-50 rounded">
                                 <h4 className="font-semibold mb-2">1. verzió:</h4>
                                 <p>{optimizationData.currentSituation.note}</p>
                                 <p className="mt-1">Nem engedélyezett túllépés a lekötésen felüli rész havi teljesítmény díjának a {optimizationData.currentSituation.avgContractedPower}-szorosa</p>
                               </div>
                               <div className="p-3 bg-green-50 rounded">
                                 <h4 className="font-semibold mb-2">2. verzió:</h4>
                                 <p>Javasolt lekötés</p>
                                 <p className="mt-1">{optimizationData.optimization.note}</p>
                               </div>
                             </div>

                             {/* Főtáblázat */}
                             <div className="overflow-x-auto">
                               <table className="w-full border-collapse border border-gray-300 text-sm">
                                 <thead>
                                   <tr className="bg-gray-100">
                                     <th className="border border-gray-300 p-2">Hónap</th>
                                     <th className="border border-gray-300 p-2">Mért maximum teljesítmény (kW)</th>
                                     <th className="border border-gray-300 p-2">Jelenlegi lekötés (kW)</th>
                                     <th className="border border-gray-300 p-2">Díj (Ft)</th>
                                     <th className="border border-gray-300 p-2">Nem engedélyezett túllépés (kW)</th>
                                     <th className="border border-gray-300 p-2">Díj (Ft)</th>
                                     <th className="border border-gray-300 p-2">Javasolt lekötés (kW)</th>
                                     <th className="border border-gray-300 p-2">Díj (Ft)</th>
                                     <th className="border border-gray-300 p-2">Nem engedélyezett túllépés (kW)</th>
                                     <th className="border border-gray-300 p-2">Díj (Ft)</th>
                                     <th className="border border-gray-300 p-2">Engedélyezett túllépés (kW)</th>
                                     <th className="border border-gray-300 p-2">Díj (Ft)</th>
                                   </tr>
                                   <tr className="bg-gray-50 text-center font-semibold">
                                     <td className="border border-gray-300 p-1"></td>
                                     <td className="border border-gray-300 p-1" colSpan={2}>1. verzió</td>
                                     <td className="border border-gray-300 p-1" colSpan={2}>2. verzió</td>
                                   </tr>
                                 </thead>
                                 <tbody>
                                   {optimizationData.monthlyData.map((month, index) => (
                                     <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                                       <td className="border border-gray-300 p-2 font-semibold">{month.month}</td>
                                       <td className="border border-gray-300 p-2 text-center">{month.measuredMax}</td>
                                       <td className="border border-gray-300 p-2 text-center">{month.currentContracted}</td>
                                       <td className="border border-gray-300 p-2 text-right">{month.currentCost.toLocaleString()}</td>
                                       <td className="border border-gray-300 p-2 text-center">{month.excessPower}</td>
                                       <td className="border border-gray-300 p-2 text-right">{month.excessCost.toLocaleString()}</td>
                                       <td className="border border-gray-300 p-2 text-center">{month.recommendedOptimal}</td>
                                       <td className="border border-gray-300 p-2 text-right">{month.optimizedCost.toLocaleString()}</td>
                                       <td className="border border-gray-300 p-2 text-center">0</td>
                                       <td className="border border-gray-300 p-2 text-right">0</td>
                                       <td className="border border-gray-300 p-2 text-center">0</td>
                                       <td className="border border-gray-300 p-2 text-right">0</td>
                                     </tr>
                                   ))}
                                   <tr className="bg-gray-200 font-bold">
                                     <td className="border border-gray-300 p-2">Részösszeg (Ft)</td>
                                     <td className="border border-gray-300 p-2"></td>
                                     <td className="border border-gray-300 p-2"></td>
                                     <td className="border border-gray-300 p-2 text-right">
                                       {optimizationData.monthlyData.reduce((sum, m) => sum + m.currentCost, 0).toLocaleString()}
                                     </td>
                                     <td className="border border-gray-300 p-2"></td>
                                     <td className="border border-gray-300 p-2 text-right">
                                       {optimizationData.monthlyData.reduce((sum, m) => sum + m.excessCost, 0).toLocaleString()}
                                     </td>
                                     <td className="border border-gray-300 p-2"></td>
                                     <td className="border border-gray-300 p-2 text-right">
                                       {optimizationData.monthlyData.reduce((sum, m) => sum + m.optimizedCost, 0).toLocaleString()}
                                     </td>
                                     <td className="border border-gray-300 p-2"></td>
                                     <td className="border border-gray-300 p-2 text-right">0</td>
                                     <td className="border border-gray-300 p-2"></td>
                                     <td className="border border-gray-300 p-2 text-right">0</td>
                                   </tr>
                                   <tr className="bg-gray-300 font-bold">
                                     <td className="border border-gray-300 p-2">Összesen (Ft)</td>
                                     <td className="border border-gray-300 p-2" colSpan={2}></td>
                                     <td className="border border-gray-300 p-2 text-right">
                                       {optimizationData.summary.totalCurrentCost.toLocaleString()}
                                     </td>
                                     <td className="border border-gray-300 p-2" colSpan={4}></td>
                                     <td className="border border-gray-300 p-2 text-right">
                                       {optimizationData.summary.totalOptimizedCost.toLocaleString()}
                                     </td>
                                     <td className="border border-gray-300 p-2" colSpan={2}></td>
                                   </tr>
                                 </tbody>
                               </table>
                             </div>

                             {/* Összefoglaló */}
                             <div className="grid grid-cols-3 gap-4">
                               <div className="p-4 bg-blue-50 rounded-lg text-center">
                                 <h4 className="font-semibold text-blue-800">Éves megtakarítás:</h4>
                                 <p className="text-2xl font-bold text-blue-600">
                                   {optimizationData.summary.totalSavings.toLocaleString()} Ft
                                 </p>
                               </div>
                               <div className="p-4 bg-green-50 rounded-lg text-center">
                                 <h4 className="font-semibold text-green-800">Megtakarítás:</h4>
                                 <p className="text-2xl font-bold text-green-600">
                                   {optimizationData.summary.savingsPercentage}%
                                 </p>
                               </div>
                               <div className="p-4 bg-orange-50 rounded-lg">
                                 <h4 className="font-semibold text-orange-800 mb-2">Javaslat:</h4>
                                 <p className="text-sm text-orange-700">
                                   {optimizationData.summary.recommendation}
                                 </p>
                               </div>
                             </div>

                             <div className="p-4 bg-yellow-50 border-l-4 border-yellow-400">
                               <p className="text-sm font-medium text-yellow-800">
                                 {optimizationData.analysisNote}
                               </p>
                             </div>
                           </div>
                         )}
                       </SheetContent>
                     </Sheet>
                   </div>
                    
                     <div className="mt-4 flex gap-2">
                      <Button 
                        variant="premium" 
                        className="flex-1"
                        disabled={extractedData.length === 0}
                        onClick={() => {
                          console.log('🔘 Manuális navigáció gomb megnyomva');
                          console.log('🔘 professionalAnalysis hossza:', professionalAnalysis.length);
                          console.log('🔘 professionalAnalysis tartalma:', professionalAnalysis.substring(0, 100) + '...');
                          
                          const manualResults = {
                            extractedData,
                            extractedTexts,
                            professionalAnalysis
                          };
                          
                          console.log('🔘 Manuális results objektum:', manualResults);
                          
                          navigate('/results', { 
                            state: { 
                              results: manualResults
                            }
                          });
                        }}
                     >
                       <BarChart3 className="h-5 w-5 mr-2" />
                       Eredmények megtekintése
                     </Button>
                     
                     <Button variant="outline" className="flex-1">
                       <Download className="h-5 w-5 mr-2" />
                       Eredmények letöltése
                     </Button>
                   </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Jobb oldal - Diagnosztika */}
          {showDiagnostics && (
            <div className="space-y-6">
              <Card className="shadow-card">
                <CardHeader>
                  <CardTitle className="flex items-center text-slate-gray">
                    <Bug className="h-6 w-6 mr-3 text-energy-blue" />
                    Diagnosztikai konzol
                  </CardTitle>
                  <CardDescription>
                    Valós idejű rendszer információk és hibakeresés
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="bg-slate-900 rounded-lg p-4 h-96 overflow-y-auto font-mono text-sm">
                    {diagnostics.length === 0 ? (
                      <p className="text-slate-400">Nincsenek diagnosztikai üzenetek...</p>
                    ) : (
                      diagnostics.map((diag, index) => (
                        <div key={index} className="mb-2">
                          <span className="text-slate-400">[{diag.timestamp}]</span>
                          <span className="text-slate-300 ml-2">{diag.step}:</span>
                          <span className={`ml-2 ${getDiagnosticColor(diag.type)}`}>
                            {diag.message}
                          </span>
                        </div>
                      ))
                    )}
                  </div>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="mt-3 w-full"
                    onClick={() => setDiagnostics([])}
                  >
                    Konzol törlése
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}
        </div>

        {/* 🔧 ADMIN CSEKLISTA PANEL - Külön logikai blokk */}
        {showAdminPanel && (
          <div className="mt-8 border-t-4 border-red-500 bg-red-50 p-6 rounded-lg">
            <div className="bg-red-100 border border-red-300 rounded-lg p-4 mb-6">
              <h3 className="text-lg font-bold text-red-800 mb-2 flex items-center gap-2">
                🔧 ADMIN - Elemzés Cseklista Beállítások
                <Badge variant="destructive" className="text-xs">CSAK ADMIN</Badge>
              </h3>
              <p className="text-red-700 text-sm mb-2">
                ⚠️ Ez a panel csak adminok számára látható! (Ctrl+Shift+A)
              </p>
              <p className="text-red-600 text-xs">
                Itt állíthatja be, hogy milyen kategóriákat és alpontokat tartalmazzon az AI-generált elemzés.
              </p>
            </div>
            
            <div className="bg-white rounded-lg border-2 border-red-200 p-4">
              <AnalysisContentSelector 
                onSave={handleContentSettingsChange}
                onClose={() => setShowAdminPanel(false)}
              />
            </div>
            
            <div className="mt-4 flex justify-end">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setShowAdminPanel(false)}
                className="text-red-600 border-red-300 hover:bg-red-50"
              >
                <X className="h-4 w-4 mr-1" />
                Panel bezárása
              </Button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};

export default Analysis;