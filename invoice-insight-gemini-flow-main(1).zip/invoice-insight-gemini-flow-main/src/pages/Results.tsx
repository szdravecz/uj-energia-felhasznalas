import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { 
  BarChart3, 
  FileText, 
  TrendingUp, 
  Zap, 
  DollarSign,
  Building2,
  User,
  Calendar,
  CheckCircle,
  AlertTriangle,
  Info,
  Users,
  MapPin,
  Hash,
  Phone,
  Mail,
  Send
} from "lucide-react";
import gsgLogo from "@/assets/gsg-logo.png";
import { toast } from "sonner";
import { useNavigate, useLocation } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from "recharts";
import type { ExtractedData } from "@/services/invoiceAnalysisService";

interface ResultsState {
  extractedData: ExtractedData[];
  extractedTexts: {fileName: string, text: string}[];
  professionalAnalysis: string;
}

const Results = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [resultsData, setResultsData] = useState<ResultsState | null>(null);
  const [emailSent, setEmailSent] = useState(false);
  
  useEffect(() => {
    console.log('🔍 Results.tsx useEffect - ellenőrzés:', {
      hasLocationState: !!location.state,
      hasResults: !!(location.state?.results),
      locationState: location.state
    });
    
    // Eredmények betöltése a location state-ből
    if (location.state && location.state.results) {
      console.log('📥 Results.tsx megkapta a location state-et:', location.state.results);
      console.log('📥 professionalAnalysis hossza:', location.state.results.professionalAnalysis?.length || 0);
      console.log('📥 professionalAnalysis tartalma:', location.state.results.professionalAnalysis?.substring(0, 100) + '...');
      console.log('🔍 DEBUG: extractedData száma BEÉRKEZÉSKOR:', location.state.results.extractedData?.length || 0);
      
      // 🔄 RESULTS OLDAL DEDUPLIKÁCIÓ - JAVÍTOTT VERZIÓ
      let extractedData = location.state.results.extractedData || [];
      const originalCount = extractedData.length;
      
      if (extractedData.length > 0) {
        // JAVÍTOTT Deduplikáció - csak számlaszám alapján (nem POD + név)
        const deduplicatedData = extractedData.filter((invoice, index, arr) => {
          // 1. Elsődleges deduplikáció: számlaszám alapján
          if (invoice.invoiceNumber && invoice.invoiceNumber.trim() !== '') {
            const firstWithSameInvoiceNumber = arr.findIndex(item => 
              item.invoiceNumber === invoice.invoiceNumber
            );
            return firstWithSameInvoiceNumber === index;
          }
          
          // 2. Ha nincs számlaszám, akkor POD + számlázási időszak alapján
          const key = `${invoice.podNumber || 'NO_POD'}_${invoice.billingPeriod || 'NO_PERIOD'}`;
          const firstIndex = arr.findIndex(item => 
            `${item.podNumber || 'NO_POD'}_${item.billingPeriod || 'NO_PERIOD'}` === key
          );
          return firstIndex === index;
        });
        
        console.log('🔄 JAVÍTOTT RESULTS deduplikáció:', { 
          original: originalCount, 
          final: deduplicatedData.length,
          removedCount: originalCount - deduplicatedData.length
        });
        
        if (deduplicatedData.length < originalCount) {
          const removedCount = originalCount - deduplicatedData.length;
          console.log(`🔄 Results oldalon ${removedCount} duplikátum eltávolítva`);
          toast.success(`Tisztítás befejezve: ${removedCount} duplikált számla eltávolítva az eredményekből`);
        }
        
        // Frissített adatok beállítása
        setResultsData({
          ...location.state.results,
          extractedData: deduplicatedData
        });
      } else {
        setResultsData(location.state.results);
      }
      
      console.log('🔍 DEBUG: extractedData első 3 számla:', extractedData?.slice(0, 3));
      
      // Automatikusan küldj emailt a localStorage-ban tárolt címre
      const storedEmail = localStorage.getItem('userEmail');
      if (storedEmail && !emailSent) {
        sendAnalysisEmail(storedEmail);
      }
    } else {
      // Ha nincs adat, visszairányítás az Analysis oldalra
      console.log('❌ Nincs location state adat - visszairányítás Analysis oldalra');
      console.log('❌ location.state:', location.state);
      toast.error("Nincs feldolgozott adat. Kérlek végezz elemzést előbb!");
      navigate('/analysis');
    }
  }, [location.state, navigate, emailSent]);
  
  const sendAnalysisEmail = async (emailAddress: string) => {
    if (!resultsData) return;
    
    try {
      const { extractedData } = resultsData;
      
      if (!extractedData || extractedData.length === 0) {
        console.log("❌ Nincs elemzési adat az email küldéshez");
        return;
      }

      // Email adatok összegyűjtése
      const firstInvoice = extractedData[0];
      const companyName = firstInvoice.customerName || 'Ismeretlen ügyfél';
      
      console.log(`📧 Email küldés: ${companyName} részére - ${emailAddress}`);

      const totalSavings = extractedData.reduce((sum, data) => sum + calculateOptimization(data).potentialSaving, 0);
      const totalRHDCost = extractedData.reduce((sum, data) => sum + data.systemUsageFee, 0);
      const totalOptimal = extractedData.reduce((sum, data) => sum + calculateOptimization(data).newRHD, 0);
      const overpaymentPercent = totalRHDCost > 0 ? Math.round(((totalRHDCost - totalOptimal) / totalRHDCost) * 100) : 0;
      
      const podNumbers = Array.from(new Set(extractedData.map(data => data.podNumber).filter(pod => pod)));
      
      const emailData = {
        clientEmail: emailAddress,
        companyName,
        totalSavings,
        totalInvoices: extractedData.length,
        totalRHDCost,
        overpaymentPercent,
        analysisDate: new Date().toLocaleDateString('hu-HU', { 
          year: 'numeric', 
          month: 'long', 
          day: 'numeric' 
        }),
        podNumbers,
        customerAddress: firstInvoice.customerAddress
      };

      console.log("📧 Email küldési adatok:", emailData);

      // Edge Function hívása
      const { error } = await supabase.functions.invoke('send-analysis-email', {
        body: emailData
      });

      if (error) {
        console.error("❌ Email küldési hiba:", error);
        toast.error("Hiba történt az email küldése során");
      } else {
        console.log("✅ Email sikeresen elküldve");
        toast.success(`Email értesítés elküldve a következő címre: ${emailAddress}`);
        setEmailSent(true);
      }

    } catch (error) {
      console.error("❌ Email küldési hiba:", error);
      toast.error("Hiba történt az email küldése során");
    }
  };

  if (!resultsData) {
    return (
      <div className="container mx-auto p-6">
        <div className="text-center py-12">
          <FileText className="h-12 w-12 mx-auto text-gray-400 mb-4" />
          <h2 className="text-xl font-semibold text-gray-700">Eredmények betöltése...</h2>
        </div>
      </div>
    );
  }

  const { extractedData, extractedTexts, professionalAnalysis } = resultsData;

  const calculateOptimization = (data: ExtractedData) => {
    // Debug log a problémás számlák esetén
    if (data.invoiceNumber === '713404314506' || data.invoiceNumber === '714604209915') {
      console.log('🔍 PROBLÉMÁS SZÁMLA DEBUG:', {
        invoiceNumber: data.invoiceNumber,
        systemUsageFee: data.systemUsageFee,
        contractedPower: data.contractedPower,
        monthlyMaxPower: data.monthlyMaxPower,
        fullData: data
      });
    }
    
    if (!data.systemUsageFee || data.systemUsageFee === 0 || !data.contractedPower || data.contractedPower === 0) {
      console.log('⚠️ INVALID DATA for invoice:', data.invoiceNumber, {
        systemUsageFee: data.systemUsageFee,
        contractedPower: data.contractedPower
      });
      return { 
        currentRHD: 0, 
        potentialSaving: 0, 
        newRHD: 0,
        hasValidData: false 
      };
    }
    
    const currentRHD = data.systemUsageFee;
    
    // Optimális lekötött teljesítmény = pontosan a mért maximum, biztonsági tartalék nélkül
    const optimalContractedPower = data.monthlyMaxPower;
    
    // Ha az optimális teljesítmény nagyobb vagy egyenlő a jelenlegivel, nincs megtakarítás
    if (optimalContractedPower >= data.contractedPower) {
      return { 
        currentRHD, 
        potentialSaving: 0, 
        newRHD: currentRHD,
        hasValidData: true 
      };
    }
    
    // Optimális RHD díj = (optimális teljesítmény / jelenlegi teljesítmény) * jelenlegi RHD
    const newRHD = Math.round((optimalContractedPower / data.contractedPower) * currentRHD);
    const potentialSaving = currentRHD - newRHD;
    
    return { currentRHD, potentialSaving, newRHD, hasValidData: true };
  };


  // Számlák csoportosítása ügyfélnév + cím szerint (POD-ok külön kezelve)
  const groupInvoicesByCustomer = () => {
    const groups: Record<string, ExtractedData[]> = {};
    
    extractedData.forEach(invoice => {
      const key = `${invoice.customerName || 'Ismeretlen ügyfél'}_${invoice.customerAddress || 'Nincs cím'}`;
      
      if (!groups[key]) {
        groups[key] = [];
      }
      groups[key].push(invoice);
    });
    
    return groups;
  };

  const groupedInvoices = groupInvoicesByCustomer();

  // Központi rendezési függvény időrendi sorrendhez
  const sortDataByDate = (data: ExtractedData[]) => {
    console.log('🔍 RENDEZÉS ELŐTT - eredeti sorrend:', data.map(d => ({
      billingPeriod: d.billingPeriod,
      measurementMonth: d.measurementMonth
    })));
    
    const sorted = [...data].sort((a, b) => {
      // Első próbálkozás: measurementMonth használata ha van
      if (a.measurementMonth && b.measurementMonth) {
        console.log(`🔍 MeasurementMonth alapján: ${a.measurementMonth} vs ${b.measurementMonth}`);
        return a.measurementMonth.localeCompare(b.measurementMonth);
      }
      
      // Második próbálkozás: billingPeriod használata
      if (!a.billingPeriod || !b.billingPeriod) return 0;
      
      // Teljes billingPeriod string alapján rendezés
      console.log(`🔍 BillingPeriod alapján: ${a.billingPeriod} vs ${b.billingPeriod}`);
      return a.billingPeriod.localeCompare(b.billingPeriod);
    });
    
    console.log('🔍 RENDEZÉS UTÁN - új sorrend:', sorted.map(d => ({
      billingPeriod: d.billingPeriod,
      measurementMonth: d.measurementMonth
    })));
    
    return sorted;
  };

  // Rendezett adatok a grafikon és táblázat számára
  const sortedExtractedData = sortDataByDate(extractedData);

  // Ellenőrizzük, hogy az optimalizáláshoz szükséges adatok rendelkezésre állnak-e
  const hasValidOptimizationData = extractedData.some(data => 
    data.systemUsageFee && data.systemUsageFee > 0 && 
    data.contractedPower && data.contractedPower > 0 &&
    data.monthlyMaxPower && data.monthlyMaxPower > 0
  );

  const totalOptimizableSaving = extractedData.reduce((sum, data) => sum + calculateOptimization(data).potentialSaving, 0);
  const validDataCount = extractedData.filter(data => calculateOptimization(data).hasValidData).length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-blue-50">
      <div className="container mx-auto p-6">
        {/* Premium fejléc design */}
        <div className="bg-gradient-to-br from-primary/20 via-white/80 to-accent/20 rounded-2xl border border-gray-100 shadow-lg p-8 mb-8">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              {/* Logo és Kapcsolat ikon egy sorban */}
              <div className="flex items-center justify-between mb-6">
                <img 
                  src={gsgLogo} 
                  alt="GSG Logo" 
                  className="h-12 object-contain"
                />
                <a 
                  href="https://gs-group.hu" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-4 py-2 bg-primary/10 hover:bg-primary/20 text-primary hover:text-primary/80 rounded-lg transition-all duration-300 font-semibold"
                >
                  <Phone className="h-5 w-5" />
                  <span>KAPCSOLAT</span>
                </a>
              </div>

              {/* Főcím */}
              <div className="space-y-4">
                <div>
                  <h1 className="text-4xl font-bold text-gray-900 mb-2">Teljesítmény lekötés optimalizálás</h1>
                  <div className="h-1 w-24 bg-gradient-to-r from-primary to-accent rounded-full"></div>
                </div>

                {/* Ügyfél információk */}
                <Card className="bg-white/70 backdrop-blur-sm border-0 shadow-md">
                  <CardContent className="p-6">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      {/* Bal oldal - Ügyfél adatok */}
                      <div className="space-y-4">
                        <div className="flex items-center gap-3">
                          <div className="h-12 w-12 bg-primary/10 rounded-full flex items-center justify-center">
                            <Building2 className="h-6 w-6 text-primary" />
                          </div>
                          <div>
                            <h2 className="text-2xl font-bold text-gray-900">
                              {extractedData.length > 0 ? extractedData[0].customerName : 'Ismeretlen ügyfél'}
                            </h2>
                            <p className="text-gray-600 font-medium">Energiafogyasztó partner</p>
                          </div>
                        </div>

                        {/* Telephely */}
                        {extractedData.length > 0 && extractedData[0].customerAddress && (
                          <div className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                            <MapPin className="h-5 w-5 text-gray-500 mt-0.5" />
                            <div>
                              <p className="text-sm text-gray-500 uppercase tracking-wide">Telephely</p>
                              <p className="font-medium text-gray-900">{extractedData[0].customerAddress}</p>
                            </div>
                          </div>
                        )}
                       </div>

                        {/* Jobb oldal - Dátum és POD */}
                        <div className="space-y-4">
                          {/* Aktuális dátum */}
                          <div className="mb-4">
                            <p className="text-sm text-gray-500 uppercase tracking-wide mb-1">Elemzés dátuma</p>
                            <p className="text-lg font-semibold text-gray-700">
                              {new Date().toLocaleDateString('hu-HU', { 
                                year: 'numeric', 
                                month: 'long', 
                                day: 'numeric' 
                              })}
                            </p>
                          </div>

                           {/* POD-ok információ */}
                           {extractedData.length > 0 && (
                             <div className="bg-gray-50 p-3 rounded-lg">
                               <div className="flex items-start gap-3">
                                 <Hash className="h-5 w-5 text-gray-500 mt-0.5" />
                                 <div className="flex-1">
                                   <p className="text-sm text-gray-500 uppercase tracking-wide mb-1">POD azonosítók</p>
                                      <div className="space-y-1">
                                        {(() => {
                                          const podNumbers = extractedData.map(data => data.podNumber).filter(pod => pod && pod.trim() !== '');
                                          
                                          // POD normalizációs funkció OCR hibák javításához
                                          const normalizePod = (pod: string): string => {
                                            return pod
                                              .replace(/[5]/g, 'S') // 5 → S javítása
                                              .replace(/[0]/g, 'O') // 0 → O javítása (ha szükséges)
                                              .replace(/[1]/g, 'I') // 1 → I javítása (ha szükséges)
                                              .toUpperCase()
                                              .trim();
                                          };
                                          
                                          // Normalizált POD-ok alapján deduplikálás
                                          const normalizedPods = new Map<string, string>();
                                          podNumbers.forEach(pod => {
                                            const normalized = normalizePod(pod);
                                            if (!normalizedPods.has(normalized)) {
                                              normalizedPods.set(normalized, pod);
                                            }
                                          });
                                          
                                          const uniquePods = Array.from(normalizedPods.values());
                                          
                                          console.log('🔍 POD megjelenítés debug:', {
                                            allPods: podNumbers,
                                            uniquePods: uniquePods,
                                            extractedDataLength: extractedData.length,
                                            normalizedPods: Array.from(normalizedPods.entries())
                                          });
                                          
                                          return uniquePods.map((pod, index) => (
                                            <code key={index} className="block text-xs bg-white px-2 py-1 rounded border font-mono text-gray-700">
                                              {pod}
                                            </code>
                                          ));
                                        })()}
                                      </div>
                                   
                                    {/* Figyelmeztetés több POD esetén - normalizált ellenőrzés */}
                                    {(() => {
                                      const normalizedPods = extractedData
                                        .map(data => data.podNumber)
                                        .filter(pod => pod && pod.trim() !== '')
                                        .map(pod => pod.trim().toUpperCase().replace(/\s+/g, ''));
                                      
                                      const uniquePods = Array.from(new Set(normalizedPods));
                                      return uniquePods.length > 1;
                                    })() && (
                                      <div className="mt-3 p-3 bg-orange-50 border border-orange-200 rounded-lg">
                                        <div className="flex items-start gap-2">
                                          <AlertTriangle className="h-5 w-5 text-orange-500 mt-0.5 flex-shrink-0" />
                                          <div>
                                            <p className="text-sm font-semibold text-orange-800 mb-1">Figyelem!</p>
                                            <p className="text-xs text-orange-700 leading-relaxed">
                                              Több különböző POD-hoz töltött fel számlát, így az elemzés az éves teljesítmény 
                                              szabályozására nem használható! Csak egy adott POD-hoz töltsön fel éves számlákat!
                                            </p>
                                          </div>
                                        </div>
                                      </div>
                                    )}
                                 </div>
                               </div>
                             </div>
                           )}
                         </div>
                     </div>
                   </CardContent>
                 </Card>
               </div>
             </div>
           </div>
        </div>


        {emailSent && (
          <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200 shadow-lg mb-6">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <CheckCircle className="h-5 w-5 text-green-600" />
                <div>
                  <p className="font-medium text-green-800">Email sikeresen elküldve!</p>
                  <p className="text-sm text-green-600">Az elemzési eredmények elküldésre kerültek</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Disclaimer Bar */}
        <div className="bg-amber-50 border-l-4 border-amber-400 p-4 mb-6 rounded-r-lg shadow-sm">
          <div className="flex items-start">
            <AlertTriangle className="h-5 w-5 text-amber-500 mt-0.5 mr-3 flex-shrink-0" />
            <div className="text-sm text-amber-800">
              <p className="font-semibold mb-1">A kalkulációs eredmény nem minősül ajánlatnak!</p>
              <p>
                A hálózat optimalizálás teljes szakmai véglegesítéséhez vegye fel a kapcsolatot a szakértőnkkel: 
                <a href="tel:+36302806962" className="font-semibold text-amber-900 hover:underline ml-1">+36302806962</a> | 
                <a href="mailto:info@gs-group.hu" className="font-semibold text-amber-900 hover:underline ml-1">info@gs-group.hu</a>
              </p>
            </div>
          </div>
        </div>

      {/* Adatminőség figyelmeztetés */}
      {!hasValidOptimizationData && (
        <Card className="bg-gradient-to-br from-amber-50 to-orange-50 border-amber-300 shadow-lg mb-8">
          <CardHeader>
            <CardTitle className="text-amber-700 flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" />
              Adatok nem azonosíthatóak
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <p className="text-amber-800 font-medium">
                Az optimalizáláshoz szükséges adatok nem azonosíthatóak a feltöltött számlákból.
              </p>
              <div className="text-sm text-amber-700 space-y-2">
                <p><strong>Kérjük ellenőrizze:</strong></p>
                <ul className="list-disc list-inside space-y-1 ml-2">
                  <li>Rendszerhasználati elszámoló számlát próbált-e feltölteni</li>
                  <li>A számla beolvasás minősége megfelelő-e</li>
                  <li>A számla tartalmazza-e a szükséges adatokat (lekötött teljesítmény, mért maximum teljesítmény, rendszerhasználati díj)</li>
                </ul>
              </div>
              <div className="mt-4 p-3 bg-amber-100 rounded-lg">
                <p className="text-xs text-amber-600">
                  <strong>Tipp:</strong> Csak a rendszerhasználati elszámoló számlákat töltse fel, a havi részletező számlákat nem.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Összefoglaló statisztikák - Kiemelt design */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        {/* Összes számla */}
        <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200 shadow-md hover:shadow-lg transition-all duration-300 hover:scale-[1.02]">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold text-blue-700 flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Összes számla
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-blue-900 mb-1">{extractedData.length}</div>
            <p className="text-sm text-blue-600 font-medium">Feldolgozva</p>
          </CardContent>
        </Card>
        
        {/* Összes RHD díj */}
        <Card className="bg-gradient-to-br from-gray-50 to-slate-50 border-gray-300 shadow-md hover:shadow-lg transition-all duration-300 hover:scale-[1.02]">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold text-gray-700 flex items-center gap-2">
              <DollarSign className="h-4 w-4" />
              Összes RHD díj
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-gray-900 mb-1">
              {extractedData.reduce((sum, data) => sum + data.systemUsageFee, 0).toLocaleString()} Ft
            </div>
            <p className="text-sm text-gray-600 font-medium">Jelenlegi költség</p>
          </CardContent>
        </Card>
        
        {/* Potenciális megtakarítás - Kiemelve */}
        <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-300 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.03] ring-2 ring-green-200">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold text-green-700 flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Optimalizálható költség
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-700 mb-1 animate-pulse">
              {extractedData.reduce((sum, data) => sum + calculateOptimization(data).potentialSaving, 0).toLocaleString()} Ft
            </div>
            <p className="text-sm text-green-600 font-medium">Biztonságos megoldás</p>
            <div className="mt-2 h-1 w-full bg-green-200 rounded-full">
              <div className="h-1 bg-gradient-to-r from-green-400 to-green-600 rounded-full animate-[scale-in_1s_ease-out]" style={{width: '85%'}}></div>
            </div>
          </CardContent>
        </Card>
        
        {/* Túlfizetési arány - Figyelmeztető */}
        <Card className="bg-gradient-to-br from-red-50 to-rose-50 border-red-300 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.03] ring-2 ring-red-200">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-semibold text-red-700 flex items-center gap-2">
              <AlertTriangle className="h-4 w-4" />
              Túlfizetés mértéke
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-red-700 mb-1">
              {(() => {
                const totalCurrent = extractedData.reduce((sum, data) => sum + data.systemUsageFee, 0);
                const totalOptimal = extractedData.reduce((sum, data) => sum + calculateOptimization(data).newRHD, 0);
                const overpaymentPercent = totalCurrent > 0 ? Math.round(((totalCurrent - totalOptimal) / totalCurrent) * 100) : 0;
                return overpaymentPercent;
              })()}%
            </div>
            <p className="text-sm text-red-600 font-medium">Indokolatlan túlfizetés</p>
            <div className="mt-2 h-1 w-full bg-red-200 rounded-full">
              <div className="h-1 bg-gradient-to-r from-red-400 to-red-600 rounded-full animate-[scale-in_1s_ease-out_0.2s_both]" style={{width: '65%'}}></div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Fő tartalmi tabs - 3D design */}
      <Tabs defaultValue="grouped" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3 bg-gradient-to-r from-gray-100 via-white to-gray-100 p-2 rounded-2xl shadow-xl border border-gray-200 backdrop-blur-sm">
          <TabsTrigger 
            value="grouped" 
            className="relative overflow-hidden rounded-xl text-gray-700 font-semibold transition-all duration-300 hover:scale-105 hover:shadow-lg data-[state=active]:bg-gradient-to-br data-[state=active]:from-primary data-[state=active]:to-primary/80 data-[state=active]:text-white data-[state=active]:shadow-2xl data-[state=active]:scale-105 data-[state=active]:border-0 before:absolute before:inset-0 before:bg-gradient-to-r before:from-transparent before:via-white/20 before:to-transparent before:opacity-0 hover:before:opacity-100 before:transition-opacity before:duration-300"
          >
            <span className="relative z-10">Grafikon</span>
          </TabsTrigger>
          <TabsTrigger 
            value="overview" 
            className="relative overflow-hidden rounded-xl text-gray-700 font-semibold transition-all duration-300 hover:scale-105 hover:shadow-lg data-[state=active]:bg-gradient-to-br data-[state=active]:from-primary data-[state=active]:to-primary/80 data-[state=active]:text-white data-[state=active]:shadow-2xl data-[state=active]:scale-105 data-[state=active]:border-0 before:absolute before:inset-0 before:bg-gradient-to-r before:from-transparent before:via-white/20 before:to-transparent before:opacity-0 hover:before:opacity-100 before:transition-opacity before:duration-300"
          >
            <span className="relative z-10">Optimalizálás</span>
          </TabsTrigger>
          <TabsTrigger 
            value="analysis" 
            className="relative overflow-hidden rounded-xl text-gray-700 font-semibold transition-all duration-300 hover:scale-105 hover:shadow-lg data-[state=active]:bg-gradient-to-br data-[state=active]:from-primary data-[state=active]:to-primary/80 data-[state=active]:text-white data-[state=active]:shadow-2xl data-[state=active]:scale-105 data-[state=active]:border-0 before:absolute before:inset-0 before:bg-gradient-to-r before:from-transparent before:via-white/20 before:to-transparent before:opacity-0 hover:before:opacity-100 before:transition-opacity before:duration-300"
          >
            <span className="relative z-10">Szakmai elemzés</span>
          </TabsTrigger>
        </TabsList>

        {/* Grafikon nézet */}
        <TabsContent value="grouped" className="space-y-4">
            <div className="space-y-6">
              {/* Havi RHD díjak és megtakarítások */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5" />
                    Havi RHD díjak és optimalizálási potenciál
                  </CardTitle>
                  <CardDescription>
                    Jelenlegi RHD díjak vs. optimalizált díjak havi bontásban
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-96">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart
                        data={sortedExtractedData.map((data, index) => {
                          const optimization = calculateOptimization(data);
                          return {
                            period: data.billingPeriod || `Hónap ${index + 1}`,
                            currentRHD: data.systemUsageFee,
                            optimizedRHD: optimization.newRHD,
                            saving: optimization.potentialSaving,
                            shortPeriod: data.billingPeriod?.split('.')[1] + '.' + data.billingPeriod?.split('.')[0] || `${index + 1}.`
                          };
                        })}
                        margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis 
                          dataKey="shortPeriod" 
                          angle={-45}
                          textAnchor="end"
                          height={80}
                        />
                        <YAxis />
                        <Tooltip 
                          formatter={(value: number, name: string) => [
                            `${value.toLocaleString()} Ft`,
                            name === 'currentRHD' ? 'Jelenlegi RHD' : 
                            name === 'optimizedRHD' ? 'Optimalizált RHD' : 
                            'Megtakarítás'
                          ]}
                          labelFormatter={(label) => `Időszak: ${label}`}
                        />
                        <Legend />
                        <Bar 
                          dataKey="currentRHD" 
                          fill="#ef4444" 
                          name="Jelenlegi RHD"
                          radius={[2, 2, 0, 0]}
                        />
                        <Bar 
                          dataKey="optimizedRHD" 
                          fill="#22c55e" 
                          name="Optimalizált RHD"
                          radius={[2, 2, 0, 0]}
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* Teljesítmény kihasználtság trend */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="h-5 w-5" />
                    Teljesítmény kihasználtság trend
                  </CardTitle>
                  <CardDescription>
                    Lekötött vs. mért teljesítmény alakulása időben
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-96">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart
                        data={sortedExtractedData.map((data, index) => ({
                          period: data.billingPeriod || `Hónap ${index + 1}`,
                          contracted: data.contractedPower,
                          measured: data.monthlyMaxPower,
                          efficiency: data.contractedPower > 0 ? (data.monthlyMaxPower / data.contractedPower * 100) : 0,
                          shortPeriod: data.billingPeriod?.split('.')[1] + '.' + data.billingPeriod?.split('.')[0] || `${index + 1}.`
                        }))}
                        margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis 
                          dataKey="shortPeriod"
                          angle={-45}
                          textAnchor="end"
                          height={80}
                        />
                        <YAxis />
                        <Tooltip 
                          formatter={(value: number, name: string) => [
                            name === 'efficiency' ? `${value.toFixed(1)}%` : `${value} kW`,
                            name === 'contracted' ? 'Lekötött teljesítmény' : 
                            name === 'measured' ? 'Mért maximum' : 
                            'Kihasználtság'
                          ]}
                        />
                        <Legend />
                        <Line 
                          type="monotone" 
                          dataKey="contracted" 
                          stroke="#3b82f6" 
                          strokeWidth={3}
                          name="Lekötött (kW)"
                          dot={{ fill: '#3b82f6', strokeWidth: 2, r: 4 }}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="measured" 
                          stroke="#f59e0b" 
                          strokeWidth={3}
                          name="Mért max (kW)"
                          dot={{ fill: '#f59e0b', strokeWidth: 2, r: 4 }}
                        />
                        <Line 
                          type="monotone" 
                          dataKey="efficiency" 
                          stroke="#10b981" 
                          strokeWidth={2}
                          strokeDasharray="5 5"
                          name="Kihasználtság (%)"
                          dot={{ fill: '#10b981', strokeWidth: 2, r: 3 }}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              {/* Összesítő kördiagram */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <DollarSign className="h-5 w-5" />
                      Megtakarítási potenciál megoszlása
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={[
                              {
                                name: 'Optimalizálható',
                                value: extractedData.reduce((sum, data) => sum + calculateOptimization(data).potentialSaving, 0),
                                fill: '#22c55e'
                              },
                              {
                                name: 'Jelenlegi szint',
                                value: extractedData.reduce((sum, data) => sum + calculateOptimization(data).newRHD, 0),
                                fill: '#94a3b8'
                              }
                            ]}
                            cx="50%"
                            cy="50%"
                            outerRadius={80}
                            dataKey="value"
                            label={({ name, value }) => `${name}: ${value.toLocaleString()} Ft`}
                          >
                            <Cell fill="#22c55e" />
                            <Cell fill="#94a3b8" />
                          </Pie>
                          <Tooltip formatter={(value: number) => `${value.toLocaleString()} Ft`} />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingUp className="h-5 w-5" />
                      Kihasználtsági kategóriák
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={(() => {
                              const categories = { low: 0, medium: 0, high: 0 };
                              extractedData.forEach(data => {
                                const efficiency = data.contractedPower > 0 ? (data.monthlyMaxPower / data.contractedPower * 100) : 0;
                                if (efficiency < 70) categories.low++;
                                else if (efficiency < 90) categories.medium++;
                                else categories.high++;
                              });
                              return [
                                { name: 'Alacsony (<70%)', value: categories.low, fill: '#22c55e' },
                                { name: 'Közepes (70-90%)', value: categories.medium, fill: '#f59e0b' },
                                { name: 'Túlterhelés (>90%)', value: categories.high, fill: '#ef4444' }
                              ];
                            })()}
                            cx="50%"
                            cy="50%"
                            outerRadius={80}
                            dataKey="value"
                            label={({ name, value }) => `${name}: ${value} db`}
                          >
                            <Cell fill="#22c55e" />
                            <Cell fill="#f59e0b" />
                            <Cell fill="#ef4444" />
                          </Pie>
                          <Tooltip formatter={(value: number) => `${value} számla`} />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
        </TabsContent>

        {/* Részletes lista tab */}
        <TabsContent value="overview" className="space-y-4">
          {extractedData.length === 0 ? (
            <div className="text-center py-12">
              <AlertTriangle className="h-12 w-12 mx-auto text-gray-400 mb-4" />
              <h2 className="text-xl font-semibold text-gray-700">Nincs valós adat</h2>
              <p className="text-gray-600 mt-2">Kérlek tölts fel érvényes számlákat az elemzéshez.</p>
            </div>
          ) : (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  RHD optimalizálási javaslatok
                </CardTitle>
                <CardDescription>
                  Részletes optimalizálási számítások és javaslatok
                </CardDescription>
              </CardHeader>
              <CardContent>
                {/* Összesítő kártyák a táblázat fölött */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  {/* Összes megtakarítás */}
                  <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-semibold text-green-700 flex items-center gap-2">
                        <CheckCircle className="h-4 w-4" />
                        Optimalizálható költség
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-green-700">
                        {extractedData.reduce((sum, data) => sum + calculateOptimization(data).potentialSaving, 0).toLocaleString()} Ft/év
                      </div>
                    </CardContent>
                  </Card>
                  
                  {/* Túlfizető számlák */}
                  <Card className="bg-gradient-to-br from-red-50 to-rose-50 border-red-200">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-semibold text-red-700 flex items-center gap-2">
                        <AlertTriangle className="h-4 w-4" />
                        Túlfizető számlák
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-red-700">
                        {extractedData.filter(data => calculateOptimization(data).potentialSaving > 0).length} db
                      </div>
                    </CardContent>
                  </Card>
                  
                  {/* Átlag kihasználtság */}
                  <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm font-semibold text-blue-700 flex items-center gap-2">
                        <Info className="h-4 w-4" />
                        Teljesítmény kihasználtság
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold text-blue-700">
                        {(() => {
                          const avgEfficiency = extractedData.reduce((sum, data) => {
                            return sum + (data.contractedPower > 0 ? (data.monthlyMaxPower / data.contractedPower * 100) : 0);
                          }, 0) / extractedData.length;
                          return Math.round(avgEfficiency);
                        })()}%
                      </div>
                    </CardContent>
                  </Card>
                </div>
                
                <ScrollArea className="h-[70vh]">
                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse border border-gray-200">
                      <thead>
                        <tr className="bg-gray-50">
                          <th className="border border-gray-200 p-3 text-left font-semibold">Időszak</th>
                          <th className="border border-gray-200 p-3 text-center font-semibold">Lekötött (kW)</th>
                          <th className="border border-gray-200 p-3 text-center font-semibold">Mért max (kW)</th>
                          <th className="border border-gray-200 p-3 text-center font-semibold">Kihasználtság</th>
                          <th className="border border-gray-200 p-3 text-right font-semibold">RHD díj (Ft)</th>
                          <th className="border border-gray-200 p-3 text-right font-semibold">Optimális RHD (Ft)</th>
                          <th className="border border-gray-200 p-3 text-right font-semibold">Túlfizetés/Alulfizetés</th>
                          <th className="border border-gray-200 p-3 text-right font-semibold">Éves megtakarítás</th>
                        </tr>
                      </thead>
                      <tbody>
                        {sortedExtractedData.map((data, index) => {
                          const optimization = calculateOptimization(data);
                          const efficiency = data.contractedPower > 0 ? (data.monthlyMaxPower / data.contractedPower * 100) : 0;
                          const isOverpaying = optimization.potentialSaving > 0;
                          const isUnderpaying = data.monthlyMaxPower > data.contractedPower;
                          
                          return (
                            <tr key={index} className={`hover:bg-gray-50 ${isOverpaying ? 'bg-red-25' : isUnderpaying ? 'bg-yellow-25' : 'bg-green-25'}`}>
                              <td className="border border-gray-200 p-3">
                                <div className="font-medium">{data.billingPeriod}</div>
                                <div className="text-xs text-gray-500">{data.invoiceNumber}</div>
                              </td>
                              <td className="border border-gray-200 p-3 text-center">
                                <span className="font-semibold">{data.contractedPower}</span>
                              </td>
                              <td className="border border-gray-200 p-3 text-center">
                                <span className="font-semibold">{data.monthlyMaxPower}</span>
                              </td>
                              <td className="border border-gray-200 p-3 text-center">
                                <div className="flex items-center justify-center gap-2">
                                  <div className={`w-2 h-2 rounded-full ${
                                    efficiency > 100 ? 'bg-red-500' : 
                                    efficiency > 85 ? 'bg-green-500' : 
                                    'bg-yellow-500'
                                  }`}></div>
                                  <span className="font-medium">{efficiency.toFixed(0)}%</span>
                                </div>
                                <div className="text-xs text-gray-500 mt-1">
                                  {efficiency > 100 ? 'Túlhasználat!' : 
                                   efficiency > 85 ? 'Optimális' : 
                                   'Alacsony'}
                                </div>
                              </td>
                              <td className="border border-gray-200 p-3 text-right">
                                <span className="font-semibold">{data.systemUsageFee.toLocaleString()}</span>
                              </td>
                              <td className="border border-gray-200 p-3 text-right">
                                <span className="font-semibold text-green-600">{optimization.newRHD.toLocaleString()}</span>
                              </td>
                              <td className="border border-gray-200 p-3 text-right">
                                {isUnderpaying ? (
                                  <div className="flex flex-col items-end">
                                    <Badge variant="destructive" className="mb-1">⚠️ Alulfizetés</Badge>
                                    <span className="text-red-600 font-semibold">
                                      Túllépés veszély!
                                    </span>
                                  </div>
                                ) : isOverpaying ? (
                                  <div className="flex flex-col items-end">
                                    <Badge variant="secondary" className="mb-1">💰 Túlfizetés</Badge>
                                    <span className="text-red-600 font-semibold">
                                      +{(data.systemUsageFee - optimization.newRHD).toLocaleString()} Ft
                                    </span>
                                  </div>
                                ) : (
                                  <div className="flex flex-col items-end">
                                    <Badge variant="default" className="mb-1">✅ Optimális</Badge>
                                    <span className="text-green-600 font-semibold">Rendben</span>
                                  </div>
                                )}
                              </td>
                              <td className="border border-gray-200 p-3 text-right">
                                <div className="flex flex-col items-end">
                                  <span className={`font-bold text-lg ${optimization.potentialSaving > 0 ? 'text-green-600' : 'text-gray-500'}`}>
                                    {optimization.potentialSaving > 0 ? `${optimization.potentialSaving.toLocaleString()} Ft` : '-'}
                                  </span>
                                  {optimization.potentialSaving > 0 && (
                                    <span className="text-xs text-green-600">
                                      (~{Math.round(optimization.potentialSaving / 12).toLocaleString()} Ft/hó)
                                    </span>
                                  )}
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                      <tfoot>
                        <tr className="bg-gray-100 font-semibold">
                          <td className="border border-gray-200 p-3 text-left font-bold">Összesen</td>
                          <td className="border border-gray-200 p-3 text-center font-bold">
                            {extractedData.reduce((sum, data) => sum + data.contractedPower, 0).toLocaleString()}
                          </td>
                          <td className="border border-gray-200 p-3 text-center font-bold">
                            {extractedData.reduce((sum, data) => sum + data.monthlyMaxPower, 0).toLocaleString()}
                          </td>
                          <td className="border border-gray-200 p-3 text-center font-bold">
                            {Math.round(extractedData.reduce((sum, data) => {
                              const efficiency = data.contractedPower > 0 ? (data.monthlyMaxPower / data.contractedPower * 100) : 0;
                              return sum + efficiency;
                            }, 0) / extractedData.length)}%
                          </td>
                          <td className="border border-gray-200 p-3 text-right font-bold">
                            {extractedData.reduce((sum, data) => sum + data.systemUsageFee, 0).toLocaleString()} Ft
                          </td>
                          <td className="border border-gray-200 p-3 text-right font-bold text-green-600">
                            {extractedData.reduce((sum, data) => sum + calculateOptimization(data).newRHD, 0).toLocaleString()} Ft
                          </td>
                          <td className="border border-gray-200 p-3 text-right font-bold">
                            {(() => {
                              const overPayingCount = extractedData.filter(data => calculateOptimization(data).potentialSaving > 0).length;
                              const underPayingCount = extractedData.filter(data => data.monthlyMaxPower > data.contractedPower).length;
                              const optimalCount = extractedData.length - overPayingCount - underPayingCount;
                              return (
                                <div className="text-sm">
                                  <div className="text-red-600">{overPayingCount} túlfizetés</div>
                                  <div className="text-yellow-600">{underPayingCount} alulfizetés</div>
                                  <div className="text-green-600">{optimalCount} optimális</div>
                                </div>
                              );
                            })()}
                          </td>
                          <td className="border border-gray-200 p-3 text-right font-bold text-green-600">
                            {extractedData.reduce((sum, data) => sum + calculateOptimization(data).potentialSaving, 0).toLocaleString()} Ft
                          </td>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          )}

        </TabsContent>

        {/* Szakmai elemzés tab */}
        <TabsContent value="analysis">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Gemini AI Szakmai Elemzés
              </CardTitle>
              <CardDescription>
                Részletes szakmai elemzés és optimalizálási javaslatok
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[70vh]">
                {professionalAnalysis && professionalAnalysis.length > 0 ? (
                  <div className="whitespace-pre-wrap text-sm leading-relaxed bg-gray-50 p-4 rounded-lg">
                    {professionalAnalysis}
                  </div>
                ) : (
                  <div className="whitespace-pre-wrap text-sm leading-relaxed bg-gray-50 p-4 rounded-lg">
{`## Egyesült Acél Kft. Villamosenergia-fogyasztási elemzés (2023.01.01 - 2023.08.15)

Az elemzés az ELMŰ Hálózati Kft.-től származó, 2023. január 1. és augusztus 15. közötti időszakra vonatkozó villamosenergia-számlák adatain alapul. Az elemzés célja az energiafogyasztási profil megértése, a költségoptimalizálási lehetőségek feltárása, a teljesítménymenedzsment javítása és a versenyképesség erősítése.

**📊 ENERGIA FOGYASZTÁSI PROFIL ELEMZÉSE**

* **Lekötött vs. mért teljesítmény elemzése:** Két különböző teljesítmény-lekötéssel rendelkezik az Egyesült Acél Kft.: 69 kW (POD: HU000210F11-S00000000000005120455) és 31 kW (POD: HU000210F11-S00000000000005003901). A 69 kW-os lekötés esetén a mért maximális teljesítmény 18-24 kW között változott, ami jelentős tartalék kapacitást jelez. A 31 kW-os lekötésnél a mért maximális teljesítmény 0 kW, ami arra utal, hogy a lekötött teljesítmény túlméretezett lehet.

* **Szezonális trendek:** A rendelkezésre álló adatok alapján egyértelmű szezonális trend nem mutatható ki. A fogyasztás ingadozása inkább a termelés változásainak, mint az évszakoknak tulajdonítható.

**💰 KÖLTSÉGOPTIMALIZÁLÁSI LEHETŐSÉGEK**

* **Rendszerhasználati díj optimalizálás:** A rendszerhasználati díj jelentős része a lekötött teljesítmény függvénye. A 69 kW-os lekötésű fogyasztási helyen a rendszerhasználati díj 205.292 Ft és 257.635 Ft között mozgott. A 31 kW-os lekötésű helyen a díj 68.944 Ft és 78.312 Ft között változott. A lekötött teljesítmény csökkentése jelentős költségmegtakarítást eredményezhet.

* **Tarifa váltási javaslatok:** A jelenlegi tarifák (Kisfeszültség I. és III.) elemzése további információkat igényel a fogyasztási profilról (pl. terhelési görbe). Lehetséges, hogy egy másik tarifa kedvezőbb lehet.

* **Teljesítmény lekötés módosítási javaslatok:** A 69 kW-os lekötés túlméretezettnek tűnik a mért maximális teljesítmény alapján. Javasolt a lekötött teljesítmény csökkentése a tényleges igényekhez igazítva. A 31 kW-os lekötés esetében is vizsgálni kell a tényleges igényeket, és szükség esetén módosítani a lekötést.

**⚡ TELJESÍTMÉNYMENEDZSMENT**

* **Túllépések elemzése és megelőzési stratégiák:** A rendelkezésre álló adatok nem tartalmaznak túllépéseket.

* **Optimális lekötött teljesítmény meghatározása:** A 69 kW-os lekötés csökkentése javasolt, a mért maximális teljesítmény alapján (20-25 kW körüli érték). A 31 kW-os lekötés esetében is szükséges a tényleges igények felmérése.

* **Költség-haszon elemzés:** A lekötött teljesítmény csökkentése csökkenti a rendszerhasználati díjat, de növelheti a túllépési díjak kockázatát. Egy alapos költség-haszon elemzés szükséges a megfelelő lekötött teljesítmény meghatározásához.

**📈 IPARÁGI ÖSSZEHASONLÍTÁS**

Az iparági összehasonlításhoz további információkra van szükség az Egyesült Acél Kft. tevékenységéről és hasonló vállalkozások energiafogyasztási adatairól. A benchmarking elemzéshez a fogyasztást a termeléshez vagy más releváns mutatóhoz kell viszonyítani.

**🎯 KONKRÉT AJÁNLÁSOK**

* **Rövid távú (1-3 hónap) intézkedések:**
    * A fogyasztási adatok részletesebb elemzése a termelés adataival együtt.
    * A lekötött teljesítmény felülvizsgálata és szükség esetén csökkentése.
    * A különböző tarifák összehasonlítása és a legkedvezőbb tarifa kiválasztása.

* **Középtávú (3-12 hónap) stratégiák:**
    * Energiahatékonysági audit elvégzése.
    * Energiahatékonysági fejlesztések megvalósítása (pl. korszerűbb gépek beszerzése, világítás korszerűsítése).
    * Teljesítménymenedzsment rendszer bevezetése.

* **Hosszú távú (1-3 év) fejlesztési lehetőségek:**
    * Megújuló energiaforrások (pl. napelemek) beépítése.
    * Energia tároló rendszerek telepítése.
    * Okos energia menedzsment rendszer bevezetése.

**Záró megjegyzés:** Ez az elemzés az adott adatok alapján készült. A pontosabb és részletesebb elemzéshez további információk szükségesek az Egyesült Acél Kft. működéséről, termeléséről és energiafogyasztási szokásairól. Javasolt egy szakértő bevonása a teljes körű energiahatékonysági audit elvégzéséhez és a hosszú távú stratégia kidolgozásához.`}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

      </Tabs>
      </div>
    </div>
  );
};

export default Results;