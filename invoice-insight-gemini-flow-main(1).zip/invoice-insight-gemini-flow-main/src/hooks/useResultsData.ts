import { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import type { ExtractedData } from "@/services/invoiceAnalysisService";

interface ResultsData {
  extractedData: ExtractedData[];
  extractedTexts: {fileName: string, text: string}[];
  professionalAnalysis: string;
}

export const useResultsData = () => {
  const location = useLocation();
  const [resultsData, setResultsData] = useState<ResultsData | null>(null);
  
  useEffect(() => {
    if (location.state && location.state.results) {
      // Deduplikáció alkalmazása ugyanúgy, mint a Results komponensben
      let extractedData = location.state.results.extractedData || [];
      
      if (extractedData.length > 0) {
        const deduplicatedData = extractedData.filter((invoice: ExtractedData, index: number, arr: ExtractedData[]) => {
          if (invoice.invoiceNumber && invoice.invoiceNumber.trim() !== '') {
            const firstWithSameInvoiceNumber = arr.findIndex(item => 
              item.invoiceNumber === invoice.invoiceNumber
            );
            return firstWithSameInvoiceNumber === index;
          }
          
          const key = `${invoice.podNumber || 'NO_POD'}_${invoice.billingPeriod || 'NO_PERIOD'}`;
          const firstIndex = arr.findIndex(item => 
            `${item.podNumber || 'NO_POD'}_${item.billingPeriod || 'NO_PERIOD'}` === key
          );
          return firstIndex === index;
        });
        
        setResultsData({
          ...location.state.results,
          extractedData: deduplicatedData
        });
      } else {
        setResultsData(location.state.results);
      }
    }
  }, [location.state]);
  
  return resultsData;
};