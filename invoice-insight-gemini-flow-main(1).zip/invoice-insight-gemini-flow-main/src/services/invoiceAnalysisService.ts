import { VisionOcrService } from './visionOcrService';
import { GeminiParser } from './gemini/GeminiParser';
import { RegexParser } from './regexParser';
import type { ExtractedData, ApiConfig } from '../types/invoice';
import { DEFAULT_API_KEY } from '../types/invoice';

export class InvoiceAnalysisService {
  private visionService: VisionOcrService;
  private geminiParser: GeminiParser;

  constructor(config?: ApiConfig) {
    const apiConfig = config || { apiKey: DEFAULT_API_KEY };
    console.log('🔑 InvoiceAnalysisService API kulcs:', apiConfig.apiKey ? 'van' : 'nincs');
    this.visionService = new VisionOcrService(apiConfig);
    this.geminiParser = new GeminiParser(apiConfig);
  }

  // PDF szöveg kinyerése OCR-rel
  async extractTextFromPDF(file: File): Promise<string> {
    return await this.visionService.extractTextFromPDF(file);
  }

  // Intelligens számlaelemzés Gemini AI-val, regex fallback-kel
  async parseInvoiceData(extractedText: string): Promise<ExtractedData> {
    try {
      // Először próbáljuk Gemini AI-val
      return await this.geminiParser.parseInvoiceData(extractedText);
    } catch (error) {
      console.warn('⚠️ Gemini AI sikertelen, regex fallback használata:', error);
      // Fallback regex-alapú elemzésre
      return RegexParser.parseInvoiceData(extractedText);
    }
  }

  // Több számla kezelése egy PDF-ben
  async parseMultipleInvoicesFromText(extractedText: string): Promise<ExtractedData[]> {
    try {
      console.log('📄 Többszámla elemzés indítása PDF szövegből...');
      return await this.geminiParser.parseMultipleInvoices(extractedText);
    } catch (error) {
      console.warn('⚠️ Gemini többszámla elemzés sikertelen, fallback egyetlen számlára:', error);
      // Fallback egyetlen számla feldolgozásra
      const singleInvoice = await this.parseInvoiceData(extractedText);
      return [singleInvoice];
    }
  }

  // Szakmai elemzés generálása
  async generateProfessionalAnalysis(extractedData: ExtractedData[], enabledCategories?: any[]): Promise<string> {
    return await this.geminiParser.generateProfessionalAnalysis(extractedData, enabledCategories);
  }
}

// Backward compatibility - régi GoogleVisionService export
export { InvoiceAnalysisService as GoogleVisionService };

// Type exports
export type { ExtractedData, ApiConfig as GoogleVisionConfig } from '../types/invoice';