import { GoogleGenerativeAI } from '@google/generative-ai';
import type { ExtractedData } from '../../types/invoice';
import { parseNumber, parseGeminiResponse } from './utils';

export class InvoiceParser {
  private genAI: GoogleGenerativeAI;

  constructor(genAI: GoogleGenerativeAI) {
    this.genAI = genAI;
  }

  // Egyetlen számla adatok kinyerése AI-val
  async parseSingleInvoice(text: string): Promise<ExtractedData> {
    try {
      console.log('🤖 Gemini AI egyetlen számla elemzés indítása...');
      
      const model = this.genAI.getGenerativeModel({ 
        model: "gemini-1.5-flash",
        generationConfig: {
          temperature: 0.1,
          topP: 0.8,
          topK: 40
        }
      });
      
      const prompt = `
Elemezd ezt a magyar villamos energia számlát és azonosítsd be az összes lekötés optimalizációhoz szükséges adatot. Add vissza JSON formátumban:

{
  "companyName": "szolgáltató neve",
  "address": "szolgáltató címe", 
  "monthlyMaxPower": "mért maximum teljesítmény kW-ban (szám)",
  "contractedPower": "lekötött teljesítmény kW-ban (szám)",
  "systemUsageFee": "rendszerhasználati díj Ft-ban (szám)",
  "tariffType": "tarifa típusa (pl. KIF III.)",
  "billingPeriod": "számlázási időszak",
  "totalAmount": "számla végösszeg Ft-ban (szám)",
  "customerName": "ügyfél neve",
  "customerAddress": "ügyfél címe", 
  "taxNumber": "adószám",
  "invoiceNumber": "számla szám",
  "performanceFeeUnit": "teljesítmény díj Ft/kW/hó egységárban (szám)",
  "yearlyPerformanceFee": "éves teljesítmény díj Ft/kW/év egységárban (szám)",
  "podNumber": "POD azonosító (HU kezdetű kód)",
  "exceedanceAmount": "túllépés mértéke kW-ban (szám, 0 ha nincs)",
  "exceedanceFee": "túllépési díj Ft-ban (szám, 0 ha nincs)",
  "actualEnergyConsumption": "tényleges energia fogyasztás kWh-ban (szám)",
  "energyFee": "energia díj Ft-ban (szám)",
  "networkUsageFee": "hálózathasználati díj Ft-ban (szám)",
  "measurementMonth": "mérési hónap (pl. 2024 január)",
  "billingDays": "számlázási napok száma (szám)"
}

KERESENDŐ KULCSSZAVAK:
- Lekötött teljesítmény, szerződött teljesítmény
- Mért maximum, mért maximum teljesítmény  
- Teljesítmény díj, havi teljesítmény díj
- POD szám, fogyasztáshely azonosító
- Túllépés, túllépési díj
- Rendszerhasználati díj
- Hálózathasználati díj
- Energia díj, villamos energia díj

Számla szöveg:
${text}

FONTOS: Csak JSON formátumban válaszolj, semmi más szöveget ne írj! Ha egy adat nem található, használj 0-t számoknál és üres stringet szövegeknél.`;

      const result = await model.generateContent(prompt);
      const response = await result.response;
      const responseText = response.text();
      
      console.log('🤖 Gemini AI válasz:', responseText);
      
      try {
        const aiData = parseGeminiResponse(responseText);
        
        const result: ExtractedData = {
          companyName: aiData.companyName || '',
          address: aiData.address || '',
          monthlyMaxPower: parseNumber(aiData.monthlyMaxPower),
          contractedPower: parseNumber(aiData.contractedPower),
          systemUsageFee: parseNumber(aiData.systemUsageFee),
          tariffType: aiData.tariffType || '',
          billingPeriod: aiData.billingPeriod || '',
          totalAmount: parseNumber(aiData.totalAmount),
          customerName: aiData.customerName || '',
          customerAddress: aiData.customerAddress || '',
          taxNumber: aiData.taxNumber || '',
          invoiceNumber: aiData.invoiceNumber || '',
          confidence: 0.9,
          performanceFeeUnit: parseNumber(aiData.performanceFeeUnit),
          yearlyPerformanceFee: parseNumber(aiData.yearlyPerformanceFee),
          podNumber: aiData.podNumber || '',
          exceedanceAmount: parseNumber(aiData.exceedanceAmount),
          exceedanceFee: parseNumber(aiData.exceedanceFee),
          actualEnergyConsumption: parseNumber(aiData.actualEnergyConsumption),
          energyFee: parseNumber(aiData.energyFee),
          networkUsageFee: parseNumber(aiData.networkUsageFee),
          measurementMonth: aiData.measurementMonth || '',
          billingDays: parseNumber(aiData.billingDays) || 30
        };
        
        console.log('🎯 Gemini AI eredmény:', result);
        return result;
        
      } catch (parseError) {
        console.error('❌ Gemini JSON parse hiba:', parseError);
        throw parseError;
      }
      
    } catch (error) {
      console.error('❌ Gemini AI hiba:', error);
      throw error;
    }
  }
}