import { GoogleGenerativeAI } from '@google/generative-ai';
import type { EnergyConsumptionData, ApiConfig } from '../../types/energyConsumption';

export class EnergyGeminiParser {
  private genAI: GoogleGenerativeAI;

  constructor(config: ApiConfig) {
    console.log('🔑 EnergyGeminiParser konstruktor - API kulcs:', config.apiKey ? `${config.apiKey.substring(0, 20)}...` : 'NINCS');
    this.genAI = new GoogleGenerativeAI(config.apiKey);
  }

  // Energia számla adatok kinyerése AI-val
  async parseEnergyInvoiceData(text: string): Promise<EnergyConsumptionData> {
    try {
      console.log('🤖 Gemini AI energia számla elemzés indítása...');
      
      const model = this.genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
      
      const prompt = `
Elemezd a következő magyar energia számlát és nyerd ki a következő információkat JSON formátumban:

{
  "companyName": "Energia szolgáltató neve",
  "address": "Szolgáltató címe",
  "customerName": "Ügyfél neve",
  "customerAddress": "Ügyfél címe",
  "taxNumber": "Adószám",
  "invoiceNumber": "Számlaszám",
  "energyConsumption": 0,
  "energyConsumptionDay": 0,
  "energyConsumptionNight": 0,
  "energyConsumptionPeak": 0,
  "maxPowerDemand": 0,
  "averagePowerDemand": 0,
  "contractedPower": 0,
  "totalCost": 0,
  "energyCost": 0,
  "networkCost": 0,
  "systemUsageFee": 0,
  "tariffType": "Tarifa típusa",
  "billingPeriod": "Számlázási időszak",
  "billingDays": 30,
  "measurementMonth": "Mérési hónap",
  "co2Emissions": 0,
  "renewableEnergyPercentage": 0,
  "confidence": 85
}

Fontos szabályok:
1. Minden numerikus értéket számként adj meg (ne string-ként)
2. Az energyConsumption kWh-ban
3. A teljesítmény értékek kW-ban
4. A költségek forintban
5. A co2Emissions kg-ban (becslés: 0.3 kg CO2/kWh)
6. A renewableEnergyPercentage százalékban (ha nincs adat, 0)
7. Ha nem találsz adatot, használj 0 értéket vagy "Ismeretlen" szöveget
8. A confidence 0-100 közötti érték legyen

Számla szöveg:
${text}

Csak a JSON választ add vissza, semmi mást:`;

      const result = await model.generateContent(prompt);
      const response = await result.response;
      const generatedText = response.text();
      
      console.log('🤖 Gemini AI válasz:', generatedText);
      
      // JSON parse
      const cleanedResponse = generatedText.replace(/```json\s*|\s*```/g, '').trim();
      const extractedData = JSON.parse(cleanedResponse);
      
      console.log('📊 Kinyert energia adatok:', extractedData);
      
      return extractedData as EnergyConsumptionData;
      
    } catch (error) {
      console.error('❌ Gemini AI energia elemzés hiba:', error);
      throw error;
    }
  }

  // Több számla kezelése egy PDF-ben
  async parseMultipleEnergyInvoices(text: string): Promise<EnergyConsumptionData[]> {
    try {
      console.log('📄 Több energia számla elemzés indítása...');
      
      const model = this.genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
      
      const prompt = `
Elemezd a következő szöveget és határozd meg, hogy több energia számla van-e benne.
Ha igen, külön-külön elemezd mindegyiket és adj vissza egy JSON tömböt.

Minden számla esetén nyerd ki:
- companyName, address, customerName, customerAddress, taxNumber, invoiceNumber
- energyConsumption, energyConsumptionDay, energyConsumptionNight, energyConsumptionPeak
- maxPowerDemand, averagePowerDemand, contractedPower
- totalCost, energyCost, networkCost, systemUsageFee
- tariffType, billingPeriod, billingDays, measurementMonth
- co2Emissions (becslés: 0.3 kg CO2/kWh)
- renewableEnergyPercentage (ha nincs adat, 0)
- confidence (0-100)

Szöveg:
${text}

JSON tömb formátumban add vissza:`;

      const result = await model.generateContent(prompt);
      const response = await result.response;
      const generatedText = response.text();
      
      console.log('🤖 Gemini AI többszámla válasz:', generatedText);
      
      // JSON parse
      const cleanedResponse = generatedText.replace(/```json\s*|\s*```/g, '').trim();
      const extractedData = JSON.parse(cleanedResponse);
      
      // Ha nem tömb, akkor egyelemű tömbbé alakítjuk
      const dataArray = Array.isArray(extractedData) ? extractedData : [extractedData];
      
      console.log(`📊 Kinyert energia számlák: ${dataArray.length} db`);
      
      return dataArray as EnergyConsumptionData[];
      
    } catch (error) {
      console.error('❌ Gemini AI többszámla elemzés hiba:', error);
      throw error;
    }
  }

  // Energia hatékonysági elemzés generálása
  async generateEnergyAnalysis(extractedData: EnergyConsumptionData[], enabledCategories?: any[]): Promise<string> {
    try {
      console.log('📊 Energia hatékonysági elemzés generálása...');
      
      const model = this.genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
      
      const dataString = JSON.stringify(extractedData, null, 2);
      const categoriesString = enabledCategories ? JSON.stringify(enabledCategories, null, 2) : '';
      
      const prompt = `
Készíts részletes energia hatékonysági elemzést a következő adatok alapján:

ENERGIA FOGYASZTÁSI ADATOK:
${dataString}

ELEMZÉSI KATEGÓRIÁK:
${categoriesString || 'Minden kategória elemzése'}

ELEMZÉS TARTALMA:
1. ÖSSZEFOGLALÓ
   - Összes energia fogyasztás
   - Átlagos havi fogyasztás
   - CO2 kibocsátás összesítés
   - Költségek elemzése

2. HATÉKONYSÁGI ÉRTÉKELÉS
   - Energia hatékonysági osztályba sorolás (A-G)
   - Hasonló méretű fogyasztókhoz képest
   - Szezonális fogyasztási minták

3. KÖLTSÉGOPTIMALIZÁLÁS
   - Tarifaváltási lehetőségek
   - Csúcsidei fogyasztás optimalizálása
   - Hálózati díj csökkentési lehetőségek

4. KÖRNYEZETVÉDELMI ASPEKTUS
   - CO2 kibocsátás csökkentési lehetőségek
   - Megújuló energia források ajánlása
   - Fenntarthatósági javaslatok

5. GYAKORLATI JAVASLATOK
   - Rövid távú intézkedések
   - Hosszú távú beruházások
   - Várható megtakarítások

6. KÖVETKEZTETÉSEK
   - Prioritási sorrend
   - Beruházási javaslatok
   - Megtérülési számítások

Használj szakmai kifejezéseket, konkrét számokat és gyakorlati tanácsokat.
A válasz legyen részletes, de könnyen érthető magyar nyelven.`;

      const result = await model.generateContent(prompt);
      const response = await result.response;
      const generatedText = response.text();
      
      console.log('📊 Energia elemzés elkészült:', generatedText.length, 'karakter');
      
      return generatedText;
      
    } catch (error) {
      console.error('❌ Energia elemzés generálási hiba:', error);
      throw error;
    }
  }
}