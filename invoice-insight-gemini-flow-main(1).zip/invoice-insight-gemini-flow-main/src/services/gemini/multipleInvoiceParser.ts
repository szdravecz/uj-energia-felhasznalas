import { GoogleGenerativeAI } from '@google/generative-ai';
import type { ExtractedData } from '../../types/invoice';
import { processInvoice, parseGeminiResponse } from './utils';

export class MultipleInvoiceParser {
  private genAI: GoogleGenerativeAI;

  constructor(genAI: GoogleGenerativeAI) {
    this.genAI = genAI;
  }

  // Több számla kezelése egy PDF-ben - JAVÍTOTT VERZIÓ
  async parseMultipleInvoices(text: string): Promise<ExtractedData[]> {
    try {
      console.log('🔍 JAVÍTOTT Többszámla elemzés indítása...');
      console.log('📏 Szöveg hossza:', text.length, 'karakter');
      
      // Szöveg előkészítése
      const cleanText = text
        .replace(/\s+/g, ' ')
        .replace(/\n+/g, '\n')
        .trim();
        
      console.log('🧹 Tisztított szöveg hossza:', cleanText.length, 'karakter');
      
      // Nagy szöveg esetén chunks-okra bontás
      if (cleanText.length > 60000) {
        console.log('⚠️ Nagy szöveg észlelve - chunks-okra bontás');
        return await this.parseInChunks(cleanText);
      }
      
      const model = this.genAI.getGenerativeModel({ 
        model: "gemini-1.5-flash",
        generationConfig: {
          temperature: 0.1, // Még alacsonyabb konzisztenciáért
          topP: 0.7,
          topK: 30,
          maxOutputTokens: 8192 // Nagyobb output limit
        }
      });
      
      const prompt = `
KRITIKUS FELADAT: Elemezd ezt a magyar villamos energia számla szöveget és találd meg MINDEN EGYES KÜLÖN SZÁMLÁT!

🔍 SZÁMLA FELISMERÉSI STRATÉGIA:
1. Keress minden "Számla sorszáma:" vagy "Számlaszám:" előfordulást
2. Keress minden "Elszámolási időszak:" vagy "Számlázási időszak:" változást  
3. Keress minden POD azonosítót (HU kezdetű)
4. Keress minden "Fizetendő összeg:" vagy "Végösszeg:" tételt
5. Figyelj a dátum változásokra (hónapok)

⚠️ KRITIKUS SZABÁLYOK:
- SOHA ne hagyj ki egyetlen számlát sem!
- Minden számla KÜLÖN JSON objektum
- Ha 11 számlát látsz, 11 objektumot adj vissza
- Ne összesítsd az adatokat - minden számla különálló
- Ha bizonytalan vagy, inkább készíts több objektumot mint kevesebbet

Elemzendő szöveg:
${cleanText.substring(0, 50000)}${cleanText.length > 50000 ? '\n... [szöveg folytatódik]' : ''}

VÁLASZ FORMÁTUM - MINDIG JSON TÖMB (még 1 számla esetén is):
[
  {
    "companyName": "szolgáltató neve",
    "address": "szolgáltató címe", 
    "monthlyMaxPower": mert_maximum_teljesitmeny_szam,
    "contractedPower": lekotott_teljesitmeny_szam,
    "systemUsageFee": rendszerhasznalati_dij_szam,
    "tariffType": "tarifa típusa",
    "billingPeriod": "YYYY.MM.DD-YYYY.MM.DD",
    "totalAmount": vegosszeg_szam,
    "customerName": "ügyfél neve",
    "customerAddress": "ügyfél címe", 
    "taxNumber": "adószám",
    "invoiceNumber": "számla sorszáma",
    "performanceFeeUnit": teljesitmeny_dij_egysegar_szam,
    "yearlyPerformanceFee": eves_teljesitmeny_dij_szam,
    "podNumber": "POD azonosító",
    "exceedanceAmount": tullpes_mertek_szam,
    "exceedanceFee": tullpesi_dij_szam,
    "actualEnergyConsumption": energia_fogyasztas_szam,
    "energyFee": energia_dij_szam,
    "networkUsageFee": halozathasznalati_dij_szam,
    "measurementMonth": "YYYY.MM",
    "billingDays": szamlazasi_napok_szam,
    "confidence": 0.9
  }
]

FONTOS: Csak tiszta JSON választ adj, semmi más szöveget!`;

      const result = await model.generateContent(prompt);
      const response = await result.response;
      const responseText = response.text();
      
      console.log('🤖 JAVÍTOTT Gemini válasz hossza:', responseText.length);
      console.log('🤖 JAVÍTOTT Gemini válasz első 500 karakter:', responseText.substring(0, 500));
      
      try {
        const aiData = parseGeminiResponse(responseText);
        console.log('🔍 Parsed AI data type:', Array.isArray(aiData) ? 'array' : 'object');
        console.log('🔍 Parsed AI data length/keys:', Array.isArray(aiData) ? aiData.length : Object.keys(aiData).length);

        let invoices: ExtractedData[] = [];

        // Mindig tömbbé alakítjuk
        if (Array.isArray(aiData)) {
          invoices = aiData.map((item, index) => {
            const processed = processInvoice(item);
            return processed;
          });
        } else {
          // Ha egyetlen objektum, tömbbé alakítjuk
          const processed = processInvoice(aiData);
          invoices = [processed];
        }
        
        console.log(`✅ JAVÍTOTT EREDMÉNY: ${invoices.length} számla feldolgozva`);
        
        // Részletes logging minden számláról
        invoices.forEach((invoice, index) => {
          console.log(`📋 Számla ${index + 1}:`, {
            customerName: invoice.customerName,
            invoiceNumber: invoice.invoiceNumber,
            billingPeriod: invoice.billingPeriod,
            totalAmount: invoice.totalAmount,
            podNumber: invoice.podNumber
          });
        });
        
        return invoices;
        
      } catch (parseError) {
        console.error('❌ JAVÍTOTT JSON parse hiba:', parseError);
        console.error('❌ Problémás válasz:', responseText);
        throw parseError;
      }
      
    } catch (error) {
      console.error('❌ JAVÍTOTT Többszámla elemzés hiba:', error);
      throw error;
    }
  }

  // Nagy szöveg chunks-okra bontása
  private async parseInChunks(text: string): Promise<ExtractedData[]> {
    console.log('🔄 CHUNKS feldolgozás indítása...');
    
    const chunkSize = 45000; // Biztonságos chunk méret
    const chunks: string[] = [];
    
    // Intelligens szöveg darabolás számla határok szerint
    const potentialBreaks = [
      /(?=.*számla.*sorszáma)/gi,
      /(?=.*elszámolási.*időszak)/gi,
      /(?=.*POD.*azonosító)/gi,
      /(?=.*következő.*oldal)/gi
    ];
    
    let remainingText = text;
    let chunkIndex = 0;
    
    while (remainingText.length > 0 && chunkIndex < 20) { // Max 20 chunk biztonsági korlát
      let chunkEnd = Math.min(chunkSize, remainingText.length);
      
      // Próbáljunk számla határnál vágni
      if (chunkEnd < remainingText.length) {
        for (const breakPattern of potentialBreaks) {
          const matches = Array.from(remainingText.substring(chunkEnd - 2000, chunkEnd + 2000).matchAll(breakPattern));
          if (matches.length > 0) {
            const match = matches[0];
            const adjustedEnd = chunkEnd - 2000 + (match.index || 0);
            if (adjustedEnd > chunkEnd * 0.7) { // Ne vágjunk túl korán
              chunkEnd = adjustedEnd;
              break;
            }
          }
        }
      }
      
      const chunk = remainingText.substring(0, chunkEnd);
      chunks.push(chunk);
      remainingText = remainingText.substring(chunkEnd);
      chunkIndex++;
      
      console.log(`📦 Chunk ${chunkIndex} létrehozva: ${chunk.length} karakter`);
    }
    
    console.log(`📦 Összesen ${chunks.length} chunk létrehozva`);
    
    // Minden chunk feldolgozása
    const allInvoices: ExtractedData[] = [];
    for (let i = 0; i < chunks.length; i++) {
      console.log(`🔍 Chunk ${i + 1}/${chunks.length} feldolgozása...`);
      try {
        const chunkInvoices = await this.parseMultipleInvoices(chunks[i]);
        console.log(`✅ Chunk ${i + 1}: ${chunkInvoices.length} számla találva`);
        allInvoices.push(...chunkInvoices);
      } catch (chunkError) {
        console.error(`❌ Chunk ${i + 1} feldolgozási hiba:`, chunkError);
        // Folytatjuk a többi chunk-kal
      }
    }
    
    console.log(`🎯 CHUNKS ÖSSZESÍTÉS: ${allInvoices.length} számla összesen`);
    return allInvoices;
  }
}