import { GoogleGenerativeAI } from '@google/generative-ai';
import type { ExtractedData, ApiConfig } from '../../types/invoice';
import { InvoiceParser } from './invoiceParser';
import { MultipleInvoiceParser } from './multipleInvoiceParser';
import { AnalysisGenerator } from './analysisGenerator';

export class GeminiParser {
  private genAI: GoogleGenerativeAI;
  private invoiceParser: InvoiceParser;
  private multipleInvoiceParser: MultipleInvoiceParser;
  private analysisGenerator: AnalysisGenerator;

  constructor(config: ApiConfig) {
    console.log('🔑 GeminiParser konstruktor - API kulcs:', config.apiKey ? `${config.apiKey.substring(0, 20)}...` : 'NINCS');
    this.genAI = new GoogleGenerativeAI(config.apiKey);
    
    // Inicializálás a parser modulokkal
    this.invoiceParser = new InvoiceParser(this.genAI);
    this.multipleInvoiceParser = new MultipleInvoiceParser(this.genAI);
    this.analysisGenerator = new AnalysisGenerator(this.genAI);
  }

  // Számla adatok kinyerése AI-val (egy vagy több számla kezelése)
  async parseInvoiceData(text: string): Promise<ExtractedData> {
    try {
      console.log('🤖 Gemini AI elemzés indítása...');
      
      // Először ellenőrizzük, hogy több számla van-e
      const multipleInvoices = await this.parseMultipleInvoices(text);
      if (multipleInvoices.length > 1) {
        console.log(`📄 Több számla észlelve: ${multipleInvoices.length} db - visszaadjuk az első számlát`);
        return multipleInvoices[0];
      } else if (multipleInvoices.length === 1) {
        return multipleInvoices[0];
      }
      
      // Fallback egyetlen számla feldolgozáshoz
      return await this.invoiceParser.parseSingleInvoice(text);
      
    } catch (error) {
      console.error('❌ Gemini AI hiba:', error);
      throw error;
    }
  }

  // Több számla kezelése egy PDF-ben
  async parseMultipleInvoices(text: string): Promise<ExtractedData[]> {
    return await this.multipleInvoiceParser.parseMultipleInvoices(text);
  }

  // Szakmai elemzés generálása a kinyert adatok alapján
  async generateProfessionalAnalysis(extractedData: ExtractedData[], enabledCategories?: any[]): Promise<string> {
    return await this.analysisGenerator.generateProfessionalAnalysis(extractedData, enabledCategories);
  }
}