import { GoogleGenerativeAI } from '@google/generative-ai';
import type { ExtractedData } from '../../types/invoice';

export class AnalysisGenerator {
  private genAI: GoogleGenerativeAI;

  constructor(genAI: GoogleGenerativeAI) {
    this.genAI = genAI;
  }

  // Szakmai elemzés generálása a kinyert adatok alapján
  async generateProfessionalAnalysis(extractedData: ExtractedData[], enabledCategories?: any[]): Promise<string> {
    try {
      const model = this.genAI.getGenerativeModel({ 
        model: "gemini-1.5-flash",
        generationConfig: {
          temperature: 0.1,
          topP: 0.8,
          topK: 40
        }
      });
      
      const analysisData = extractedData.map(data => ({
        szolgaltato: data.companyName,
        ugyfel: data.customerName,
        lekotottTeljesitmeny: data.contractedPower,
        maxTeljesitmeny: data.monthlyMaxPower,
        rendszerhasznalatiDij: data.systemUsageFee,
        osszeg: data.totalAmount,
        tarifa: data.tariffType,
        idoszak: data.billingPeriod,
        teljesitmenyDij: data.performanceFeeUnit,
        evesteljesitmenyDij: data.yearlyPerformanceFee,
        tullpesOsszeg: data.exceedanceAmount,
        tullepesDij: data.exceedanceFee,
        energiaFogyasztas: data.actualEnergyConsumption,
        podSzam: data.podNumber
      }));

      // Beállítások használata (ha átadva) vagy alapértelmezettek
      let categories: any[] = [];
      
      if (enabledCategories && enabledCategories.length > 0) {
        categories = enabledCategories.filter((cat: any) => cat.enabled);
      } else {
        categories = this.getDefaultCategories();
      }

      // Prompt összeállítása csak a kiválasztott kategóriák alapján
      let analysisPrompt = `
Te egy magyar villamos energia szakértő vagy. Készíts részletes, szakmai elemzést az alábbi számla adatok alapján.
Az elemzés legyen magyarázó, konkrét és végrehajtható javaslatokkal!

ENERGIA SZÁMLA ADATOK:
${JSON.stringify(analysisData, null, 2)}

FONTOS: Az elemzést MAGYAR NYELVEN, részletesen írd meg az alábbi kategóriákban:

`;

      // Csak a kiválasztott kategóriákat adjuk hozzá
      categories.forEach(category => {
        const enabledSubcats = category.subcategories.filter((sub: any) => sub.enabled);
        if (enabledSubcats.length > 0) {
          analysisPrompt += `\n## ${category.emoji} ${category.title}\n`;
          enabledSubcats.forEach((subcat: any) => {
            analysisPrompt += `- ${subcat.title}\n`;
          });
        }
      });

      analysisPrompt += `\nAz elemzés legyen gyakorlatias, számszerű és végrehajtható javaslatokkal!`;

      const result = await model.generateContent(analysisPrompt);
      const response = await result.response;
      const analysis = response.text();
      
      console.log('📊 Szakmai elemzés generálva, hossz:', analysis.length);
      console.log('📊 Felhasznált kategóriák:', categories.map(c => c.title));
      return analysis;
      
    } catch (error) {
      console.error('❌ Szakmai elemzés hiba:', error);
      throw error;
    }
  }

  // Alapértelmezett kategóriák
  private getDefaultCategories() {
    return [
      {
        id: 'consumption-profile',
        title: 'ENERGIA FOGYASZTÁSI PROFIL ELEMZÉSE',
        emoji: '📊',
        enabled: true,
        subcategories: [
          { id: 'contracted-vs-measured', title: 'Lekötött vs. mért teljesítmény elemzése', enabled: true },
          { id: 'consumption-efficiency', title: 'Fogyasztási hatékonyság értékelése', enabled: true },
          { id: 'seasonal-trends', title: 'Szezonális trendek (ha több számlát kapsz)', enabled: true }
        ]
      },
      {
        id: 'cost-optimization',
        title: 'KÖLTSÉGOPTIMALIZÁLÁSI LEHETŐSÉGEK',
        emoji: '💰',
        enabled: true,
        subcategories: [
          { id: 'system-fee-optimization', title: 'Rendszerhasználati díj optimalizálás', enabled: true },
          { id: 'tariff-switching', title: 'Tarifa váltási javaslatok', enabled: true },
          { id: 'capacity-adjustment', title: 'Teljesítmény lekötés módosítási javaslatok', enabled: true }
        ]
      },
      {
        id: 'performance-management',
        title: 'TELJESÍTMÉNYMENEDZSMENT',
        emoji: '⚡',
        enabled: true,
        subcategories: [
          { id: 'exceedance-analysis', title: 'Túllépések elemzése és megelőzési stratégiák', enabled: true },
          { id: 'optimal-capacity', title: 'Optimális lekötött teljesítmény meghatározása', enabled: true },
          { id: 'cost-benefit-analysis', title: 'Költség-haszon elemzés', enabled: true }
        ]
      },
      {
        id: 'industry-comparison',
        title: 'IPARÁGI ÖSSZEHASONLÍTÁS',
        emoji: '📈',
        enabled: true,
        subcategories: [
          { id: 'benchmarking', title: 'Benchmarking hasonló vállalkozásokkal', enabled: true },
          { id: 'market-position', title: 'Piaci átlagokhoz viszonyított pozíció', enabled: true },
          { id: 'competitiveness', title: 'Versenyképességi értékelés', enabled: true }
        ]
      },
      {
        id: 'recommendations',
        title: 'KONKRÉT AJÁNLÁSOK',
        emoji: '🎯',
        enabled: true,
        subcategories: [
          { id: 'short-term', title: 'Rövid távú (1-3 hónap) intézkedések', enabled: true },
          { id: 'medium-term', title: 'Középtávú (3-12 hónap) stratégiák', enabled: true },
          { id: 'long-term', title: 'Hosszú távú (1-3 év) fejlesztési lehetőségek', enabled: true }
        ]
      }
    ];
  }
}