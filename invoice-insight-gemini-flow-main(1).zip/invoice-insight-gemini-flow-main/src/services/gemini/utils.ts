import type { ExtractedData } from '../../types/invoice';

// Szám konverzió segédfüggvény
export const parseNumber = (value: any): number => {
  if (value === null || value === undefined || value === '') return 0;
  const num = typeof value === 'string' ? 
    parseFloat(value.replace(/[^\d.-]/g, '')) : 
    parseFloat(value);
  return isNaN(num) ? 0 : num;
};

// Számla objektum feldolgozása
export const processInvoice = (invoiceData: any): ExtractedData => ({
  companyName: invoiceData.companyName || '',
  address: invoiceData.address || '',
  monthlyMaxPower: parseNumber(invoiceData.monthlyMaxPower),
  contractedPower: parseNumber(invoiceData.contractedPower),
  systemUsageFee: parseNumber(invoiceData.systemUsageFee),
  tariffType: invoiceData.tariffType || '',
  billingPeriod: invoiceData.billingPeriod || '',
  totalAmount: parseNumber(invoiceData.totalAmount),
  customerName: invoiceData.customerName || '',
  customerAddress: invoiceData.customerAddress || '',
  taxNumber: invoiceData.taxNumber || '',
  invoiceNumber: invoiceData.invoiceNumber || '',
  confidence: 0.9,
  performanceFeeUnit: parseNumber(invoiceData.performanceFeeUnit),
  yearlyPerformanceFee: parseNumber(invoiceData.yearlyPerformanceFee),
  podNumber: invoiceData.podNumber || '',
  exceedanceAmount: parseNumber(invoiceData.exceedanceAmount),
  exceedanceFee: parseNumber(invoiceData.exceedanceFee),
  actualEnergyConsumption: parseNumber(invoiceData.actualEnergyConsumption),
  energyFee: parseNumber(invoiceData.energyFee),
  networkUsageFee: parseNumber(invoiceData.networkUsageFee),
  measurementMonth: invoiceData.measurementMonth || '',
  billingDays: parseNumber(invoiceData.billingDays) || 30
});

// JSON tisztítása és parse-olása
export const parseGeminiResponse = (responseText: string): any => {
  const cleanJson = responseText.replace(/```json|```/g, '').trim();
  return JSON.parse(cleanJson);
};