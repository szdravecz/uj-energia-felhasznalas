import { VisionOcrService } from './visionOcrService';
import { EnergyGeminiParser } from './gemini/energyGeminiParser';
import { EnergyRegexParser } from './energyRegexParser';
import type { EnergyConsumptionData, ApiConfig } from '../types/energyConsumption';
import { DEFAULT_API_KEY } from '../types/energyConsumption';

export class EnergyAnalysisService {
  private visionService: VisionOcrService;
  private geminiParser: EnergyGeminiParser;

  constructor(config?: ApiConfig) {
    const apiConfig = config || { apiKey: DEFAULT_API_KEY };
    console.log('🔑 EnergyAnalysisService API kulcs:', apiConfig.apiKey ? 'van' : 'nincs');
    this.visionService = new VisionOcrService(apiConfig);
    this.geminiParser = new EnergyGeminiParser(apiConfig);
  }

  // PDF szöveg kinyerése OCR-rel
  async extractTextFromPDF(file: File): Promise<string> {
    return await this.visionService.extractTextFromPDF(file);
  }

  // Intelligens energia számla elemzés Gemini AI-val, regex fallback-kel
  async parseEnergyInvoiceData(extractedText: string): Promise<EnergyConsumptionData> {
    try {
      // Először próbáljuk Gemini AI-val
      return await this.geminiParser.parseEnergyInvoiceData(extractedText);
    } catch (error) {
      console.warn('⚠️ Gemini AI sikertelen, regex fallback használata:', error);
      // Fallback regex-alapú elemzésre
      return EnergyRegexParser.parseEnergyInvoiceData(extractedText);
    }
  }

  // Több számla kezelése egy PDF-ben
  async parseMultipleEnergyInvoicesFromText(extractedText: string): Promise<EnergyConsumptionData[]> {
    try {
      console.log('📄 Többszámla elemzés indítása PDF szövegből...');
      return await this.geminiParser.parseMultipleEnergyInvoices(extractedText);
    } catch (error) {
      console.warn('⚠️ Gemini többszámla elemzés sikertelen, fallback egyetlen számlára:', error);
      // Fallback egyetlen számla feldolgozásra
      const singleInvoice = await this.parseEnergyInvoiceData(extractedText);
      return [singleInvoice];
    }
  }

  // Energia hatékonysági elemzés generálása
  async generateEnergyAnalysis(extractedData: EnergyConsumptionData[], enabledCategories?: any[]): Promise<string> {
    return await this.geminiParser.generateEnergyAnalysis(extractedData, enabledCategories);
  }
}

// Type exports
export type { EnergyConsumptionData, ApiConfig as EnergyApiConfig } from '../types/energyConsumption';