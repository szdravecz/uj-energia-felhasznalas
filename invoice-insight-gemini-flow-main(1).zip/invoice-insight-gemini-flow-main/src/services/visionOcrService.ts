import { PdfConverter } from './pdfConverter';
import type { ApiConfig } from '../types/invoice';

export class VisionOcrService {
  private apiKey: string;

  constructor(config: ApiConfig) {
    this.apiKey = config.apiKey;
  }

  // Google Cloud Vision API hívás képpel - ÖSSZES oldal feldolgozása
  async extractTextFromPDF(file: File): Promise<string> {
    const totalStartTime = performance.now(); // TELJES FOLYAMAT IDŐMÉRÉS
    try {
      // PDF összes oldalának feldolgozása
      const allTexts: string[] = [];
      
      // Először lekérdezzük, hány oldala van a PDF-nek
      const pdfjsLib = await import('pdfjs-dist/build/pdf.min.mjs');
      
      // Worker URL beállítása a Vite számára
      if (typeof window !== 'undefined') {
        pdfjsLib.GlobalWorkerOptions.workerSrc = new URL(
          'pdfjs-dist/build/pdf.worker.min.mjs',
          import.meta.url
        ).toString();
      }
      
      const fileReader = new FileReader();
      
      const pageCount = await new Promise<number>((resolve, reject) => {
        fileReader.onload = async (event) => {
          try {
            const arrayBuffer = event.target?.result as ArrayBuffer;
            const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
            resolve(pdf.numPages);
          } catch (error) {
            reject(error);
          }
        };
        fileReader.onerror = () => reject(new Error('FileReader hiba'));
        fileReader.readAsArrayBuffer(file);
      });

      console.log(`📄 PDF feldolgozás: ${pageCount} oldal található`);

      // SZUPER GYORSÍTOTT BATCH FELDOLGOZÁS
      const BATCH_SIZE = 16; // Maximális batch méret a Vision API-hoz (16 kép/kérés)
      console.log(`⚡ SZUPER GYORSÍTOTT feldolgozás: ${pageCount} oldal, ${BATCH_SIZE}-as batchekben`);
      
      const allResults: Array<{ pageIndex: number, text: string } | null> = [];
      
      // Batch-ekben dolgozzuk fel
      for (let batchStart = 0; batchStart < pageCount; batchStart += BATCH_SIZE) {
        const batchEnd = Math.min(batchStart + BATCH_SIZE, pageCount);
        const batchSize = batchEnd - batchStart;
        
        console.log(`📦 Batch ${Math.floor(batchStart/BATCH_SIZE) + 1}/${Math.ceil(pageCount/BATCH_SIZE)}: oldal ${batchStart + 1}-${batchEnd}`);
        
        try {
          // SZUPER GYORSÍTOTT: Képek konvertálása és Vision API hívás párhuzamosan
          const batchStartTime = performance.now();
          
          // Párhuzamos kép konvertálás (minden oldal egyszerre)
          const batchImagePromises = Array.from({ length: batchSize }, async (_, i) => {
            const pageIndex = batchStart + i;
            console.log(`⚡ ${pageIndex + 1}. oldal gyors konvertálás...`);
            const base64Image = await PdfConverter.convertToImage(file, pageIndex, 1.3); // Csökkentett felbontás
            console.log(`✅ ${pageIndex + 1}. oldal kész (${Math.round(base64Image.length/1024)}KB)`);
            return { pageIndex, base64Image };
          });
          
          // Minden kép egyszerre készül el
          const batchImages = await Promise.all(batchImagePromises);
          const conversionTime = performance.now() - batchStartTime;
          console.log(`🏎️ Batch konvertálás kész: ${conversionTime.toFixed(0)}ms (${batchSize} oldal)`);
          
          // Batch Vision API hívás
          const batchRequests = batchImages.map(({ base64Image }) => ({
            image: { content: base64Image },
            features: [{ type: 'TEXT_DETECTION', maxResults: 1 }]
          }));
          
          console.log(`🚀 Vision API batch hívás: ${batchRequests.length} kép (batch ${Math.floor(batchStart/BATCH_SIZE) + 1})`);
          const apiStartTime = performance.now();
          
          const response = await fetch(`https://vision.googleapis.com/v1/images:annotate?key=${this.apiKey}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ requests: batchRequests })
          });
          
          const apiTime = performance.now() - apiStartTime;
          console.log(`⚡ Vision API válasz: ${apiTime.toFixed(0)}ms`);

          if (!response.ok) {
            console.warn(`⚠️ Batch ${Math.floor(batchStart/BATCH_SIZE) + 1} hiba, fallback egyenként...`);
            // Fallback: egyenként próbáljuk
            for (let i = 0; i < batchSize; i++) {
              const pageIndex = batchStart + i;
              try {
                const singleResponse = await fetch(`https://vision.googleapis.com/v1/images:annotate?key=${this.apiKey}`, {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    requests: [{
                      image: { content: batchImages[i].base64Image },
                      features: [{ type: 'TEXT_DETECTION', maxResults: 1 }]
                    }]
                  })
                });
                
                if (singleResponse.ok) {
                  const singleResult = await singleResponse.json();
                  const pageText = singleResult.responses[0].fullTextAnnotation?.text || '';
                  if (pageText.trim()) {
                    console.log(`✅ ${pageIndex + 1}. oldal kész (${pageText.length} karakter)`);
                    allResults.push({ pageIndex, text: pageText });
                  } else {
                    allResults.push(null);
                  }
                } else {
                  console.warn(`❌ ${pageIndex + 1}. oldal egyenkénti fallback hiba`);
                  allResults.push(null);
                }
              } catch (singleError) {
                console.warn(`❌ ${pageIndex + 1}. oldal egyenkénti hiba:`, singleError);
                allResults.push(null);
              }
            }
            continue;
          }

          const batchResult = await response.json();
          
          // Batch eredmények feldolgozása
          for (let i = 0; i < batchSize; i++) {
            const pageIndex = batchStart + i;
            const responseData = batchResult.responses[i];
            
            if (responseData.error) {
              console.warn(`⚠️ ${pageIndex + 1}. oldal Vision API hiba:`, responseData.error.message);
              allResults.push(null);
              continue;
            }

            const pageText = responseData.fullTextAnnotation?.text || '';
            if (pageText.trim()) {
              console.log(`✅ ${pageIndex + 1}. oldal kész (${pageText.length} karakter)`);
              allResults.push({ pageIndex, text: pageText });
            } else {
              allResults.push(null);
            }
          }
          
        } catch (batchError) {
          console.warn(`❌ Batch ${Math.floor(batchStart/BATCH_SIZE) + 1} teljes hiba:`, batchError);
          // Fallback null-ok hozzáadása
          for (let i = 0; i < batchSize; i++) {
            allResults.push(null);
          }
        }
      }
      const validResults = allResults.filter(Boolean).sort((a, b) => a!.pageIndex - b!.pageIndex);
      
      console.log(`📊 ÖSSZES EREDMÉNY DEBUG:`, allResults);
      console.log(`✅ VALID EREDMÉNYEK DEBUG:`, validResults);
      console.log(`📄 OLDALAK SZÁMA PER EREDMÉNY:`, validResults.map(r => ({ oldal: r!.pageIndex + 1, szövegHossz: r!.text.length })));
      
      const combinedText = validResults.map(result => result!.text).join('\n\n--- KÖVETKEZŐ OLDAL ---\n\n');
      
      // TELJES FOLYAMAT IDŐMÉRÉS BEFEJEZÉSE
      const totalTime = performance.now() - totalStartTime;
      const avgTimePerPage = totalTime / pageCount;
      console.log(`🚀 SZUPER GYORSÍTOTT OCR BEFEJEZVE!`);
      console.log(`⏱️ Teljes idő: ${(totalTime/1000).toFixed(1)}s (${totalTime.toFixed(0)}ms)`);
      console.log(`📄 Átlag/oldal: ${avgTimePerPage.toFixed(0)}ms`);
      console.log(`🎯 Feldolgozott: ${validResults.length}/${pageCount} oldal sikeres`);
      console.log(`📝 Szöveg hossz: ${combinedText.length} karakter`);
      
      return combinedText;
    } catch (error) {
      console.error('OCR Error:', error);
      throw error;
    }
  }
}