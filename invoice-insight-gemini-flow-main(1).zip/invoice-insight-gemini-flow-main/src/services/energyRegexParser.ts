import type { EnergyConsumptionData } from '../types/energyConsumption';

export class EnergyRegexParser {
  static parseEnergyInvoiceData(text: string): EnergyConsumptionData {
    console.log('🔍 Regex-alapú energia számla elemzés indítása...');
    
    // Alapvető cég adatok
    const companyName = this.extractCompanyName(text);
    const address = this.extractAddress(text);
    const customerName = this.extractCustomerName(text);
    const customerAddress = this.extractCustomerAddress(text);
    const taxNumber = this.extractTaxNumber(text);
    const invoiceNumber = this.extractInvoiceNumber(text);
    
    // Energia fogyasztási adatok
    const energyConsumption = this.extractEnergyConsumption(text);
    const energyConsumptionDay = this.extractEnergyConsumptionDay(text);
    const energyConsumptionNight = this.extractEnergyConsumptionNight(text);
    const energyConsumptionPeak = this.extractEnergyConsumptionPeak(text);
    
    // Teljesítmény adatok
    const maxPowerDemand = this.extractMaxPowerDemand(text);
    const averagePowerDemand = this.extractAveragePowerDemand(text);
    const contractedPower = this.extractContractedPower(text);
    
    // Költségek
    const totalCost = this.extractTotalCost(text);
    const energyCost = this.extractEnergyCost(text);
    const networkCost = this.extractNetworkCost(text);
    const systemUsageFee = this.extractSystemUsageFee(text);
    
    // Tarifa és időszak
    const tariffType = this.extractTariffType(text);
    const billingPeriod = this.extractBillingPeriod(text);
    const billingDays = this.extractBillingDays(text);
    const measurementMonth = this.extractMeasurementMonth(text);
    
    // CO2 kibocsátás becslés (0.3 kg CO2/kWh Magyarországon)
    const co2Emissions = energyConsumption > 0 ? Math.round(energyConsumption * 0.3) : 0;
    
    const result: EnergyConsumptionData = {
      companyName,
      address,
      customerName,
      customerAddress,
      taxNumber,
      invoiceNumber,
      energyConsumption,
      energyConsumptionDay,
      energyConsumptionNight,
      energyConsumptionPeak,
      maxPowerDemand,
      averagePowerDemand,
      contractedPower,
      totalCost,
      energyCost,
      networkCost,
      systemUsageFee,
      tariffType,
      billingPeriod,
      billingDays,
      measurementMonth,
      co2Emissions,
      confidence: 60, // Regex alapú elemzés alacsonyabb megbízhatóságú
    };
    
    console.log('📊 Regex elemzés eredménye:', result);
    return result;
  }
  
  private static extractCompanyName(text: string): string {
    const patterns = [
      /(?:Szolgáltató|Áramszolgáltató|Energiaszolgáltató)[:\s]+([^\\n]+)/i,
      /E\.ON[^\\n]*/i,
      /ELMŰ[^\\n]*/i,
      /NKM[^\\n]*/i,
      /MVM[^\\n]*/i
    ];
    
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match && match[1]) {
        return match[1].trim();
      }
    }
    
    return 'Ismeretlen szolgáltató';
  }
  
  private static extractAddress(text: string): string {
    const patterns = [
      /(?:Szolgáltató címe|Székhely)[:\s]+([^\\n]+)/i,
      /\d{4}\s+[A-Za-zÁÉÍÓÖŐÚÜŰáéíóöőúüű\s]+,\s*[^\\n]+/
    ];
    
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match && match[1]) {
        return match[1].trim();
      }
    }
    
    return 'Ismeretlen cím';
  }
  
  private static extractCustomerName(text: string): string {
    const patterns = [
      /(?:Vevő|Ügyfél neve|Fogyasztó)[:\s]+([^\\n]+)/i,
      /Név[:\s]+([^\\n]+)/i
    ];
    
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match && match[1]) {
        return match[1].trim();
      }
    }
    
    return 'Ismeretlen ügyfél';
  }
  
  private static extractCustomerAddress(text: string): string {
    const patterns = [
      /(?:Vevő címe|Ügyfél címe|Fogyasztási hely)[:\s]+([^\\n]+)/i,
      /Cím[:\s]+([^\\n]+)/i
    ];
    
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match && match[1]) {
        return match[1].trim();
      }
    }
    
    return 'Ismeretlen cím';
  }
  
  private static extractTaxNumber(text: string): string {
    const patterns = [
      /(?:Adószám|Adóazonosító)[:\s]+([0-9-]+)/i,
      /\b\d{8}-\d{1}-\d{2}\b/
    ];
    
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match && match[1]) {
        return match[1].trim();
      }
    }
    
    return '';
  }
  
  private static extractInvoiceNumber(text: string): string {
    const patterns = [
      /(?:Számlaszám|Bizonylat száma)[:\s]+([A-Z0-9]+)/i,
      /\b[0-9]{10,15}\b/
    ];
    
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match && match[1]) {
        return match[1].trim();
      }
    }
    
    return '';
  }
  
  private static extractEnergyConsumption(text: string): number {
    const patterns = [
      /(?:Összes fogyasztás|Teljes fogyasztás|Energia fogyasztás)[:\s]+([0-9.,]+)\s*kWh/i,
      /([0-9.,]+)\s*kWh/i
    ];
    
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match && match[1]) {
        return parseFloat(match[1].replace(',', '.'));
      }
    }
    
    return 0;
  }
  
  private static extractEnergyConsumptionDay(text: string): number {
    const patterns = [
      /(?:Nappali fogyasztás|Nappal)[:\s]+([0-9.,]+)\s*kWh/i,
      /([0-9.,]+)\s*kWh.*nappal/i
    ];
    
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match && match[1]) {
        return parseFloat(match[1].replace(',', '.'));
      }
    }
    
    return 0;
  }
  
  private static extractEnergyConsumptionNight(text: string): number {
    const patterns = [
      /(?:Éjszakai fogyasztás|Éjjel)[:\s]+([0-9.,]+)\s*kWh/i,
      /([0-9.,]+)\s*kWh.*éjjel/i
    ];
    
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match && match[1]) {
        return parseFloat(match[1].replace(',', '.'));
      }
    }
    
    return 0;
  }
  
  private static extractEnergyConsumptionPeak(text: string): number {
    const patterns = [
      /(?:Csúcsidei fogyasztás|Csúcs)[:\s]+([0-9.,]+)\s*kWh/i,
      /([0-9.,]+)\s*kWh.*csúcs/i
    ];
    
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match && match[1]) {
        return parseFloat(match[1].replace(',', '.'));
      }
    }
    
    return 0;
  }
  
  private static extractMaxPowerDemand(text: string): number {
    const patterns = [
      /(?:Maximális teljesítmény|Max teljesítmény)[:\s]+([0-9.,]+)\s*kW/i,
      /([0-9.,]+)\s*kW.*max/i
    ];
    
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match && match[1]) {
        return parseFloat(match[1].replace(',', '.'));
      }
    }
    
    return 0;
  }
  
  private static extractAveragePowerDemand(text: string): number {
    const patterns = [
      /(?:Átlagos teljesítmény|Átlag teljesítmény)[:\s]+([0-9.,]+)\s*kW/i,
      /([0-9.,]+)\s*kW.*átlag/i
    ];
    
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match && match[1]) {
        return parseFloat(match[1].replace(',', '.'));
      }
    }
    
    return 0;
  }
  
  private static extractContractedPower(text: string): number {
    const patterns = [
      /(?:Lekötött teljesítmény|Szerződött teljesítmény)[:\s]+([0-9.,]+)\s*kW/i,
      /([0-9.,]+)\s*kW.*lekötött/i
    ];
    
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match && match[1]) {
        return parseFloat(match[1].replace(',', '.'));
      }
    }
    
    return 0;
  }
  
  private static extractTotalCost(text: string): number {
    const patterns = [
      /(?:Végösszeg|Fizetendő|Összes költség)[:\s]+([0-9.,]+)\s*Ft/i,
      /([0-9.,]+)\s*Ft.*végösszeg/i
    ];
    
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match && match[1]) {
        return parseFloat(match[1].replace(',', '.'));
      }
    }
    
    return 0;
  }
  
  private static extractEnergyCost(text: string): number {
    const patterns = [
      /(?:Energia díj|Energiaköltség)[:\s]+([0-9.,]+)\s*Ft/i,
      /([0-9.,]+)\s*Ft.*energia/i
    ];
    
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match && match[1]) {
        return parseFloat(match[1].replace(',', '.'));
      }
    }
    
    return 0;
  }
  
  private static extractNetworkCost(text: string): number {
    const patterns = [
      /(?:Hálózati díj|Hálózathasználat)[:\s]+([0-9.,]+)\s*Ft/i,
      /([0-9.,]+)\s*Ft.*hálózat/i
    ];
    
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match && match[1]) {
        return parseFloat(match[1].replace(',', '.'));
      }
    }
    
    return 0;
  }
  
  private static extractSystemUsageFee(text: string): number {
    const patterns = [
      /(?:Rendszerhasználati díj|RHD)[:\s]+([0-9.,]+)\s*Ft/i,
      /([0-9.,]+)\s*Ft.*rendszer/i
    ];
    
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match && match[1]) {
        return parseFloat(match[1].replace(',', '.'));
      }
    }
    
    return 0;
  }
  
  private static extractTariffType(text: string): string {
    const patterns = [
      /(?:Tarifa|Tarifacsomag)[:\s]+([A-Z0-9]+)/i,
      /\b[A-Z]\d+\b/
    ];
    
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match && match[1]) {
        return match[1].trim();
      }
    }
    
    return 'Ismeretlen tarifa';
  }
  
  private static extractBillingPeriod(text: string): string {
    const patterns = [
      /(?:Számlázási időszak|Elszámolási időszak)[:\s]+([^\\n]+)/i,
      /\d{4}\.\d{2}\.\d{2}\s*-\s*\d{4}\.\d{2}\.\d{2}/
    ];
    
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match && match[1]) {
        return match[1].trim();
      }
    }
    
    return 'Ismeretlen időszak';
  }
  
  private static extractBillingDays(text: string): number {
    const patterns = [
      /(?:Számlázási napok|Elszámolási napok)[:\s]+([0-9]+)/i,
      /([0-9]+)\s*nap/i
    ];
    
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match && match[1]) {
        return parseInt(match[1]);
      }
    }
    
    return 30; // Alapértelmezett 30 nap
  }
  
  private static extractMeasurementMonth(text: string): string {
    const patterns = [
      /(?:Mérési hónap|Fogyasztási hónap)[:\s]+([^\\n]+)/i,
      /\d{4}\s+\w+/
    ];
    
    for (const pattern of patterns) {
      const match = text.match(pattern);
      if (match && match[1]) {
        return match[1].trim();
      }
    }
    
    return 'Ismeretlen hónap';
  }
}