import { InvoiceAnalysisService, type ExtractedData } from "@/services/invoiceAnalysisService";

export interface AnalysisProgress {
  step: string;
  progress: number;
  message: string;
}

export interface AnalysisResult {
  extractedData: ExtractedData[];
  extractedTexts: {fileName: string, text: string}[];
  professionalAnalysis: string;
}

export class AnalysisEngine {
  private visionService: InvoiceAnalysisService;
  private onProgress?: (progress: AnalysisProgress) => void;

  constructor(geminiApiKey?: string, visionApiKey?: string) {
    this.visionService = new InvoiceAnalysisService({ 
      apiKey: geminiApiKey || visionApiKey || 'AIzaSyBQOIWfD-Mjo0i0Wj6DdEoUrR_8bei7EKk' 
    });
  }

  setProgressCallback(callback: (progress: AnalysisProgress) => void) {
    this.onProgress = callback;
  }

  private updateProgress(step: string, progress: number, message: string) {
    if (this.onProgress) {
      this.onProgress({ step, progress, message });
    }
  }

  async runFullAnalysis(files: File[]): Promise<AnalysisResult> {
    if (files.length === 0) {
      throw new Error("Először töltsön fel számlákat!");
    }

    // 1. Feltöltés
    this.updateProgress('upload', 5, 'Fájlok feltöltése és előkészítése...');
    
    const extractedResults: ExtractedData[] = [];
    const textResults: {fileName: string, text: string}[] = [];
    
    // 2. OCR feldolgozás
    this.updateProgress('ocr', 10, 'OCR feldolgozás kezdése...');
    
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const progress = 10 + Math.round((i / files.length) * 40); // OCR = 10-50%
      
      this.updateProgress('ocr', progress, `OCR feldolgozás: ${file.name}`);
      
      try {
        // OCR szövegfelismerés
        const extractedText = await this.visionService.extractTextFromPDF(file);
        textResults.push({fileName: file.name, text: extractedText});
        
        // Többszámla elemzés
        const invoiceDataArray = await this.visionService.parseMultipleInvoicesFromText(extractedText);
        
        // Minden kinyert számlát hozzáadunk
        for (const invoiceData of invoiceDataArray) {
          extractedResults.push({
            ...invoiceData,
            companyName: invoiceData.companyName || file.name.replace('.pdf', ''),
            fileName: file.name
          });
        }
      } catch (error) {
        console.error(`Hiba ${file.name} feldolgozásánál:`, error);
        throw new Error(`Hiba a(z) ${file.name} feldolgozásánál: ${error}`);
      }
    }
    
    // 3. Szakmai elemzés
    this.updateProgress('analysis', 60, 'AI szakmai elemzés generálása...');
    
    let professionalAnalysis = '';
    try {
      if (extractedResults.length > 0) {
        // Kategória beállítások betöltése localStorage-ból
        let enabledCategories: any[] = [];
        try {
          const savedSettings = localStorage.getItem('analysisContentSettings');
          if (savedSettings) {
            const settings = JSON.parse(savedSettings);
            enabledCategories = settings;
          }
        } catch (error) {
          console.warn('Kategória beállítások betöltése sikertelen:', error);
        }
        
        professionalAnalysis = await this.visionService.generateProfessionalAnalysis(extractedResults, enabledCategories);
      }
    } catch (error) {
      console.warn('Szakmai elemzés nem sikerült:', error);
      professionalAnalysis = 'Szakmai elemzés nem elérhető.';
    }
    
    // 4. Riport összeállítása, megjelenítés
    this.updateProgress('report', 90, 'Riport összeállítása...');
    
    // Kis késleltetés a UX-ért
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    this.updateProgress('complete', 100, 'Elemzés befejezve! Átirányítás...');
    
    return {
      extractedData: extractedResults,
      extractedTexts: textResults,
      professionalAnalysis
    };
  }
}