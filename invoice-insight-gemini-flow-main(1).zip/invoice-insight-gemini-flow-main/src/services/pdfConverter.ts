// PDF.js használata PDF → kép konvertáláshoz - SZUPER GYORSÍTOTT VERZIÓ
export class PdfConverter {
  static async convertToImage(file: File, pageNumber: number = 0, scale: number = 1.3): Promise<string> {
    console.log('🔄 PDF.js feldolgozás kezdése (új módszer)...', file.name);
    
    try {
      // PDF.js dinamikus importálása
      const pdfjsLib = await import('pdfjs-dist/build/pdf.min.mjs');
      
      // Worker URL beállítása a Vite számára
      if (typeof window !== 'undefined') {
        pdfjsLib.GlobalWorkerOptions.workerSrc = new URL(
          'pdfjs-dist/build/pdf.worker.min.mjs',
          import.meta.url
        ).toString();
      }
      
      console.log('✅ PDF.js worker beállítva');
      
      const fileReader = new FileReader();
      
      return new Promise((resolve, reject) => {
        fileReader.onload = async (event) => {
          try {
            const arrayBuffer = event.target?.result as ArrayBuffer;
            console.log('✅ PDF fájl beolvasva:', arrayBuffer.byteLength, 'bytes');
            
            // PDF betöltése
            const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
            console.log('✅ PDF dokumentum betöltve, oldalak:', pdf.numPages);
            
            // Megadott oldal renderelése (alapértelmezett: első oldal)
            const pageIndex = Math.max(1, Math.min(pageNumber + 1, pdf.numPages));
            const page = await pdf.getPage(pageIndex);
            const viewport = page.getViewport({ scale });
            
            const canvas = document.createElement('canvas');
            const context = canvas.getContext('2d')!;
            canvas.height = viewport.height;
            canvas.width = viewport.width;
            
            // Fehér háttér
            context.fillStyle = '#ffffff';
            context.fillRect(0, 0, canvas.width, canvas.height);
            
            // PDF oldal renderelése
            await page.render({
              canvasContext: context,
              viewport: viewport
            }).promise;
            
            const base64Image = canvas.toDataURL('image/png').split(',')[1];
            console.log('✅ PDF → kép konvertálás sikeres:', base64Image.length);
            
            resolve(base64Image);
            
          } catch (error) {
            console.error('❌ PDF renderelési hiba:', error);
            reject(error);
          }
        };
        
        fileReader.onerror = () => reject(new Error('FileReader hiba'));
        fileReader.readAsArrayBuffer(file);
      });
      
    } catch (error) {
      console.error('❌ PDF.js import/setup hiba:', error);
      throw new Error(`PDF feldolgozás sikertelen: ${error}`);
    }
  }
}