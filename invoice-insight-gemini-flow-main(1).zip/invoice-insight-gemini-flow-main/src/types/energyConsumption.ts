export interface EnergyConsumptionData {
  // Alapvető vállalati adatok
  companyName: string;
  address: string;
  customerName: string;
  customerAddress: string;
  taxNumber: string;
  invoiceNumber: string;
  
  // Energia fogyasztási adatok
  energyConsumption: number; // kWh - összes energia fogyasztás
  energyConsumptionDay: number; // kWh - nappali fogyasztás
  energyConsumptionNight: number; // kWh - éjszakai fogyasztás
  energyConsumptionPeak: number; // kWh - csúcsidei fogyasztás
  
  // Teljesítmény adatok
  maxPowerDemand: number; // kW - maximális teljesítmény igény
  averagePowerDemand: number; // kW - átlagos teljesítmény igény
  contractedPower: number; // kW - lekötött teljesítmény
  
  // Költségek
  totalCost: number; // Ft - összes költség
  energyCost: number; // Ft - energia költség
  networkCost: number; // Ft - hálózati díj
  systemUsageFee: number; // Ft - rendszerhasználati díj
  
  // Tarifa és időszak
  tariffType: string; // pl. "A1", "A2", "B1" stb.
  billingPeriod: string; // számlázási időszak
  billingDays: number; // számlázási napok száma
  measurementMonth: string; // mérési hónap
  
  // Hatékonysági mutatók
  energyEfficiencyRating?: 'A' | 'B' | 'C' | 'D' | 'E' | 'F' | 'G';
  co2Emissions?: number; // kg CO2 - becsült kibocsátás
  renewableEnergyPercentage?: number; // % - megújuló energia aránya
  
  // Metaadatok
  confidence: number; // 0-100 - AI elemzés megbízhatósága
  fileName?: string; // PDF fájl neve
  analysisDate?: string; // elemzés dátuma
}

export interface EnergyAnalysisReport {
  // Alapadatok
  extractedData: EnergyConsumptionData;
  
  // Elemzési eredmények
  efficiencyScore: number; // 0-100 - hatékonysági pontszám
  potentialSavings: {
    annualSavings: number; // Ft/év - becsült éves megtakarítás
    co2Reduction: number; // kg CO2/év - CO2 csökkentés
    percentage: number; // % - megtakarítás százalék
  };
  
  // Ajánlások
  recommendations: EnergyRecommendation[];
  
  // Összehasonlítás
  industryComparison: {
    averageConsumption: number; // kWh/m² vagy kWh/fő
    yourConsumption: number;
    performance: 'EXCELLENT' | 'GOOD' | 'AVERAGE' | 'POOR';
  };
  
  // Trend elemzés
  trendAnalysis?: {
    consumptionTrend: 'INCREASING' | 'STABLE' | 'DECREASING';
    costTrend: 'INCREASING' | 'STABLE' | 'DECREASING';
    seasonalPattern: string;
  };
}

export interface EnergyRecommendation {
  id: string;
  title: string;
  description: string;
  category: 'TARIFF' | 'EFFICIENCY' | 'RENEWABLE' | 'TIMING' | 'EQUIPMENT';
  priority: 'HIGH' | 'MEDIUM' | 'LOW';
  potentialSavings: {
    annual: number; // Ft/év
    percentage: number; // %
    co2Reduction: number; // kg CO2/év
  };
  implementationCost?: number; // Ft - beruházási költség
  paybackPeriod?: number; // hónap - megtérülési idő
  difficulty: 'EASY' | 'MEDIUM' | 'HARD';
}

export interface ApiConfig {
  apiKey: string;
}

// Google API kulcs (Vision és Gemini egyaránt)
export const DEFAULT_API_KEY = 'AIzaSyC2LgjUl7Og4ZRQkADnsji3Xt3reOXeZxc';