export interface ExtractedData {
  companyName: string;
  address: string;
  monthlyMaxPower: number; // kW - mért maximum teljesítmény
  contractedPower: number; // kW - lekötött teljesítmény
  systemUsageFee: number; // Ft - rendszerhasználati díj
  tariffType: string;
  billingPeriod: string;
  confidence: number;
  // Általános számlázási adatok
  totalAmount: number; // Ft
  customerName: string;
  customerAddress: string;
  taxNumber: string;
  invoiceNumber: string;
  // Lekötés optimalizációhoz szükséges specifikus adatok
  performanceFeeUnit: number; // Ft/kW/hó - teljesítmény díj egységár
  yearlyPerformanceFee: number; // Ft/kW/év - éves teljesítmény díj  
  podNumber: string; // POD azonosító
  exceedanceAmount: number; // kW - túllépés mértéke
  exceedanceFee: number; // Ft - túllépési díj összege
  actualEnergyConsumption: number; // kWh - tényleges energia fogyasztás
  energyFee: number; // Ft - energia díj
  networkUsageFee: number; // Ft - hálózathasználati díj
  measurementMonth: string; // pl. "2024 január"
  billingDays: number; // számlázási napok száma
  fileName?: string; // PDF fájl neve (opcionális)
}

export interface ApiConfig {
  apiKey: string;
}

// Google API kulcs (Vision és Gemini egyaránt)
export const DEFAULT_API_KEY = 'AIzaSyC2LgjUl7Og4ZRQkADnsji3Xt3reOXeZxc';