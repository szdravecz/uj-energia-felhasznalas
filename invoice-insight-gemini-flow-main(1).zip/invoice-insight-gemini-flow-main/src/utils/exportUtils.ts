import type { ExtractedData } from "@/services/invoiceAnalysisService";

interface ResultsData {
  extractedData: ExtractedData[];
  extractedTexts: {fileName: string, text: string}[];
  professionalAnalysis: string;
}

export const exportToJSON = (data: ResultsData) => {
  const exportData = {
    exportDate: new Date().toISOString(),
    summary: {
      totalInvoices: data.extractedData.length,
      totalFiles: data.extractedTexts.length,
      companyName: data.extractedData[0]?.customerName || 'Ismeretlen ügyfél'
    },
    extractedData: data.extractedData,
    extractedTexts: data.extractedTexts,
    professionalAnalysis: data.professionalAnalysis
  };

  const jsonString = JSON.stringify(exportData, null, 2);
  const blob = new Blob([jsonString], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  
  const now = new Date();
  const dateString = now.toISOString().split('T')[0].replace(/-/g, '_');
  const filename = `energia_elemzesi_eredmenyek_${dateString}.json`;
  
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};

export const exportToCSV = (data: ResultsData) => {
  const calculateOptimization = (invoice: ExtractedData) => {
    if (!invoice.systemUsageFee || invoice.systemUsageFee === 0 || !invoice.contractedPower || invoice.contractedPower === 0) {
      return { 
        currentRHD: 0, 
        potentialSaving: 0, 
        newRHD: 0,
        hasValidData: false 
      };
    }
    
    const currentRHD = invoice.systemUsageFee;
    const optimalContractedPower = invoice.monthlyMaxPower;
    
    if (optimalContractedPower >= invoice.contractedPower) {
      return { 
        currentRHD, 
        potentialSaving: 0, 
        newRHD: currentRHD,
        hasValidData: true 
      };
    }
    
    const newRHD = Math.round((optimalContractedPower / invoice.contractedPower) * currentRHD);
    const potentialSaving = currentRHD - newRHD;
    
    return { currentRHD, potentialSaving, newRHD, hasValidData: true };
  };

  const headers = [
    'POD szám',
    'Számlaszám', 
    'Ügyfél neve',
    'Ügyfél címe',
    'Lekötött teljesítmény (kW)',
    'Mért maximum (kW)',
    'Jelenlegi RHD (Ft)',
    'Optimális RHD (Ft)',
    'Megtakarítás (Ft)',
    'Megtakarítás (%)',
    'Számlázási időszak',
    'Mérési hónap'
  ];

  const csvRows = [
    headers.join(';'),
    ...data.extractedData.map(invoice => {
      const optimization = calculateOptimization(invoice);
      const savingsPercent = optimization.currentRHD > 0 ? 
        Math.round((optimization.potentialSaving / optimization.currentRHD) * 100) : 0;
      
      return [
        invoice.podNumber || '',
        invoice.invoiceNumber || '',
        invoice.customerName || '',
        invoice.customerAddress || '',
        invoice.contractedPower || '',
        invoice.monthlyMaxPower || '',
        optimization.currentRHD || '',
        optimization.newRHD || '',
        optimization.potentialSaving || '',
        `${savingsPercent}%`,
        invoice.billingPeriod || '',
        invoice.measurementMonth || ''
      ].join(';');
    })
  ];

  // UTF-8 BOM hozzáadása az Excel kompatibilitáshoz
  const csvContent = '\ufeff' + csvRows.join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  
  const now = new Date();
  const dateString = now.toISOString().split('T')[0].replace(/-/g, '_');
  const filename = `energia_optimalizalas_tablazat_${dateString}.csv`;
  
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};