export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instanciate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "12.2.3 (519615d)"
  }
  public: {
    Tables: {
      Arkozlo: {
        Row: {
          created_at: string
          id: number
        }
        Insert: {
          created_at?: string
          id?: number
        }
        Update: {
          created_at?: string
          id?: number
        }
        Relationships: []
      }
      document_results: {
        Row: {
          created_at: string | null
          debug_info: string | null
          extracted_text: string | null
          filename: string
          id: string
          interpretation: string | null
          status: number | null
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          debug_info?: string | null
          extracted_text?: string | null
          filename: string
          id?: string
          interpretation?: string | null
          status?: number | null
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          debug_info?: string | null
          extracted_text?: string | null
          filename?: string
          id?: string
          interpretation?: string | null
          status?: number | null
          user_id?: string | null
        }
        Relationships: []
      }
      document_term_matches: {
        Row: {
          confidence_score: number | null
          context_text: string | null
          created_at: string
          document_result_id: string | null
          id: string
          matched_text: string
          term_id: string | null
        }
        Insert: {
          confidence_score?: number | null
          context_text?: string | null
          created_at?: string
          document_result_id?: string | null
          id?: string
          matched_text: string
          term_id?: string | null
        }
        Update: {
          confidence_score?: number | null
          context_text?: string | null
          created_at?: string
          document_result_id?: string | null
          id?: string
          matched_text?: string
          term_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "document_term_matches_document_result_id_fkey"
            columns: ["document_result_id"]
            isOneToOne: false
            referencedRelation: "document_results"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "document_term_matches_term_id_fkey"
            columns: ["term_id"]
            isOneToOne: false
            referencedRelation: "professional_terms"
            referencedColumns: ["id"]
          },
        ]
      }
      energy_reports: {
        Row: {
          client_email: string
          company_name: string | null
          contracted_capacity: number | null
          created_at: string
          energy_type: string
          file_path: string | null
          file_size: number | null
          filename: string
          id: string
          peak_demand: number | null
          potential_savings: string | null
          recommended_capacity: number | null
          report_data: Json
          submitted_at: string | null
          total_cost: string | null
          unit: string | null
        }
        Insert: {
          client_email: string
          company_name?: string | null
          contracted_capacity?: number | null
          created_at?: string
          energy_type: string
          file_path?: string | null
          file_size?: number | null
          filename: string
          id?: string
          peak_demand?: number | null
          potential_savings?: string | null
          recommended_capacity?: number | null
          report_data: Json
          submitted_at?: string | null
          total_cost?: string | null
          unit?: string | null
        }
        Update: {
          client_email?: string
          company_name?: string | null
          contracted_capacity?: number | null
          created_at?: string
          energy_type?: string
          file_path?: string | null
          file_size?: number | null
          filename?: string
          id?: string
          peak_demand?: number | null
          potential_savings?: string | null
          recommended_capacity?: number | null
          report_data?: Json
          submitted_at?: string | null
          total_cost?: string | null
          unit?: string | null
        }
        Relationships: []
      }
      professional_categories: {
        Row: {
          created_at: string
          description: string | null
          display_name: string
          id: string
          name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          display_name: string
          id?: string
          name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          display_name?: string
          id?: string
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
      professional_terms: {
        Row: {
          category_id: string | null
          confidence_score: number | null
          created_at: string
          id: string
          is_primary: boolean | null
          normalized_term: string
          term: string
          updated_at: string
          usage_count: number | null
        }
        Insert: {
          category_id?: string | null
          confidence_score?: number | null
          created_at?: string
          id?: string
          is_primary?: boolean | null
          normalized_term: string
          term: string
          updated_at?: string
          usage_count?: number | null
        }
        Update: {
          category_id?: string | null
          confidence_score?: number | null
          created_at?: string
          id?: string
          is_primary?: boolean | null
          normalized_term?: string
          term?: string
          updated_at?: string
          usage_count?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "professional_terms_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "professional_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      uploaded_files: {
        Row: {
          bucket: string
          created_at: string | null
          file_path: string
          filename: string
          id: string
          mimetype: string
          size: number | null
          uploader_email: string | null
        }
        Insert: {
          bucket: string
          created_at?: string | null
          file_path: string
          filename: string
          id?: string
          mimetype: string
          size?: number | null
          uploader_email?: string | null
        }
        Update: {
          bucket?: string
          created_at?: string | null
          file_path?: string
          filename?: string
          id?: string
          mimetype?: string
          size?: number | null
          uploader_email?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
