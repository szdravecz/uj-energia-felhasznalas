import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Clock, CheckCircle, AlertCircle, Loader2, FileText, Brain, Calculator, Target } from 'lucide-react';
import { cn } from '@/lib/utils';

interface AnalysisStep {
  id: string;
  title: string;
  description: string;
  status: 'pending' | 'running' | 'completed' | 'error';
  progress: number;
  duration?: number;
  error?: string;
  estimatedTime?: number;
}

interface AnalysisProgressBarProps {
  steps: AnalysisStep[];
  currentStep?: string;
  startTime?: number;
  totalFiles?: number;
}

const stepIcons = {
  'upload': FileText,
  'ocr': FileText,
  'ai-analysis': Brain,
  'calculation': Calculator,
  'results': Target
};

const stepEstimatedTimes = {
  'upload': 1,
  'ocr': 30, // 30 seconds per file on average
  'ai-analysis': 15,
  'calculation': 2,
  'results': 1
};

export const AnalysisProgressBar: React.FC<AnalysisProgressBarProps> = ({
  steps,
  currentStep,
  startTime,
  totalFiles = 1
}) => {
  const [elapsedTime, setElapsedTime] = useState(0);
  const [estimatedTotal, setEstimatedTotal] = useState(0);
  const [animatedProgress, setAnimatedProgress] = useState<{[stepId: string]: number}>({});

  // Calculate elapsed time
  useEffect(() => {
    if (!startTime) return;
    
    const interval = setInterval(() => {
      setElapsedTime(Date.now() - startTime);
    }, 1000);

    return () => clearInterval(interval);
  }, [startTime]);

  // Calculate estimated total time
  useEffect(() => {
    const ocrTime = stepEstimatedTimes.ocr * totalFiles;
    const total = stepEstimatedTimes.upload + 
                  ocrTime + 
                  stepEstimatedTimes['ai-analysis'] + 
                  stepEstimatedTimes.calculation + 
                  stepEstimatedTimes.results;
    setEstimatedTotal(total * 1000); // Convert to milliseconds
  }, [totalFiles]);

  // Smooth progress animation for running steps
  useEffect(() => {
    const interval = setInterval(() => {
      setAnimatedProgress(prev => {
        const newProgress = { ...prev };
        
        steps.forEach(step => {
          if (step.status === 'running') {
            const currentAnimated = prev[step.id] || 0;
            const actualProgress = step.progress;
            
            // If actual progress is higher, jump to it immediately
            if (actualProgress > currentAnimated) {
              newProgress[step.id] = actualProgress;
            } else {
              // Otherwise, slowly increase animated progress (max 85% without real progress)
              const maxAutoProgress = Math.min(85, actualProgress + 20);
              if (currentAnimated < maxAutoProgress) {
                newProgress[step.id] = Math.min(maxAutoProgress, currentAnimated + Math.random() * 2 + 0.5);
              }
            }
          } else if (step.status === 'completed') {
            newProgress[step.id] = 100;
          } else if (step.status === 'pending') {
            newProgress[step.id] = 0;
          }
        });
        
        return newProgress;
      });
    }, 100); // Update every 100ms for smooth animation

    return () => clearInterval(interval);
  }, [steps]);

  // Calculate overall progress using animated values
  const completedSteps = steps.filter(step => step.status === 'completed').length;
  const runningStep = steps.find(step => step.status === 'running');
  const totalSteps = steps.length;
  
  let overallProgress = (completedSteps / totalSteps) * 100;
  if (runningStep) {
    const animatedStepProgress = animatedProgress[runningStep.id] || runningStep.progress;
    overallProgress += (animatedStepProgress / totalSteps);
  }

  // Calculate remaining time
  const remainingTime = Math.max(0, estimatedTotal - elapsedTime);
  
  const formatTime = (ms: number) => {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    
    if (minutes > 0) {
      return `${minutes}p ${remainingSeconds}mp`;
    }
    return `${remainingSeconds}mp`;
  };

  const getStepIcon = (step: AnalysisStep) => {
    const IconComponent = stepIcons[step.id as keyof typeof stepIcons] || FileText;
    
    if (step.status === 'running') {
      return <Loader2 className="h-5 w-5 text-primary animate-spin" />;
    } else if (step.status === 'completed') {
      return <CheckCircle className="h-5 w-5 text-green-500" />;
    } else if (step.status === 'error') {
      return <AlertCircle className="h-5 w-5 text-red-500" />;
    } else {
      return <IconComponent className="h-5 w-5 text-muted-foreground" />;
    }
  };

  const getStepBadgeVariant = (status: AnalysisStep['status']) => {
    switch (status) {
      case 'completed': return 'default';
      case 'running': return 'secondary';
      case 'error': return 'destructive';
      default: return 'outline';
    }
  };

  return (
    <Card className="w-full">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
              <Brain className="h-4 w-4 text-primary" />
            </div>
            <span>Elemzési folyamat</span>
          </div>
          <div className="flex items-center space-x-4 text-sm text-muted-foreground">
            {startTime && (
              <>
                <div className="flex items-center space-x-1">
                  <Clock className="h-4 w-4" />
                  <span>Eltelt: {formatTime(elapsedTime)}</span>
                </div>
                {remainingTime > 0 && (
                  <div className="flex items-center space-x-1">
                    <Clock className="h-4 w-4" />
                    <span>Hátra: {formatTime(remainingTime)}</span>
                  </div>
                )}
              </>
            )}
          </div>
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Overall Progress */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="font-medium">Összes előrehaladás</span>
            <span className="text-muted-foreground">{Math.round(overallProgress)}%</span>
          </div>
          <Progress 
            value={overallProgress} 
            className="h-3"
          />
        </div>

        {/* Individual Steps */}
        <div className="space-y-4">
          {steps.map((step, index) => (
            <div 
              key={step.id} 
              className={cn(
                "border rounded-lg p-4 transition-all duration-300",
                step.status === 'running' && "border-primary bg-primary/5 shadow-sm",
                step.status === 'completed' && "border-green-200 bg-green-50/50",
                step.status === 'error' && "border-red-200 bg-red-50/50"
              )}
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-3">
                  {getStepIcon(step)}
                  <div>
                    <h4 className="font-medium">{step.title}</h4>
                    <p className="text-sm text-muted-foreground">{step.description}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  {step.duration && (
                    <span className="text-xs text-muted-foreground">
                      {formatTime(step.duration * 1000)}
                    </span>
                  )}
                  <Badge variant={getStepBadgeVariant(step.status)}>
                    {step.status === 'pending' && 'Várakozás'}
                    {step.status === 'running' && 'Folyamatban'}
                    {step.status === 'completed' && 'Befejezve'}
                    {step.status === 'error' && 'Hiba'}
                  </Badge>
                </div>
              </div>
              
              {step.status === 'running' && (
                <div className="space-y-2">
                  <Progress 
                    value={animatedProgress[step.id] || step.progress} 
                    className="h-2 transition-all duration-300" 
                  />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>{Math.round(animatedProgress[step.id] || step.progress)}% kész</span>
                    {step.estimatedTime && (
                      <span>Becsült idő: {formatTime(step.estimatedTime * 1000)}</span>
                    )}
                  </div>
                </div>
              )}
              
              {step.error && (
                <div className="mt-2 text-sm text-red-600 bg-red-50 p-2 rounded">
                  {step.error}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Files info */}
        {totalFiles > 1 && (
          <div className="pt-4 border-t">
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <span>Feldolgozott fájlok száma:</span>
              <span className="font-medium">{totalFiles} PDF</span>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};