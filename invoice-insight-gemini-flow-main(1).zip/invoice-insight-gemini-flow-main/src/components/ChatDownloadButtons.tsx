import React from 'react';
import { Button } from "@/components/ui/button";
import { Download, FileText, Table } from "lucide-react";
import { exportToJSON, exportToCSV } from "@/utils/exportUtils";
import { toast } from "sonner";

interface ChatDownloadButtonsProps {
  resultsData: {
    extractedData: any[];
    extractedTexts: {fileName: string, text: string}[];
    professionalAnalysis: string;
  };
}

export const ChatDownloadButtons: React.FC<ChatDownloadButtonsProps> = ({ resultsData }) => {
  const handleJSONDownload = () => {
    try {
      exportToJSON(resultsData);
      toast.success("JSON fájl letöltése elkezdődött!");
    } catch (error) {
      toast.error("Hiba a JSON exportálás során");
      console.error('JSON export error:', error);
    }
  };

  const handleCSVDownload = () => {
    try {
      exportToCSV(resultsData);
      toast.success("CSV fájl letöltése elkezdődött!");
    } catch (error) {
      toast.error("Hiba a CSV exportálás során");
      console.error('CSV export error:', error);
    }
  };

  return (
    <div className="flex flex-col gap-3 p-4 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg border border-blue-200">
      <div className="flex items-center gap-2 mb-2">
        <Download className="h-5 w-5 text-blue-600" />
        <h3 className="font-semibold text-blue-900">Eredmények letöltése</h3>
      </div>
      
      <div className="flex flex-col gap-2">
        <Button 
          onClick={handleJSONDownload}
          className="flex items-center gap-2 w-full justify-start"
          variant="outline"
        >
          <FileText className="h-4 w-4" />
          JSON letöltés
          <span className="text-xs text-gray-500 ml-auto">
            (teljes adatsor)
          </span>
        </Button>
        
        <Button 
          onClick={handleCSVDownload}
          className="flex items-center gap-2 w-full justify-start"
          variant="outline"
        >
          <Table className="h-4 w-4" />
          CSV letöltés
          <span className="text-xs text-gray-500 ml-auto">
            (táblázat Excel-hez)
          </span>
        </Button>
      </div>
      
      <div className="text-xs text-gray-600 mt-2">
        <p>• <strong>JSON:</strong> Teljes elemzési adatok (szövegek, számítások, professzionális analízis)</p>
        <p>• <strong>CSV:</strong> Strukturált táblázat a fő számla adatokkal és optimalizálási eredményekkel</p>
      </div>
    </div>
  );
};