import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { 
  BarChart3, 
  DollarSign, 
  Zap, 
  TrendingUp, 
  Target,
  Settings2,
  CheckCircle,
  X
} from "lucide-react";
import { toast } from "sonner";

interface AnalysisCategory {
  id: string;
  title: string;
  icon: React.ComponentType<any>;
  emoji: string;
  description: string;
  enabled: boolean;
  subcategories: {
    id: string;
    title: string;
    enabled: boolean;
  }[];
}

interface AnalysisContentSelectorProps {
  onSave: (categories: AnalysisCategory[]) => void;
  onClose: () => void;
}

const defaultCategories: AnalysisCategory[] = [
  {
    id: 'consumption-profile',
    title: 'ENERGIA FOGYASZTÁSI PROFIL ELEMZÉSE',
    icon: BarChart3,
    emoji: '📊',
    description: 'Fogyasztási szokások és teljesítmény elemzése',
    enabled: true,
    subcategories: [
      { id: 'contracted-vs-measured', title: 'Lekötött vs. mért teljesítmény elemzése', enabled: true },
      { id: 'consumption-efficiency', title: 'Fogyasztási hatékonyság értékelése', enabled: true },
      { id: 'seasonal-trends', title: 'Szezonális trendek (ha több számlát kapsz)', enabled: true }
    ]
  },
  {
    id: 'cost-optimization',
    title: 'KÖLTSÉGOPTIMALIZÁLÁSI LEHETŐSÉGEK',
    icon: DollarSign,
    emoji: '💰',
    description: 'Költségcsökkentési és megtakarítási javaslatok',
    enabled: true,
    subcategories: [
      { id: 'system-fee-optimization', title: 'Rendszerhasználati díj optimalizálás', enabled: true },
      { id: 'tariff-switching', title: 'Tarifa váltási javaslatok', enabled: true },
      { id: 'capacity-adjustment', title: 'Teljesítmény lekötés módosítási javaslatok', enabled: true }
    ]
  },
  {
    id: 'performance-management',
    title: 'TELJESÍTMÉNYMENEDZSMENT',
    icon: Zap,
    emoji: '⚡',
    description: 'Teljesítmény optimalizálás és túllépés kezelés',
    enabled: true,
    subcategories: [
      { id: 'exceedance-analysis', title: 'Túllépések elemzése és megelőzési stratégiák', enabled: true },
      { id: 'optimal-capacity', title: 'Optimális lekötött teljesítmény meghatározása', enabled: true },
      { id: 'cost-benefit-analysis', title: 'Költség-haszon elemzés', enabled: true }
    ]
  },
  {
    id: 'industry-comparison',
    title: 'IPARÁGI ÖSSZEHASONLÍTÁS',
    icon: TrendingUp,
    emoji: '📈',
    description: 'Piaci pozíció és versenyképesség értékelése',
    enabled: true,
    subcategories: [
      { id: 'benchmarking', title: 'Benchmarking hasonló vállalkozásokkal', enabled: true },
      { id: 'market-position', title: 'Piaci átlagokhoz viszonyított pozíció', enabled: true },
      { id: 'competitiveness', title: 'Versenyképességi értékelés', enabled: true }
    ]
  },
  {
    id: 'recommendations',
    title: 'KONKRÉT AJÁNLÁSOK',
    icon: Target,
    emoji: '🎯',
    description: 'Időzített cselekvési tervek és javaslatok',
    enabled: true,
    subcategories: [
      { id: 'short-term', title: 'Rövid távú (1-3 hónap) intézkedések', enabled: true },
      { id: 'medium-term', title: 'Középtávú (3-12 hónap) stratégiák', enabled: true },
      { id: 'long-term', title: 'Hosszú távú (1-3 év) fejlesztési lehetőségek', enabled: true }
    ]
  }
];

// Icon mapping to restore icons from localStorage
const iconMap: Record<string, React.ComponentType<any>> = {
  'consumption-profile': BarChart3,
  'cost-optimization': DollarSign,
  'performance-management': Zap,
  'industry-comparison': TrendingUp,
  'recommendations': Target
};

const AnalysisContentSelector: React.FC<AnalysisContentSelectorProps> = ({
  onSave,
  onClose
}) => {
  const [categories, setCategories] = useState<AnalysisCategory[]>(() => {
    const saved = localStorage.getItem('analysisContentSettings');
    if (saved) {
      try {
        const parsedCategories = JSON.parse(saved);
        // Restore icons from the icon map
        return parsedCategories.map((cat: any) => ({
          ...cat,
          icon: iconMap[cat.id] || BarChart3 // fallback to BarChart3
        }));
      } catch {
        return defaultCategories;
      }
    }
    return defaultCategories;
  });

  const handleCategoryToggle = (categoryId: string) => {
    setCategories(prev => prev.map(cat => 
      cat.id === categoryId 
        ? { 
            ...cat, 
            enabled: !cat.enabled,
            subcategories: cat.subcategories.map(sub => ({ ...sub, enabled: !cat.enabled }))
          }
        : cat
    ));
  };

  const handleSubcategoryToggle = (categoryId: string, subcategoryId: string) => {
    setCategories(prev => prev.map(cat => 
      cat.id === categoryId 
        ? {
            ...cat,
            subcategories: cat.subcategories.map(sub =>
              sub.id === subcategoryId ? { ...sub, enabled: !sub.enabled } : sub
            )
          }
        : cat
    ));
  };

  const handleSelectAll = () => {
    setCategories(prev => prev.map(cat => ({
      ...cat,
      enabled: true,
      subcategories: cat.subcategories.map(sub => ({ ...sub, enabled: true }))
    })));
  };

  const handleDeselectAll = () => {
    setCategories(prev => prev.map(cat => ({
      ...cat,
      enabled: false,
      subcategories: cat.subcategories.map(sub => ({ ...sub, enabled: false }))
    })));
  };

  const handleSave = () => {
    localStorage.setItem('analysisContentSettings', JSON.stringify(categories));
    onSave(categories);
    toast.success("Elemzési beállítások mentve!");
  };

  const handleReset = () => {
    setCategories(defaultCategories);
    localStorage.removeItem('analysisContentSettings');
    toast.success("Alapértelmezett beállítások visszaállítva!");
  };

  const enabledCount = categories.reduce((count, cat) => 
    count + cat.subcategories.filter(sub => sub.enabled).length, 0
  );

  const totalCount = categories.reduce((count, cat) => count + cat.subcategories.length, 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Settings2 className="h-6 w-6 text-primary" />
            Szakmai Elemzés Tartalom Beállítások
          </h2>
          <p className="text-gray-600 mt-1">
            Válassza ki, mely elemzési kategóriákat szeretné látni az AI jelentésben
          </p>
          <Badge variant="outline" className="mt-2">
            {enabledCount}/{totalCount} elem kiválasztva
          </Badge>
        </div>
        
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={handleSelectAll}>
            <CheckCircle className="h-4 w-4 mr-1" />
            Mind
          </Button>
          <Button variant="outline" size="sm" onClick={handleDeselectAll}>
            <X className="h-4 w-4 mr-1" />
            Egyik sem
          </Button>
          <Button variant="secondary" size="sm" onClick={handleReset}>
            Alapértelmezett
          </Button>
        </div>
      </div>

      <div className="grid gap-4">
        {categories.map((category) => {
          const IconComponent = category.icon;
          const enabledSubs = category.subcategories.filter(sub => sub.enabled).length;
          const totalSubs = category.subcategories.length;
          
          return (
            <Card key={category.id} className={`transition-all duration-200 ${
              category.enabled ? 'border-primary/30 bg-primary/5' : 'border-gray-200 bg-gray-50'
            }`}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg transition-colors ${
                      category.enabled ? 'bg-primary/10' : 'bg-gray-200'
                    }`}>
                      <IconComponent className={`h-5 w-5 ${
                        category.enabled ? 'text-primary' : 'text-gray-400'
                      }`} />
                    </div>
                    <div className="flex-1">
                      <CardTitle className="flex items-center gap-2 text-lg">
                        <span>{category.emoji}</span>
                        {category.title}
                        <Badge variant={category.enabled ? "default" : "secondary"} className="text-xs">
                          {enabledSubs}/{totalSubs}
                        </Badge>
                      </CardTitle>
                      <CardDescription className="mt-1">
                        {category.description}
                      </CardDescription>
                    </div>
                  </div>
                  
                  <Checkbox
                    checked={category.enabled}
                    onCheckedChange={() => handleCategoryToggle(category.id)}
                    className="mt-1"
                  />
                </div>
              </CardHeader>
              
              <CardContent className="pt-0">
                <Separator className="mb-4" />
                <div className="space-y-3">
                  {category.subcategories.map((subcategory) => (
                    <div key={subcategory.id} className="flex items-center justify-between py-2 px-3 rounded-lg hover:bg-gray-50 transition-colors">
                      <div className="flex items-center gap-3">
                        <div className="w-1 h-6 bg-primary/30 rounded-full"></div>
                        <span className={`text-sm ${
                          subcategory.enabled ? 'text-gray-900 font-medium' : 'text-gray-500'
                        }`}>
                          {subcategory.title}
                        </span>
                      </div>
                      
                      <Checkbox
                        checked={subcategory.enabled}
                        onCheckedChange={() => handleSubcategoryToggle(category.id, subcategory.id)}
                        disabled={!category.enabled}
                      />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="flex justify-between items-center pt-4 border-t">
        <div className="text-sm text-gray-600">
          A beállítások automatikusan mentődnek és a következő elemzéskor lépnek életbe
        </div>
        
        <div className="flex gap-3">
          <Button variant="outline" onClick={onClose}>
            Mégse
          </Button>
          <Button onClick={handleSave} className="bg-primary hover:bg-primary/90">
            <CheckCircle className="h-4 w-4 mr-2" />
            Beállítások mentése
          </Button>
        </div>
      </div>
    </div>
  );
};

export default AnalysisContentSelector;