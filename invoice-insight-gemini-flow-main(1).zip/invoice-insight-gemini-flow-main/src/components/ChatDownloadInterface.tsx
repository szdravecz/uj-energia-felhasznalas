import React from 'react';
import { Button } from "@/components/ui/button";
import { Download, FileText, Table, CheckCircle } from "lucide-react";
import { exportToJSON, exportToCSV } from "@/utils/exportUtils";
import { useResultsData } from "@/hooks/useResultsData";
import { toast } from "sonner";

export const ChatDownloadInterface: React.FC = () => {
  const resultsData = useResultsData();

  if (!resultsData) {
    return (
      <div className="flex flex-col gap-3 p-4 bg-yellow-50 rounded-lg border border-yellow-200">
        <div className="flex items-center gap-2">
          <Download className="h-5 w-5 text-yellow-600" />
          <h3 className="font-semibold text-yellow-900">Letöltés nem elérhető</h3>
        </div>
        <p className="text-sm text-yellow-700">
          Kérlek, végezz el egy elemzést a /analysis oldalon, majd lépj át a /results oldalra a letöltési lehetőségekért.
        </p>
      </div>
    );
  }

  const handleJSONDownload = () => {
    try {
      exportToJSON(resultsData);
      toast.success("JSON fájl letöltése elkezdődött!");
    } catch (error) {
      toast.error("Hiba a JSON exportálás során");
      console.error('JSON export error:', error);
    }
  };

  const handleCSVDownload = () => {
    try {
      exportToCSV(resultsData);
      toast.success("CSV fájl letöltése elkezdődött!");
    } catch (error) {
      toast.error("Hiba a CSV exportálás során");
      console.error('CSV export error:', error);
    }
  };

  const totalInvoices = resultsData.extractedData.length;
  const companyName = resultsData.extractedData[0]?.customerName || 'Ismeretlen ügyfél';

  return (
    <div className="flex flex-col gap-4 p-4 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg border border-blue-200">
      <div className="flex items-center gap-2 mb-2">
        <CheckCircle className="h-5 w-5 text-green-600" />
        <h3 className="font-semibold text-blue-900">Eredmények letöltése elérhető</h3>
      </div>
      
      <div className="bg-white p-3 rounded-lg border border-blue-100">
        <div className="text-sm text-gray-600 mb-2">
          <p><strong>Ügyfél:</strong> {companyName}</p>
          <p><strong>Feldolgozott számlák:</strong> {totalInvoices} db</p>
          <p><strong>Letöltés dátuma:</strong> {new Date().toLocaleDateString('hu-HU')}</p>
        </div>
      </div>
      
      <div className="flex flex-col gap-2">
        <Button 
          onClick={handleJSONDownload}
          className="flex items-center gap-2 w-full justify-start bg-blue-600 hover:bg-blue-700"
          size="lg"
        >
          <FileText className="h-4 w-4" />
          JSON letöltés
          <span className="text-xs text-blue-200 ml-auto">
            (teljes adatsor)
          </span>
        </Button>
        
        <Button 
          onClick={handleCSVDownload}
          className="flex items-center gap-2 w-full justify-start bg-green-600 hover:bg-green-700"
          size="lg"
        >
          <Table className="h-4 w-4" />
          CSV letöltés
          <span className="text-xs text-green-200 ml-auto">
            (táblázat Excel-hez)
          </span>
        </Button>
      </div>
      
      <div className="text-xs text-gray-600 mt-2 bg-gray-50 p-3 rounded">
        <p className="mb-1">📄 <strong>JSON:</strong> Teljes elemzési adatok (szövegek, számítások, professzionális analízis)</p>
        <p>📊 <strong>CSV:</strong> Strukturált táblázat a fő számla adatokkal és optimalizálási eredményekkel</p>
      </div>
    </div>
  );
};